# ESSGOO Key Mapper + Przełącznik

Projekt Android (minSdk 28 / Android 9) do mapowania dostępnych klawiszy Androida oraz uruchamiania wybranej aplikacji z osobnego skrótu.

## Aplikacje
- **Mapowanie przycisków** — ustawienia, wybór aplikacji docelowej, motyw dzień/noc, skrót do ustawień radia i moduł mapowania.
- **Przełącznik** — działa jak przełącznik kontekstowy: poza DiPlay zapamiętuje bieżącą aplikację i otwiera DiPlay; uruchomiony ponownie w DiPlay wraca do poprzedniej aplikacji/zadania, o ile Android i sama aplikacja na to pozwalają.
- **Ekran główny** — drugi skrót, który wykonuje kontekstową akcję Home. Jest też automatycznie wywoływany przez androidowy `KEYCODE_1` (cyfra 1) oraz `KEYCODE_NUMPAD_1`, gdy usługa dostępności jest aktywna i opcja jest włączona. Poza DiPlay uruchamia Home Androida/launchera. W DiPlay próbuje kliknąć dostępny semantyczny przycisk Home/Dashboard. Nie używa Wstecz jako zamiennika, bo może opuścić CarPlay zamiast wrócić na jego stronę główną.

## Kompilacja
Wgraj zawartość ZIP-a do repozytorium GitHub i uruchom workflow `Build ESSGOO-KeyMapper-Integrated`. Możesz też trzymać archiwum `ESSGOO-KeyMapper-Integrated.zip` w repozytorium; workflow obsługuje oba układy.

## Ograniczenia
Kody protokołu CarPlay nie są automatycznie androidowymi KeyEventami. Przechwytywanie klawiszy zależy od firmware i od tego, czy Android przekazuje je do AccessibilityService. Skrót do ustawień producenta otwiera aplikację ustawień ESSGOO, ale nie gwarantuje bezpośredniego przejścia do podstrony mapowania kierownicy.


## Ważne dla przycisku 1
Android nie daje zwykłej aplikacji bez roota gwarantowanej metody wysłania dowolnego klawisza do innej aplikacji. Dlatego wejście do CarPlay Home zależy od tego, czy dISplay udostępnia dostępny przycisk Home/Dashboard albo czy jego obsługa Wstecz wraca do ekranu głównego CarPlay. Cyfra 1 jest przechwytywana globalnie, więc wyłącz tę opcję w Mapowaniu przycisków, jeśli potrzebujesz wpisywać cyfrę 1 na klawiaturze.

## BtnHome = 200: istotne ograniczenie techniczne

`CarPlayProtocol.BTN_HOME` ma wartość `200`, zgodnie z publicznymi implementacjami protokołu CarPlay. To identyfikator zdarzenia protokołu, a nie androidowy `KeyEvent`. Osobna aplikacja Android nie może sama wstrzyknąć tego zdarzenia do aktywnej sesji CarPlay w DiPlay bez obsługi po stronie DiPlay (np. publicznego API, broadcast receivera lub zmiany kodu samego odbiornika). Dlatego przycisk „1” działa w launcherze przez systemowe Home, a w DiPlay używa dostępnego semantycznego przycisku Home, jeśli jest wystawiony w drzewie dostępności. Gdy go nie ma, aplikacja informuje o ograniczeniu i nie symuluje Wstecz.

## Zakres tego archiwum a właściwy launcher

To repozytorium jest aplikacją pomocniczą do mapowania klawiszy i uruchamiania aplikacji; nie zawiera kodu właściwego launchera (pulpitu, pagera, szuflady aplikacji ani Docka). Dlatego nie dodano mu po cichu kategorii `CATEGORY_HOME` ani nie zastąpiono istniejącego launchera pustym ekranem. Funkcje Persistent Dock, strony pulpitu, App Drawer/Search/Settings oraz hierarchia `BackHandler` muszą być wprowadzone do źródłowego projektu launchera.

Właściwy punkt protokołu dla powrotu na stronę główną CarPlay to `CarPlayProtocol.BTN_HOME = 200`. W tym projekcie przycisk „1” korzysta z systemowego Home poza DiPlay i próbuje uruchomić widoczny semantyczny przycisk Home/Dashboard wewnątrz DiPlay (po etykiecie, opisie lub identyfikatorze zasobu). Jeśli DiPlay nie wystawia takiego węzła, zewnętrzna aplikacja nie ma bezpośredniego dostępu do prywatnego kanału protokołu CarPlay. Aby wysyłać `BtnHome=200` niezawodnie, potrzebna jest zmiana w DiPlay lub jego udokumentowane API.


## Co jest faktycznie obsługiwane przez tę osobną aplikację

- Skrót **Przełącznik** przełącza między wybraną aplikacją docelową (domyślnie wykrywaną jako DiPlay) a ostatnią zapamiętaną aplikacją. Przy powrocie uruchamiany jest istniejący task aplikacji, jeśli Android go zachował; system nie udostępnia zwykłej aplikacji bez roota gwarantowanego dostępu do dokładnego poprzedniego okna/tasku.
- **Mapowanie klawiszy Androida** zapisuje przypisania według rzeczywistego `KeyEvent` i wykonuje obsługiwane akcje z usługi dostępności: Home, Back, Recents, przełącznik, media, głośność i motyw. Lista zapisanych mapowań i opcja usunięcia wszystkich są w ekranie mapowania.
- **Mapowanie kodów CarPlay** pozwala zapisać lokalne przypisanie dla wybranego wpisu protokołu. To konfiguracja referencyjna: zewnętrzna aplikacja nie odbiera automatycznie zdarzeń z prywatnego kanału DiPlay i nie może sama wyemitować `BtnHome=200` do tej sesji. Żeby te mapowania protokołu wykonywały akcje w DiPlay, potrzebny jest interfejs integracyjny po stronie DiPlay.
- Projekt **nie jest launcherem**: nie rejestruje `CATEGORY_HOME`, nie zastępuje pulpitu i nie implementuje Docka/pulpitu/szuflady aplikacji. Działa obok istniejącego launchera jako aplikacja pomocnicza z osobnymi skrótami.

## Sprawdzenie

Workflow GitHub Actions buduje APK przez `gradle assembleDebug`. W tym środowisku nie ma zainstalowanego Gradle ani Android SDK, więc lokalnie sprawdzono strukturę archiwum i poprawność XML, ale kompilacja APK i test na radiu wymagają uruchomienia workflow i instalacji wyniku na urządzeniu.

## Dashboard i cztery własne przyciski

- W szufladzie/menu aplikacji dostępny jest kafelek **ESSGOO Control Center**, który otwiera pełne menu pomocniczej aplikacji.
- Jest też osobny kafelek **Ustawienia przycisków**, aby można było wejść bezpośrednio do konfiguracji.
- Menu zawiera cztery przyciski. W ustawieniach każdego można niezależnie zmienić widoczną nazwę oraz wybrać aplikację docelową z listy aplikacji uruchamialnych albo ekran główny Androida.
- Po zapisaniu ustawień menu pokazuje własną nazwę i wybraną aplikację. Kliknięcie przycisku uruchamia wybrany cel; ponowne kliknięcie, gdy cel jest rozpoznany jako ostatnia aplikacja na pierwszym planie, próbuje wrócić do zapisanego ekranu źródłowego.
- Zmiana nazwy dotyczy przycisku w tym menu, nie zmienia globalnej nazwy ani ikony aplikacji w Androidzie.

## App-drawer entries (revision)

The manifest now registers six independent Android launcher activities: **Ustawienia przycisków**, **Szybkie przełączanie**, and **Przycisk 1–4**. Each of the four slot entries invokes its own configured target from SharedPreferences and can be launched directly from the Android app list. The dashboard (`MainActivity`) is no longer a launcher entry, so it does not add a seventh icon. Each slot has its own icon.

**Android label limitation:** standard app-drawer labels for launcher activities come from the installed APK manifest/resources and cannot be changed dynamically by an ordinary app at runtime. The custom slot name remains configurable and is used inside the app's own UI; the app-drawer entries are named Przycisk 1–4. Custom-labelled pinned launcher shortcuts are a different Android feature and require launcher support/user confirmation, so they are not silently substituted for the six requested app-list entries.


## Kontrola logiki Home / CarPlay / kart launchera (ważne)

Ta wersja ogranicza częsty błąd śledzenia kontekstu: zdarzenia z paska systemowego, klawiatury i ekranów uprawnień nie nadpisują już aplikacji, do której ma wrócić przełącznik. Akcja Home najpierw sprawdza pakiet aktywnego okna; jeżeli widoczne jest tylko okno systemowe, korzysta z ostatniej rzeczywistej aplikacji zapisanej przez usługę dostępności.

Oczekiwane zachowanie:
1. **Przycisk 1 poza DiPlay** — wykonuje Android Home, czyli wraca do domyślnego launchera.
2. **Przycisk 1 w DiPlay** — próbuje kliknąć widoczny w drzewie dostępności przycisk Home/Dashboard CarPlay. Nie wysyła Android Back jako zamiennika.
3. **Szybkie przełączanie** — z launchera zapisuje launcher jako miejsce powrotu i otwiera wybraną aplikację; z aplikacji docelowej wraca do launchera przez `ACTION_MAIN` + `CATEGORY_HOME` albo uruchamia zapisaną aplikację.
4. **Karty/strony wewnątrz launchera** — aplikacja pomocnicza przechowuje jedynie pakiet aplikacji, nie identyfikator aktualnej karty. Powrót do launchera korzysta z systemowego Home, który zwykle przywraca istniejące zadanie launchera i jego stan, ale nie ma publicznego API, które gwarantuje zachowanie lub wybór konkretnej karty. Nawigacja Back wewnątrz launchera jest obsługiwana przez sam launcher po wywołaniu akcji Android Back.

**Czego nie da się potwierdzić ani zagwarantować z tej osobnej aplikacji:** `BtnHome=200` nie jest Androidowym KeyEventem. Dopóki DiPlay nie udostępni API/broadcastu lub nie zostanie zmodyfikowany jego kod, aplikacja zewnętrzna nie może niezawodnie wysłać CarPlay Home do prywatnej sesji. Jeśli DiPlay nie wystawia semantycznego przycisku Home w drzewie dostępności, funkcja CarPlay Home pozostaje zależna od integracji po stronie DiPlay. Podobnie szczegółowa obsługa kart launchera wymaga jego API albo kodu źródłowego.

## Zakres weryfikacji tej wersji

Przeprowadzono statyczną kontrolę ścieżek kodu i manifestu oraz sprawdzenie składni XML/archiwum. Nie wykonano kompilacji APK ani testu na fizycznym ESSGOO; dlatego nie jest to potwierdzenie działania sprzętowego. Test na radiu powinien osobno sprawdzić: (a) Home przy otwartej karcie launchera, (b) Home wewnątrz DiPlay, (c) szybkie przełączenie launcher → DiPlay → launcher, (d) te same kroki po rozwinięciu paska systemowego lub klawiatury.

## CarPlay-inspired Settings UI (Android 9)

`SettingsActivity` has been redesigned as a native, responsive, dark automotive settings interface: a soft radial graphite background, translucent rounded groups, colored icon tiles, chevrons, compact scroll controls, a custom time/LTE/battery header, touch feedback, and separate sub-pages with back navigation. The menu includes Driving Focus, Announce Messages, Appearance, Customize Icons, Wallpaper, Display, Accessibility, Siri and Suggestions, Live Activities, Pinned Conversations, Silent Mode, and an ESSGOO controls section.

Display preferences include **Inteligentny zoom ekranu** and **Grafiki albumów w widoku Odtwarzane**, enabled by default. Their values, plus the other demo preference switches, are saved locally in SharedPreferences. Important: on this standalone Android app, these switches store the user's UI preferences; they do not change private iPhone CarPlay/DiPlay internals unless that external application provides an integration API. The ESSGOO section keeps access to the four configurable shortcuts, key mapping, quick switching, and vendor settings.
