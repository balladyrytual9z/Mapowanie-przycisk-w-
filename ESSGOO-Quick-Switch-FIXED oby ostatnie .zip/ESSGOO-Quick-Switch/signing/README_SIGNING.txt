Development signing key for ESSGOO Quick Switch.

storePassword: qs-release-2026
keyAlias: quickswitch
keyPassword: qs-release-2026

This is a project-specific development key so successive APKs can update each other.
Keep the repository private if you do not want others to obtain the signing key.
Do not replace or regenerate it after installing the app, or Android will reject in-place updates.
