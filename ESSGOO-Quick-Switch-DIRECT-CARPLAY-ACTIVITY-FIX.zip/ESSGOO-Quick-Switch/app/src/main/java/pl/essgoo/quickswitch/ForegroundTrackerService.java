package pl.essgoo.quickswitch;

import android.accessibilityservice.AccessibilityService;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.PathInterpolator;
import android.view.accessibility.AccessibilityEvent;

/** Foreground tracking and a lightweight hardware-accelerated glass transition. */
public final class ForegroundTrackerService extends AccessibilityService {
    static final String PREFS = "quick_switch_state";
    static final String LAST_PACKAGE = "last_foreground_package";
    static final String ACTION_BEGIN_CARPLAY_TRANSITION = "pl.essgoo.quickswitch.BEGIN_CARPLAY_TRANSITION";
    static final String EXTRA_TARGET_PACKAGE = "target_package";
    static final String EXTRA_LAUNCH_CLASS = "launch_class";
    // Allows the accessibility overlay to be attached and rendered before the target app opens.
    static final long TRANSITION_PRELAUNCH_DELAY_MS = 120L;

    private static volatile ForegroundTrackerService instance;
    private String lastWrittenPackage = "";
    private WindowManager windowManager;
    private GlassTransitionView glassView;
    private String pendingTargetPackage = "";
    private String initialLaunchClass = "";
    private boolean sawTargetWindow;
    private boolean receiverRegistered;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable safetyTimeout = () -> dismissGlass(false);

    private final BroadcastReceiver transitionReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (intent == null || !ACTION_BEGIN_CARPLAY_TRANSITION.equals(intent.getAction())) return;
            startTransitionInternal(intent.getStringExtra(EXTRA_TARGET_PACKAGE),
                    intent.getStringExtra(EXTRA_LAUNCH_CLASS));
        }
    };

    public static ForegroundTrackerService getInstance() { return instance; }

    /** Direct in-process call when the accessibility service is already connected. */
    public static void startTransition(Context context, String targetPackage, String launchClass) {
        ForegroundTrackerService service = instance;
        if (service != null) {
            service.startTransitionInternal(targetPackage, launchClass);
        } else {
            Intent intent = new Intent(ACTION_BEGIN_CARPLAY_TRANSITION);
            intent.setPackage(context.getPackageName());
            intent.putExtra(EXTRA_TARGET_PACKAGE, targetPackage);
            intent.putExtra(EXTRA_LAUNCH_CLASS, launchClass);
            context.sendBroadcast(intent);
        }
    }

    private void startTransitionInternal(String targetPackage, String launchClass) {
        pendingTargetPackage = targetPackage == null ? "" : targetPackage;
        initialLaunchClass = launchClass == null ? "" : launchClass;
        sawTargetWindow = false;
        showGlass();
    }

    @Override protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        IntentFilter filter = new IntentFilter(ACTION_BEGIN_CARPLAY_TRANSITION);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(transitionReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(transitionReceiver, filter);
        }
        receiverRegistered = true;
    }

    @Override public boolean onUnbind(Intent intent) {
        if (instance == this) instance = null;
        return super.onUnbind(intent);
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || event.getPackageName() == null) return;
        int type = event.getEventType();
        if (type != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
                && type != AccessibilityEvent.TYPE_WINDOWS_CHANGED) return;
        String packageName = event.getPackageName().toString();
        CharSequence classSequence = event.getClassName();
        String className = classSequence == null ? "" : classSequence.toString();
        if (packageName.isEmpty() || packageName.equals(getPackageName()) || isTransient(packageName)) return;

        if (!pendingTargetPackage.isEmpty()) {
            boolean target = packageName.equals(pendingTargetPackage);
            if (target) {
                sawTargetWindow = true;
                // Close on the first real foreground-window change into the requested app.
                // Do not wait for a guessed class name: DiPlay versions use different activities.
                if (type == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
                    pendingTargetPackage = "";
                    // Keep the glass visible briefly after the target window appears so
                    // the transition is perceptible even on fast head-unit hardware.
                    handler.postDelayed(() -> {
                        if (pendingTargetPackage.isEmpty()) dismissGlass(true);
                    }, 220L);
                }
            } else if (sawTargetWindow) {
                // The target briefly appeared and another app took focus: avoid leaving the veil up.
                pendingTargetPackage = "";
                dismissGlass(true);
            }
        }
        if (!packageName.equals(lastWrittenPackage)) {
            lastWrittenPackage = packageName;
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(LAST_PACKAGE, packageName).apply();
        }
    }

    private void showGlass() {
        if (windowManager == null || pendingTargetPackage.isEmpty()) return;
        dismissGlass(false);
        GlassTransitionView view = new GlassTransitionView(this);
        glassView = view;
        view.setAlpha(0f);
        view.setScaleX(0.98f);
        view.setScaleY(0.98f);
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.setTitle("QuickSwitch Glass Transition");
        try {
            windowManager.addView(view, lp);
            // Start animation only after the overlay has attached to WindowManager.
            view.postOnAnimation(() -> {
                if (glassView != view) return;
                view.animate().alpha(0.96f).scaleX(1f).scaleY(1f).setDuration(180L)
                        .setInterpolator(new PathInterpolator(0.2f, 0.9f, 0.1f, 1f)).start();
            });
            handler.removeCallbacks(safetyTimeout);
            handler.postDelayed(safetyTimeout, 2200L);
        } catch (RuntimeException error) {
            glassView = null;
        }
    }

    private void dismissGlass(boolean synced) {
        handler.removeCallbacks(safetyTimeout);
        final GlassTransitionView old = glassView;
        glassView = null;
        if (old == null || windowManager == null) return;
        old.animate().alpha(0f).scaleX(1.01f).scaleY(1.01f)
                .setDuration(synced ? 110L : 90L)
                .setInterpolator(new PathInterpolator(0.4f, 0f, 0.2f, 1f))
                .setListener(new AnimatorListenerAdapter() {
                    @Override public void onAnimationEnd(Animator animation) {
                        try { windowManager.removeView(old); } catch (RuntimeException ignored) { }
                    }
                }).start();
    }

    private boolean isTransient(String pkg) {
        return pkg.equals("android") || pkg.equals("com.android.systemui")
                || pkg.equals("com.android.permissioncontroller")
                || pkg.equals("com.google.android.permissioncontroller")
                || pkg.contains("inputmethod") || pkg.contains("keyboard");
    }

    @Override public void onInterrupt() { dismissGlass(false); }

    @Override public void onDestroy() {
        if (instance == this) instance = null;
        handler.removeCallbacks(safetyTimeout);
        if (receiverRegistered) {
            try { unregisterReceiver(transitionReceiver); } catch (Exception ignored) { }
            receiverRegistered = false;
        }
        dismissGlass(false);
        super.onDestroy();
    }

    /** Dual-sheen Liquid Glass overlay; shaders are created on resize, never in onDraw(). */
    private static final class GlassTransitionView extends View {
        private final Paint veil = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint primaryStreak = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint secondaryStreak = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final float density;
        private float shimmerProgress;
        private ValueAnimator shimmerAnimator;
        private RadialGradient topGlowShader;
        private RadialGradient bottomGlowShader;

        GlassTransitionView(Context context) {
            super(context);
            density = getResources().getDisplayMetrics().density;
            setLayerType(View.LAYER_TYPE_HARDWARE, null);
            veil.setColor(Color.argb(58, 10, 16, 26));
            primaryStreak.setShader(new LinearGradient(0, 0, dp(380), 0,
                    new int[]{Color.TRANSPARENT, Color.argb(30, 255, 255, 255),
                            Color.argb(70, 220, 240, 255), Color.argb(18, 180, 220, 255), Color.TRANSPARENT},
                    new float[]{0f, 0.35f, 0.5f, 0.65f, 1f}, Shader.TileMode.CLAMP));
            secondaryStreak.setShader(new LinearGradient(0, 0, dp(220), 0,
                    new int[]{Color.TRANSPARENT, Color.argb(25, 200, 230, 255), Color.TRANSPARENT},
                    new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP));
        }

        private float dp(float value) { return value * density; }

        @Override protected void onSizeChanged(int w, int h, int oldw, int oldh) {
            super.onSizeChanged(w, h, oldw, oldh);
            if (w <= 0 || h <= 0) return;
            float max = Math.max(w, h);
            topGlowShader = new RadialGradient(w * 0.8f, h * 0.15f, max * 0.65f,
                    new int[]{Color.argb(45, 160, 215, 255), Color.argb(15, 100, 170, 240), Color.TRANSPARENT},
                    new float[]{0f, 0.45f, 1f}, Shader.TileMode.CLAMP);
            bottomGlowShader = new RadialGradient(w * 0.15f, h * 0.85f, max * 0.55f,
                    new int[]{Color.argb(28, 120, 180, 240), Color.TRANSPARENT}, null, Shader.TileMode.CLAMP);
        }

        @Override protected void onAttachedToWindow() {
            super.onAttachedToWindow();
            shimmerAnimator = ValueAnimator.ofFloat(0f, 1f);
            shimmerAnimator.setDuration(380L);
            shimmerAnimator.setInterpolator(new PathInterpolator(0.2f, 0.8f, 0.2f, 1f));
            shimmerAnimator.addUpdateListener(a -> { shimmerProgress = (Float) a.getAnimatedValue(); invalidate(); });
            shimmerAnimator.start();
        }

        @Override protected void onDetachedFromWindow() {
            if (shimmerAnimator != null) { shimmerAnimator.cancel(); shimmerAnimator = null; }
            super.onDetachedFromWindow();
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float w = getWidth(), h = getHeight();
            canvas.drawRect(0, 0, w, h, veil);
            if (topGlowShader != null) { glow.setShader(topGlowShader); canvas.drawRect(0, 0, w, h, glow); }
            if (bottomGlowShader != null) { glow.setShader(bottomGlowShader); canvas.drawRect(0, 0, w, h, glow); }
            canvas.save();
            canvas.rotate(-12f, w / 2f, h / 2f);
            float x1 = -dp(380) + (w + dp(760)) * shimmerProgress;
            canvas.drawRect(x1, -h, x1 + dp(380), h * 2f, primaryStreak);
            canvas.restore();
            canvas.save();
            canvas.rotate(-6f, w / 2f, h / 2f);
            float x2 = -dp(220) + (w + dp(600)) * (shimmerProgress * 0.9f);
            canvas.drawRect(x2, -h, x2 + dp(220), h * 2f, secondaryStreak);
            canvas.restore();
        }
    }
}
