package pl.essgoo.appswitcher;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.provider.Settings;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class SettingsActivity extends Activity {
    private SharedPreferences prefs;
    private Spinner aSpinner, bSpinner;
    private final ArrayList<String> packageIds = new ArrayList<>();
    private final ArrayList<String> packageLabels = new ArrayList<>();
    private int bg = Color.rgb(16,18,22), surface = Color.rgb(30,33,39), text = Color.rgb(245,246,248), muted = Color.rgb(165,172,183), accent = Color.rgb(78,161,255);

    @Override public void onCreate(Bundle b) { super.onCreate(b); prefs=getSharedPreferences(Switcher.PREFS, MODE_PRIVATE); build(); }
    private void build() {
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true); scroll.setBackgroundColor(bg);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(22),dp(18),dp(22),dp(28)); scroll.addView(root);
        TextView eyebrow = label("ESSGOO  /  NARZĘDZIA", 12, muted, true); root.addView(eyebrow);
        TextView title = label("Mapowanie przycisków", 30, text, true); LinearLayout.LayoutParams tp = params(-1,-2); tp.topMargin=dp(8); root.addView(title,tp);
        TextView subtitle = label("Sterowanie przyciskami i ustawienia przełącznika ESSGOO", 15, muted, false); LinearLayout.LayoutParams sp=params(-1,-2); sp.topMargin=dp(4); root.addView(subtitle,sp);
        section(root,"MAPOWANIE PRZYCISKÓW");
        TextView mapHint = label("Przypisuj akcje do kodów CarPlay i fizycznych klawiszy Androida. Uruchom osobny ekran mapowania, aby skonfigurować przyciski i nasłuch.",14,muted,false);
        root.addView(mapHint, params(-1,-2));
        Button openMapping = button("Otwórz mapowanie i nasłuch");
        LinearLayout.LayoutParams omp=params(-1,dp(54)); omp.topMargin=dp(12); root.addView(openMapping,omp);
        openMapping.setOnClickListener(v -> startActivity(new Intent(this, MappingActivity.class)));
        section(root,"TRYB DZIAŁANIA");
        RadioGroup modes = new RadioGroup(this); modes.setOrientation(LinearLayout.VERTICAL); card(root,modes);
        RadioButton alt = radio("Ostatnie dwie aplikacje", "Przełączanie jak Alt + Tab", "ALT_TAB".equals(prefs.getString("mode","ALT_TAB")));
        RadioButton pair = radio("Dwie wybrane akcje", "Np. ekran główny ↔ dISplay", "PAIR".equals(prefs.getString("mode","ALT_TAB")));
        modes.addView(alt); modes.addView(pair); alt.setOnClickListener(v -> prefs.edit().putString("mode","ALT_TAB").apply()); pair.setOnClickListener(v -> prefs.edit().putString("mode","PAIR").apply());
        section(root,"AKCJE PRZEŁĄCZNIKA");
        TextView hint = label("W trybie dwóch akcji przycisk przełącza między A i B. Wybierz ekran główny albo dowolną zainstalowaną aplikację.",14,muted,false); root.addView(hint,params(-1,-2));
        loadApps();
        aSpinner = addPicker(root,"Akcja A",prefs.getString("target_a",Switcher.HOME));
        bSpinner = addPicker(root,"Akcja B",prefs.getString("target_b",""));
        Button save = button("Zapisz ustawienia"); LinearLayout.LayoutParams bp=params(-1,dp(54)); bp.topMargin=dp(22); root.addView(save,bp);
        save.setOnClickListener(v -> { prefs.edit().putString("target_a",packageIds.get(aSpinner.getSelectedItemPosition())).putString("target_b",packageIds.get(bSpinner.getSelectedItemPosition())).apply(); Toast.makeText(this,"Ustawienia zapisane",Toast.LENGTH_SHORT).show(); });
        Button access = button("Włącz dostęp do użycia aplikacji"); LinearLayout.LayoutParams ap=params(-1,dp(50)); ap.topMargin=dp(10); root.addView(access,ap); access.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        TextView note=label("Wymagane: w ustawieniach dostępności Androida włącz usługę „Przełącznik aplikacji”. Bez tego system nie pozwoli wiarygodnie śledzić poprzedniej aplikacji. Ta aplikacja nie odczytuje treści ekranu.",13,muted,false); LinearLayout.LayoutParams np=params(-1,-2); np.topMargin=dp(14); root.addView(note,np);
        setContentView(scroll);
    }
    private void loadApps() {
        packageIds.clear(); packageLabels.clear(); packageIds.add(Switcher.HOME); packageLabels.add("Ekran główny launchera");
        PackageManager pm=getPackageManager(); List<ApplicationInfo> apps=pm.getInstalledApplications(0); Collections.sort(apps, Comparator.comparing(x -> pm.getApplicationLabel(x).toString().toLowerCase()));
        for(ApplicationInfo app:apps) { if(app.packageName.equals(getPackageName())) continue; Intent launch=pm.getLaunchIntentForPackage(app.packageName); if(launch!=null) { packageIds.add(app.packageName); packageLabels.add(pm.getApplicationLabel(app).toString()); } }
    }
    private Spinner addPicker(LinearLayout root,String title,String selected) {
        TextView l=label(title,15,text,true); LinearLayout.LayoutParams lp=params(-1,-2); lp.topMargin=dp(14); root.addView(l,lp);
        Spinner s=new Spinner(this); ArrayAdapter<String> adapter=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,packageLabels); s.setAdapter(adapter);
        int idx=packageIds.indexOf(selected); s.setSelection(idx<0?0:idx); LinearLayout.LayoutParams p=params(-1,dp(52)); p.topMargin=dp(6); root.addView(s,p); s.setBackgroundTintList(android.content.res.ColorStateList.valueOf(surface)); return s;
    }
    private void section(LinearLayout root,String t) { TextView v=label(t,12,accent,true); LinearLayout.LayoutParams p=params(-1,-2); p.topMargin=dp(26); p.bottomMargin=dp(10); root.addView(v,p); }
    private void card(LinearLayout root,View child) { LinearLayout box=new LinearLayout(this); box.setPadding(dp(14),dp(8),dp(14),dp(8)); box.addView(child); box.setBackground(round(surface,dp(18))); LinearLayout.LayoutParams p=params(-1,-2); root.addView(box,p); }
    private RadioButton radio(String title,String sub,boolean checked) { RadioButton r=new RadioButton(this); r.setText(title+"\n"+sub); r.setTextColor(text); r.setTextSize(16); r.setButtonTintList(android.content.res.ColorStateList.valueOf(accent)); r.setPadding(dp(4),dp(8),dp(4),dp(8)); r.setChecked(checked); return r; }
    private Button button(String t) { Button b=new Button(this); b.setText(t); b.setTextColor(Color.WHITE); b.setAllCaps(false); b.setTextSize(16); b.setBackground(round(accent,dp(16))); return b; }
    private TextView label(String t,int size,int color,boolean bold) { TextView v=new TextView(this); v.setText(t); v.setTextSize(size); v.setTextColor(color); if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return v; }
    private GradientDrawable round(int color,int radius) { GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(radius); return d; }
    private LinearLayout.LayoutParams params(int w,int h) { return new LinearLayout.LayoutParams(w,h); }
    private int dp(int x) { return (int)(x*getResources().getDisplayMetrics().density+0.5f); }
}
