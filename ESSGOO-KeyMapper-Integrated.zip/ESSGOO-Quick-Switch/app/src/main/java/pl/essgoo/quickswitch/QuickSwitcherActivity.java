package pl.essgoo.quickswitch;

import android.app.Activity;
import android.app.ActivityOptions;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.TextUtils;
import android.widget.Toast;

import java.util.List;

/** One-action switcher: launcher -> DiPlay; DiPlay -> existing launcher task. */
public final class QuickSwitcherActivity extends Activity {
    private static final String PREFS = "quick_switch_state";
    private static final String DISPLAY_PACKAGE = "cached_diplay_package";

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        if (!isTrackerEnabled()) {
            Toast.makeText(this, "Włącz usługę dostępności „Szybkie przełączanie”, aby rozpoznawać DiPlay.", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            finish();
            return;
        }

        try {
            performSwitch();
        } catch (Exception e) {
            Toast.makeText(this, "Nie udało się przełączyć aplikacji.", Toast.LENGTH_SHORT).show();
            finish();
        }
    }

    private void performSwitch() {
        String displayPackage = findDiPlayPackageFast();
        if (TextUtils.isEmpty(displayPackage)) {
            Toast.makeText(this, "Nie znaleziono aplikacji DiPlay.", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        String last = getSharedPreferences(ForegroundTrackerService.PREFS, MODE_PRIVATE)
                .getString(ForegroundTrackerService.LAST_PACKAGE, "");
        if (displayPackage.equals(last)) {
            ActivityOptions options = ActivityOptions.makeCustomAnimation(
                    this, R.anim.qs_return_enter, R.anim.qs_exit);
            // Bring the existing HOME/launcher task forward instead of issuing a generic
            // HOME action. REORDER_TO_FRONT is intended to preserve its current tab/state.
            Intent home = new Intent(Intent.ACTION_MAIN);
            home.addCategory(Intent.CATEGORY_HOME);
            ResolveInfo resolved = getPackageManager().resolveActivity(home, PackageManager.MATCH_DEFAULT_ONLY);
            if (resolved != null && resolved.activityInfo != null) {
                home.setComponent(new ComponentName(resolved.activityInfo.packageName, resolved.activityInfo.name));
            }
            home.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                    | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
                    | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(home, options.toBundle());
        } else {
            Intent launch = getPackageManager().getLaunchIntentForPackage(displayPackage);
            if (launch == null) {
                Toast.makeText(this, "Nie można otworzyć DiPlay.", Toast.LENGTH_SHORT).show();
                finish();
                return;
            }
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
            final String targetPackage = displayPackage;
            final String launchClass = launch.getComponent() != null
                    ? launch.getComponent().getClassName() : "";
            // Ask the accessibility service to show a light, non-touchable glass transition.
            // The actual DiPlay launch is not delayed until its screen is ready.
            Intent transition = new Intent(ForegroundTrackerService.ACTION_BEGIN_CARPLAY_TRANSITION);
            transition.setPackage(getPackageName());
            transition.putExtra(ForegroundTrackerService.EXTRA_TARGET_PACKAGE, targetPackage);
            transition.putExtra(ForegroundTrackerService.EXTRA_LAUNCH_CLASS, launchClass);
            sendBroadcast(transition);
            new Handler(Looper.getMainLooper()).postDelayed(() -> {
                try {
                    ActivityOptions noSystemAnimation = ActivityOptions.makeCustomAnimation(
                            QuickSwitcherActivity.this, 0, 0);
                    startActivity(launch, noSystemAnimation.toBundle());
                    overridePendingTransition(0, 0);
                } catch (Exception ignored) {
                    Toast.makeText(QuickSwitcherActivity.this,
                            "Nie udało się otworzyć DiPlay.", Toast.LENGTH_SHORT).show();
                } finally {
                    finish();
                }
            }, 32L);
            return;
        }
        finish();
    }

    /** Cached first: avoids enumerating/sorting all installed apps on every tap. */
    private String findDiPlayPackageFast() {
        PackageManager pm = getPackageManager();
        android.content.SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        String cached = prefs.getString(DISPLAY_PACKAGE, "");
        if (!TextUtils.isEmpty(cached) && !cached.equals(getPackageName())
                && pm.getLaunchIntentForPackage(cached) != null) return cached;

        // First-run fallback only. Do not sort the entire installed-app list.
        List<ApplicationInfo> apps = pm.getInstalledApplications(0);
        for (ApplicationInfo app : apps) {
            if (app.packageName.equals(getPackageName())) continue;
            String pkg = app.packageName.toLowerCase(java.util.Locale.ROOT);
            String label = String.valueOf(pm.getApplicationLabel(app)).toLowerCase(java.util.Locale.ROOT);
            if (pkg.contains("diplay") || label.contains("diplay")) {
                if (pm.getLaunchIntentForPackage(app.packageName) != null) {
                    prefs.edit().putString(DISPLAY_PACKAGE, app.packageName).apply();
                    return app.packageName;
                }
            }
        }
        return "";
    }

    private boolean isTrackerEnabled() {
        String expected = new ComponentName(this, ForegroundTrackerService.class).flattenToString();
        String enabled = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (TextUtils.isEmpty(enabled)) return false;
        TextUtils.SimpleStringSplitter splitter = new TextUtils.SimpleStringSplitter(':');
        splitter.setString(enabled);
        while (splitter.hasNext()) {
            String item = splitter.next();
            if (expected.equalsIgnoreCase(item) || item.equalsIgnoreCase(expected.replace('/', '\\'))) return true;
        }
        return false;
    }
}
