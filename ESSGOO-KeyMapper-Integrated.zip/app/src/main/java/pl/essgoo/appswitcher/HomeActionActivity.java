package pl.essgoo.appswitcher;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.content.Intent;

/** Dedicated app-drawer activity for context-aware Home/return behavior. */
public class HomeActionActivity extends Activity {
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        finish();
        overridePendingTransition(0, 0);
        new Handler().postDelayed(() -> {
            if (!AppTrackingService.performContextHome()) {
                Intent home = new Intent(Intent.ACTION_MAIN);
                home.addCategory(Intent.CATEGORY_HOME);
                home.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                try { startActivity(home); } catch (Exception ignored) { }
            }
        }, 220);
    }
}
