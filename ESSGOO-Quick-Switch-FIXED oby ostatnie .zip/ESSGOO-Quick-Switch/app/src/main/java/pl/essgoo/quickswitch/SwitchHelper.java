package pl.essgoo.quickswitch;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.provider.Settings;
import android.text.TextUtils;
import java.util.HashSet;
import java.util.List;

/** Shared DiPlay detection and launch logic. */
public final class SwitchHelper {
    public static final String PREFS = "quick_switch_state";
    public static final String KEY_ANIMATION = "selected_animation";
    public static final String DISPLAY_PACKAGE = "cached_diplay_package";

    public static int getSelectedAnimation(Context ctx) {
        return ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getInt(KEY_ANIMATION, AnimationType.IPHONE_BOOT);
    }

    public static void setSelectedAnimation(Context ctx, int type) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putInt(KEY_ANIMATION, type).apply();
    }

    public static boolean isTrackerEnabled(Context ctx) {
        String expected = new ComponentName(ctx, ForegroundTrackerService.class).flattenToString();
        String enabled = Settings.Secure.getString(ctx.getContentResolver(),
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (TextUtils.isEmpty(enabled)) return false;
        TextUtils.SimpleStringSplitter splitter = new TextUtils.SimpleStringSplitter(':');
        splitter.setString(enabled);
        while (splitter.hasNext()) {
            String item = splitter.next();
            if (expected.equalsIgnoreCase(item)
                    || item.equalsIgnoreCase(expected.replace('/', '\\'))) return true;
        }
        return false;
    }

    public static boolean isKnownDiPlayPackage(String pkg) {
        return "com.shilapi.xcertplay".equals(pkg)
                || "com.carplay.dipower".equals(pkg)
                || "com.shihab.diplay".equals(pkg)
                || (!TextUtils.isEmpty(pkg)
                && pkg.toLowerCase(java.util.Locale.ROOT).contains("diplay"));
    }

    public static String findDiPlayPackage(Context ctx) {
        PackageManager pm = ctx.getPackageManager();
        SharedPreferences prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String[] known = {"com.shilapi.xcertplay", "com.carplay.dipower", "com.shihab.diplay"};
        for (String pkg : known) {
            if (pm.getLaunchIntentForPackage(pkg) != null) {
                prefs.edit().putString(DISPLAY_PACKAGE, pkg).apply();
                return pkg;
            }
        }
        String cached = prefs.getString(DISPLAY_PACKAGE, "");
        if (!TextUtils.isEmpty(cached) && !cached.equals(ctx.getPackageName())
                && pm.getLaunchIntentForPackage(cached) != null) return cached;

        prefs.edit().remove(DISPLAY_PACKAGE).apply();
        List<ApplicationInfo> apps = pm.getInstalledApplications(0);
        for (ApplicationInfo app : apps) {
            if (app.packageName.equals(ctx.getPackageName())) continue;
            String pkg = app.packageName.toLowerCase(java.util.Locale.ROOT);
            String label = String.valueOf(pm.getApplicationLabel(app)).toLowerCase(java.util.Locale.ROOT);
            if (pkg.contains("diplay") || label.contains("diplay")) {
                if (pm.getLaunchIntentForPackage(app.packageName) != null) {
                    prefs.edit().putString(DISPLAY_PACKAGE, app.packageName).apply();
                    return app.packageName;
                }
            }
        }
        return "";
    }

    public static String getLastForeground(Context ctx) {
        return ctx.getSharedPreferences(ForegroundTrackerService.PREFS, Context.MODE_PRIVATE)
                .getString(ForegroundTrackerService.LAST_PACKAGE, "");
    }

    /** @return true if currently on DiPlay (should go HOME), false if should open DiPlay */
    public static boolean shouldGoHome(Context ctx) {
        String display = findDiPlayPackage(ctx);
        String last = getLastForeground(ctx);
        return display.equals(last) || isKnownDiPlayPackage(last);
    }

    public static Intent buildHomeIntent() {
        Intent home = new Intent(Intent.ACTION_MAIN);
        home.addCategory(Intent.CATEGORY_HOME);
        home.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP
                | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
        return home;
    }

    public static Intent buildDiPlayIntent(Context ctx, String displayPackage) {
        Intent launch = resolveDirectDiPlayActivity(ctx, displayPackage);
        if (launch == null) {
            launch = ctx.getPackageManager().getLaunchIntentForPackage(displayPackage);
        }
        if (launch != null) {
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                    | Intent.FLAG_ACTIVITY_CLEAR_TOP
                    | Intent.FLAG_ACTIVITY_SINGLE_TOP
                    | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        }
        return launch;
    }

    private static Intent resolveDirectDiPlayActivity(Context ctx, String detectedPackage) {
        PackageManager pm = ctx.getPackageManager();
        String[] packages = {
                detectedPackage,
                "com.shilapi.xcertplay",
                "com.carplay.dipower",
                "com.shihab.diplay"
        };
        String[] targetActivities = {
                ".CarPlayHostActivity",
                "com.shilapi.xcertplay.CarPlayHostActivity",
                "com.carplay.dipower.CarPlayHostActivity",
                "com.shihab.diplay.CarPlayHostActivity",
                ".SameTaskCarPlayHostActivity",
                ".projection.ProjectionActivity",
                ".ProjectionActivity"
        };
        HashSet<String> seen = new HashSet<>();
        for (String pkg : packages) {
            if (TextUtils.isEmpty(pkg) || !seen.add(pkg)) continue;
            for (String activityPath : targetActivities) {
                String className = activityPath.startsWith(".") ? pkg + activityPath : activityPath;
                Intent candidate = new Intent();
                candidate.setComponent(new ComponentName(pkg, className));
                candidate.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                        | Intent.FLAG_ACTIVITY_CLEAR_TOP
                        | Intent.FLAG_ACTIVITY_SINGLE_TOP
                        | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                try {
                    ResolveInfo info = pm.resolveActivity(candidate, 0);
                    if (info != null && info.activityInfo != null) {
                        return candidate;
                    }
                } catch (RuntimeException ignored) {}
            }
        }
        return null;
    }

    private SwitchHelper() {}
}
