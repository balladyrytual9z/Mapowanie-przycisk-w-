UWAGA: Plik signing/quick-switch-release.jks nie został dołączony (był binarnym kluczem podpisu). 
Jeśli posiadasz oryginalny plik .jks – skopiuj go do folderu signing/.
Bez niego build release nie przejdzie (signingConfig).
