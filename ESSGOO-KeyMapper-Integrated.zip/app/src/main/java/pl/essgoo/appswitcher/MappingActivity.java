package pl.essgoo.appswitcher;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.content.SharedPreferences;
import android.content.Intent;
import android.provider.Settings;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.util.*;

public class MappingActivity extends Activity {
  private SharedPreferences prefs; private Spinner codeSpinner, actionSpinner; private TextView captured;
  private final Handler handler=new Handler(); private int bg=Color.rgb(16,18,22), surface=Color.rgb(30,33,39), fg=Color.rgb(245,246,248), muted=Color.rgb(165,172,183), accent=Color.rgb(78,161,255);
  private final String[] names={"Invalid (0)","BtnSiri (5)","CarMicrophone (7)","BtnLeft (100)","BtnRight (101)","BtnSelectDown (104)","BtnSelectUp (105)","BtnBack (106)","BtnDown (114)","BtnHome (200)","BtnPlay (201)","BtnPause (202)","BtnNextTrack (204)","BtnPrevTrack (205)","SupportWifi (1000)","SupportWifiNeedKo (1012)","AudioOutputStart (1)","AudioOutputStop (2)","AudioInputConfig (3)","AudioPhonecallStart (4)","AudioPhonecallStop (5)","AudioNaviStart (6)","AudioNaviStop (7)","AudioSiriStart (8)","AudioSiriStop (9)","AudioMediaStart (10)","AudioMediaStop (11)","TouchDown (14)","TouchMove (15)","TouchUp (16)"};
  private final int[] codes={0,5,7,100,101,104,105,106,114,200,201,202,204,205,1000,1012,1,2,3,4,5,6,7,8,9,10,11,14,15,16};
  private final String[] actions={"NONE","HOME","BACK","RECENTS","SWITCHER","PLAY_PAUSE","NEXT_TRACK","PREVIOUS_TRACK","VOLUME_UP","VOLUME_DOWN"};
  private final String[] actionLabels={"Brak akcji","Ekran główny Androida","Wstecz","Ostatnie aplikacje","Przełącznik / akcja A↔B","Odtwarzaj / pauza","Następny utwór","Poprzedni utwór","Głośniej","Ciszej"};
  @Override public void onCreate(Bundle b){super.onCreate(b);prefs=getSharedPreferences(Switcher.PREFS,MODE_PRIVATE);build();pollCaptured();}
  private void build(){ScrollView sc=new ScrollView(this);sc.setBackgroundColor(bg); LinearLayout root=new LinearLayout(this);root.setOrientation(1);root.setPadding(dp(20),dp(18),dp(20),dp(26));sc.addView(root);
    add(root,"ESSGOO  /  STEROWANIE",12,muted,true,0);add(root,"Przypisanie przycisków",28,fg,true,8);add(root,"Przypisz akcję do kodu CarPlay albo przechwyć fizyczny klawisz Androida.",14,muted,false,6);
    section(root,"KODY PROTOKOŁU CARPLAY"); add(root,"Wybierz kod, a następnie akcję. Kody protokołu nie są automatycznie klawiszami Androida: zadziałają tylko wtedy, gdy dISplay lub inny komponent przekaże je do tej aplikacji.",13,muted,false,0);
    codeSpinner=new Spinner(this); codeSpinner.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,names)); root.addView(codeSpinner,lp(-1,dp(52),12));
    actionSpinner=new Spinner(this); actionSpinner.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,actionLabels)); root.addView(actionSpinner,lp(-1,dp(52),8));
    Button save=button("Zapisz przypisanie kodu");root.addView(save,lp(-1,dp(52),12)); save.setOnClickListener(v->{int code=codes[codeSpinner.getSelectedItemPosition()];String act=actions[actionSpinner.getSelectedItemPosition()];prefs.edit().putString("protocol_item_"+codeSpinner.getSelectedItemPosition(),act).apply();Toast.makeText(this,"Zapisano "+names[codeSpinner.getSelectedItemPosition()]+" → "+act,Toast.LENGTH_SHORT).show();});
    section(root,"NASŁUCH KLAWISZY ANDROIDA"); add(root,"Włącz usługę dostępności, a następnie rozpocznij nasłuch. Naciśnij fizyczny przycisk na radiu, jeśli generuje standardowy Android KeyEvent.",13,muted,false,0);
    captured=add(root,"Ostatni klawisz: brak",16,fg,true,12); Button listen=button("Nasłuchuj następnego klawisza");root.addView(listen,lp(-1,dp(52),8)); listen.setOnClickListener(v->{prefs.edit().putBoolean("capture_key",true).remove("captured_key_name").apply();captured.setText("Nasłuch aktywny… naciśnij klawisz");});
    Button mapCaptured=button("Przypisz ostatni klawisz do wybranej akcji");root.addView(mapCaptured,lp(-1,dp(52),8)); mapCaptured.setOnClickListener(v->{int key=prefs.getInt("captured_key_code",Integer.MIN_VALUE);if(key==Integer.MIN_VALUE){Toast.makeText(this,"Najpierw uruchom nasłuch i naciśnij klawisz",Toast.LENGTH_LONG).show();return;}String act=actions[actionSpinner.getSelectedItemPosition()];prefs.edit().putString("hardware_"+key,act).apply();Toast.makeText(this,"Klawisz Androida "+key+" → "+act,Toast.LENGTH_LONG).show();});
    Button access=button("Otwórz ustawienia dostępności");root.addView(access,lp(-1,dp(50),8));access.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
    section(root,"WAŻNE OGRANICZENIA");add(root,"• Bez roota aplikacja nie może dowolnie wstrzykiwać KeyEventów do innych aplikacji. Może wykonać ograniczone akcje systemowe, np. Home, Wstecz i Ostatnie aplikacje.\n• Nasłuch działa tylko dla klawiszy przekazywanych przez Android AccessibilityService. Przyciski przejęte przez firmware lub aplikację radia mogą nie być widoczne.\n• BtnHome=200 to kod protokołu CarPlay, nie androidowy KEYCODE_HOME. Samo wpisanie 200 nie wywoła Home w dISplay.",13,muted,false,0);
    setContentView(sc);
  }
  private void pollCaptured(){String n=prefs.getString("captured_key_name","");if(!n.isEmpty()&&captured!=null)captured.setText("Ostatni klawisz: "+n+" (kod Androida "+prefs.getInt("captured_key_code",-1)+")");handler.postDelayed(this::pollCaptured,500);}
  private void section(LinearLayout r,String s){add(r,s,12,accent,true,24);} private TextView add(LinearLayout r,String s,int size,int color,boolean bold,int top){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);LinearLayout.LayoutParams p=lp(-1,-2,top);r.addView(t,p);return t;}
  private Button button(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextColor(Color.WHITE);b.setTextSize(15);b.setBackground(round(accent,dp(15)));return b;} private GradientDrawable round(int c,int r){GradientDrawable d=new GradientDrawable();d.setColor(c);d.setCornerRadius(r);return d;}
  private LinearLayout.LayoutParams lp(int w,int h,int top){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(w,h);p.topMargin=dp(top);return p;} private int dp(int x){return (int)(x*getResources().getDisplayMetrics().density+0.5f);}
}
