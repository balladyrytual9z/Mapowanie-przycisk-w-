package pl.essgoo.appswitcher;

/**
 * Public CarPlay receiver protocol values. These are NOT Android KeyEvent key codes.
 * A standalone Android app cannot inject these values into DiPlay unless DiPlay exposes
 * an integration API or this logic is implemented inside DiPlay itself. In particular,
 * BTN_HOME=200 is the correct CarPlay-level Home input, but it is not Android KEYCODE_HOME.
 */
public final class CarPlayProtocol {
    private CarPlayProtocol() {}

    public static final int INVALID = 0;
    public static final int BTN_SIRI = 5;
    public static final int CAR_MICROPHONE = 7;
    public static final int BTN_LEFT = 100;
    public static final int BTN_RIGHT = 101;
    public static final int BTN_SELECT_DOWN = 104;
    public static final int BTN_SELECT_UP = 105;
    public static final int BTN_BACK = 106;
    public static final int BTN_DOWN = 114;
    public static final int BTN_HOME = 200;
    public static final int BTN_PLAY = 201;
    public static final int BTN_PAUSE = 202;
    public static final int BTN_NEXT_TRACK = 204;
    public static final int BTN_PREV_TRACK = 205;
    public static final int SUPPORT_WIFI = 1000;
    public static final int SUPPORT_WIFI_NEED_KO = 1012;

    public static final int AUDIO_OUTPUT_START = 0x01;
    public static final int AUDIO_OUTPUT_STOP = 0x02;
    public static final int AUDIO_INPUT_CONFIG = 0x03;
    public static final int AUDIO_PHONECALL_START = 0x04;
    public static final int AUDIO_PHONECALL_STOP = 0x05;
    public static final int AUDIO_NAVI_START = 0x06;
    public static final int AUDIO_NAVI_STOP = 0x07;
    public static final int AUDIO_SIRI_START = 0x08;
    public static final int AUDIO_SIRI_STOP = 0x09;
    public static final int AUDIO_MEDIA_START = 0x0a;
    public static final int AUDIO_MEDIA_STOP = 0x0b;

    public static final int TOUCH_DOWN = 14;
    public static final int TOUCH_MOVE = 15;
    public static final int TOUCH_UP = 16;
}
