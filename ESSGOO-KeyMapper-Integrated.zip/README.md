# ESSGOO Key Mapper + Quick Switcher

Pomocnicza aplikacja dla radia ESSGOO z Androidem 9 (minSdk 28). Nie zastępuje launchera i nie wymaga roota.

## Osobne pozycje w menu aplikacji

- **Mapowanie klawiszy** — główny ekran ustawień aplikacji.
- **Szybkie przełączanie** — osobna aktywność bez ekranu pośredniego, którą można wybrać jako aplikację przypisywaną do przycisku w ustawieniach radia.
- **Konfiguracja przełącznika** — wybór aplikacji docelowej oraz przypisanie fizycznego klawisza dla szybkiego przełączania i dla Home.
- **Przycisk 1–4** — cztery niezależne aktywności uruchamiające skonfigurowane aplikacje.

## Logika Home

- Domyślnie klawisz `KEYCODE_1` wykonuje inteligentny Home. W konfiguracji można przechwycić inny klawisz; Home i przełącznik mają osobne przypisania.
- Poza DiPlay akcja Home wywołuje systemowy Android Home. System zwykle przywraca istniejący task launchera, dzięki czemu launcher może zachować poprzednią stronę/kartę. Zewnętrzna aplikacja nie ma publicznego API do wyboru konkretnej strony wewnątrz launchera.
- W DiPlay aplikacja przeszukuje widoczne okna usługi dostępności w poszukiwaniu dostępnego przycisku Home/Dashboard i próbuje go nacisnąć.
- `CarPlay BtnHome=200` to zdarzenie protokołu CarPlay, a nie Android `KeyEvent`. Jeśli DiPlay nie wystawia dostępnej kontrolki Home, niezawodne wysłanie tego zdarzenia wymaga API lub zmiany po stronie DiPlay. Aplikacja nie udaje, że może wstrzyknąć je do prywatnej sesji.

## Logika szybkiego przełączania

- Gdy szybkie przełączanie zostanie wywołane z launchera, zapisuje launcher jako miejsce powrotu i otwiera skonfigurowaną aplikację docelową (zwykle DiPlay).
- Gdy zostanie wywołane wewnątrz aplikacji docelowej, wraca do zapisanego launchera lub poprzedniej aplikacji.
- Powrót do launchera korzysta z systemowego `ACTION_MAIN` + `CATEGORY_HOME`, co daje Androidowi szansę przywrócenia istniejącego zadania launchera i jego aktualnej strony.

## Wymagane ustawienie Androida

Aby przechwytywać fizyczne klawisze, trzeba ręcznie włączyć usługę dostępności **Mapowanie klawiszy · nasłuch klawiszy**. Firmware radia musi przekazywać dany przycisk jako Android `KeyEvent`; nie każdy przycisk kierownicy jest widoczny dla aplikacji. Mapowanie kodów protokołu CarPlay w ekranie ustawień jest informacyjne i samo nie daje dostępu do prywatnego kanału DiPlay.

## Ikony i nazwy

Wpisy menu używają osobnych ikon wektorowych w stylu nowoczesnych interfejsów samochodowych. Nazwy czterech skrótów można zmieniać wewnątrz konfiguracji, ale Android 9 nie pozwala zwykłej aplikacji dynamicznie zmienić etykiet istniejących ikon w systemowej szufladzie aplikacji.

## Kompilacja

Projekt można wgrać do repozytorium GitHub i uruchomić workflow `.github/workflows/build.yml`, który wykonuje `gradle assembleDebug` i publikuje APK jako artifact. W tym środowisku nie ma Android SDK/Gradle, więc wykonano statyczną kontrolę plików XML i archiwum, ale nie potwierdzono kompilacji APK ani działania na fizycznym radiu.
