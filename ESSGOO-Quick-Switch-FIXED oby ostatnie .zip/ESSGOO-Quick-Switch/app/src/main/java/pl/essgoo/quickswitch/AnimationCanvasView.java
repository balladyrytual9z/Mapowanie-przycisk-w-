package pl.essgoo.quickswitch;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.View;
import java.util.Random;

/** Full-screen canvas that renders the selected transition effect frame-by-frame. */
public final class AnimationCanvasView extends View {
    private int type = AnimationType.NONE;
    private float progress; // 0..1
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final Random rng = new Random(42);
    private float[] sparkX, sparkY, sparkR, sparkA;
    private int w, h;

    public AnimationCanvasView(Context c) { super(c); init(); }
    public AnimationCanvasView(Context c, AttributeSet a) { super(c, a); init(); }

    private void init() {
        textPaint.setColor(Color.WHITE);
        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setFakeBoldText(true);
    }

    public void setAnimationType(int type) {
        this.type = type;
        if (type == AnimationType.SPARKLE) {
            int n = 48;
            sparkX = new float[n];
            sparkY = new float[n];
            sparkR = new float[n];
            sparkA = new float[n];
            for (int i = 0; i < n; i++) {
                sparkX[i] = rng.nextFloat();
                sparkY[i] = rng.nextFloat();
                sparkR[i] = 2f + rng.nextFloat() * 6f;
                sparkA[i] = 0.3f + rng.nextFloat() * 0.7f;
            }
        }
        invalidate();
    }

    public void setProgress(float p) {
        this.progress = Math.max(0f, Math.min(1f, p));
        invalidate();
    }

    @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
        this.w = w; this.h = h;
    }

    @Override protected void onDraw(Canvas c) {
        if (w == 0 || h == 0) return;
        switch (type) {
            case AnimationType.FADE:
            case AnimationType.CROSSFADE:
                drawFade(c); break;
            case AnimationType.ZOOM:
            case AnimationType.IOS_OPEN:
                drawZoom(c); break;
            case AnimationType.BLUR:
                drawBlur(c); break;
            case AnimationType.IPHONE_BOOT:
                drawIphoneBoot(c); break;
            case AnimationType.HONDA:
                drawHonda(c); break;
            case AnimationType.CARPLAY:
                drawCarPlay(c); break;
            case AnimationType.LIQUID:
                drawLiquid(c); break;
            case AnimationType.AURORA:
                drawAurora(c); break;
            case AnimationType.SPARKLE:
                drawSparkle(c); break;
            default:
                c.drawColor(Color.TRANSPARENT);
        }
    }

    private void drawFade(Canvas c) {
        int alpha = (int) (255 * (progress < 0.5f ? progress * 2f : (1f - progress) * 2f));
        c.drawColor(Color.argb(alpha, 0, 0, 0));
    }

    private void drawZoom(Canvas c) {
        float scale = 1f + progress * 0.35f;
        int alpha = (int) (255 * (progress < 0.4f ? progress / 0.4f : (1f - progress) / 0.6f));
        alpha = Math.max(0, Math.min(255, alpha));
        c.save();
        c.scale(scale, scale, w / 2f, h / 2f);
        c.drawColor(Color.argb(alpha, 0, 0, 0));
        c.restore();
    }

    private void drawBlur(Canvas c) {
        // Soft multi-layer veil (simulated blur)
        float p = progress < 0.5f ? progress * 2f : (1f - progress) * 2f;
        for (int i = 0; i < 5; i++) {
            float t = p * (1f - i * 0.12f);
            int a = (int) (180 * t);
            paint.setShader(new RadialGradient(w / 2f, h / 2f, w * (0.4f + i * 0.15f),
                    Color.argb(a, 20, 20, 30), Color.argb(0, 0, 0, 0), Shader.TileMode.CLAMP));
            c.drawRect(0, 0, w, h, paint);
        }
        paint.setShader(null);
    }

    private void drawIphoneBoot(Canvas c) {
        c.drawColor(Color.BLACK);
        // Logo glow in center, then fade out
        float phase;
        if (progress < 0.25f) phase = progress / 0.25f;           // fade in
        else if (progress < 0.65f) phase = 1f;                      // hold
        else phase = 1f - (progress - 0.65f) / 0.35f;               // fade out

        float cx = w / 2f, cy = h / 2f;
        int glow = (int) (90 * phase);
        paint.setShader(new RadialGradient(cx, cy, w * 0.28f,
                Color.argb(glow, 255, 255, 255), Color.TRANSPARENT, Shader.TileMode.CLAMP));
        c.drawCircle(cx, cy, w * 0.28f, paint);
        paint.setShader(null);

        textPaint.setAlpha((int) (255 * phase));
        textPaint.setTextSize(Math.min(w, h) * 0.07f);
        // Stylized apple-like mark using simple shape + text
        textPaint.setColor(Color.WHITE);
        c.drawText("●", cx, cy - Math.min(w, h) * 0.02f, textPaint);
        textPaint.setTextSize(Math.min(w, h) * 0.028f);
        textPaint.setFakeBoldText(false);
        textPaint.setLetterSpacing(0.25f);
        c.drawText("iPhone", cx, cy + Math.min(w, h) * 0.06f, textPaint);
        textPaint.setFakeBoldText(true);
        textPaint.setLetterSpacing(0f);
    }

    private void drawHonda(Canvas c) {
        c.drawColor(Color.BLACK);
        float phase;
        if (progress < 0.3f) phase = progress / 0.3f;
        else if (progress < 0.7f) phase = 1f;
        else phase = 1f - (progress - 0.7f) / 0.3f;

        float cx = w / 2f, cy = h / 2f;

        // Red accent bar sweep
        float barW = w * 0.55f * phase;
        paint.setColor(Color.argb((int) (220 * phase), 228, 5, 33)); // Honda red
        c.drawRoundRect(cx - barW / 2f, cy - 3f, cx + barW / 2f, cy + 3f, 3f, 3f, paint);

        textPaint.setAlpha((int) (255 * phase));
        textPaint.setTextSize(Math.min(w, h) * 0.09f);
        textPaint.setLetterSpacing(0.35f);
        textPaint.setColor(Color.WHITE);
        c.drawText("HONDA", cx, cy - Math.min(w, h) * 0.04f, textPaint);

        textPaint.setTextSize(Math.min(w, h) * 0.025f);
        textPaint.setLetterSpacing(0.4f);
        textPaint.setFakeBoldText(false);
        textPaint.setColor(Color.argb((int) (180 * phase), 255, 255, 255));
        c.drawText("SENSING", cx, cy + Math.min(w, h) * 0.06f, textPaint);
        textPaint.setFakeBoldText(true);
        textPaint.setLetterSpacing(0f);
    }

    private void drawCarPlay(Canvas c) {
        c.drawColor(Color.BLACK);
        float phase;
        if (progress < 0.28f) phase = progress / 0.28f;
        else if (progress < 0.68f) phase = 1f;
        else phase = 1f - (progress - 0.68f) / 0.32f;

        float cx = w / 2f, cy = h / 2f;
        float s = Math.min(w, h);

        // Soft blue glow
        int glow = (int) (100 * phase);
        paint.setShader(new RadialGradient(cx, cy, s * 0.32f,
                Color.argb(glow, 90, 200, 250), Color.TRANSPARENT, Shader.TileMode.CLAMP));
        c.drawCircle(cx, cy, s * 0.32f, paint);
        paint.setShader(null);

        // Stylized CarPlay-like mark: rounded square + play triangle
        float box = s * 0.12f;
        paint.setColor(Color.argb((int) (255 * phase), 90, 200, 250));
        c.drawRoundRect(cx - box, cy - box - s * 0.04f, cx + box, cy + box - s * 0.04f, box * 0.28f, box * 0.28f, paint);

        // Play triangle
        path.reset();
        float ty = cy - s * 0.04f;
        path.moveTo(cx - box * 0.25f, ty - box * 0.4f);
        path.lineTo(cx - box * 0.25f, ty + box * 0.4f);
        path.lineTo(cx + box * 0.45f, ty);
        path.close();
        paint.setColor(Color.argb((int) (255 * phase), 0, 0, 0));
        c.drawPath(path, paint);

        textPaint.setAlpha((int) (255 * phase));
        textPaint.setTextSize(s * 0.045f);
        textPaint.setLetterSpacing(0.08f);
        textPaint.setColor(Color.WHITE);
        c.drawText("CarPlay", cx, cy + s * 0.14f, textPaint);
        textPaint.setLetterSpacing(0f);
    }

    private void drawLiquid(Canvas c) {
        float p = progress;
        // Morphing blob waves
        for (int i = 0; i < 4; i++) {
            float t = (p + i * 0.18f) % 1f;
            float cy = h * (0.2f + t * 0.7f);
            int a = (int) (120 * (1f - Math.abs(t - 0.5f) * 2f) * (p < 0.5f ? p * 2f : (1f - p) * 2f));
            paint.setShader(new RadialGradient(w * (0.3f + i * 0.15f), cy, w * 0.45f,
                    Color.argb(Math.max(0, a), 40 + i * 30, 80, 200 - i * 20),
                    Color.TRANSPARENT, Shader.TileMode.CLAMP));
            c.drawRect(0, 0, w, h, paint);
        }
        paint.setShader(null);
        int veil = (int) (200 * (p < 0.5f ? p * 2f : (1f - p) * 2f));
        c.drawColor(Color.argb(veil / 3, 0, 0, 0));
    }

    private void drawAurora(Canvas c) {
        float p = progress;
        float intensity = p < 0.5f ? p * 2f : (1f - p) * 2f;
        int[] colors = {
                Color.argb((int) (180 * intensity), 0, 200, 180),
                Color.argb((int) (160 * intensity), 80, 40, 220),
                Color.argb((int) (140 * intensity), 220, 40, 120),
                Color.argb((int) (100 * intensity), 0, 0, 0)
        };
        float shift = p * w;
        paint.setShader(new LinearGradient(shift - w, 0, shift + w, h,
                colors, null, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, w, h, paint);
        paint.setShader(null);
    }

    private void drawSparkle(Canvas c) {
        float intensity = progress < 0.5f ? progress * 2f : (1f - progress) * 2f;
        c.drawColor(Color.argb((int) (220 * intensity), 0, 0, 0));
        if (sparkX == null) return;
        for (int i = 0; i < sparkX.length; i++) {
            float life = (progress * 1.4f + sparkA[i]) % 1f;
            float a = life < 0.5f ? life * 2f : (1f - life) * 2f;
            a *= intensity * sparkA[i];
            float x = sparkX[i] * w;
            float y = sparkY[i] * h - progress * h * 0.15f;
            paint.setColor(Color.argb((int) (255 * a), 255, 255, 255));
            c.drawCircle(x, y, sparkR[i] * (0.5f + a), paint);
        }
    }
}
