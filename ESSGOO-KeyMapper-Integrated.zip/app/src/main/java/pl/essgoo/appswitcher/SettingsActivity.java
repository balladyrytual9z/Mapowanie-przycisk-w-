package pl.essgoo.appswitcher;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.Drawable;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.widget.*;
import java.util.*;

/** Native Android settings UI for ESSGOO helper features, using a modern automotive visual style. */
public class SettingsActivity extends Activity {
    private SharedPreferences prefs;
    private FrameLayout frame;
    private ScrollView scroll;
    private LinearLayout root;
    private String page = "root";
    private int bg = 0xFF121212, card = 0xE62A2A2C, fg = Color.WHITE, muted = 0xFF8E8E93;
    private int green = 0xFF34C759, blue = 0xFF0A84FF, separator = 0xFF414145, inputSurface = 0xFF38383A;
    private boolean dark = true;
    private final ArrayList<String> ids = new ArrayList<>(), labels = new ArrayList<>();

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences(Switcher.PREFS, MODE_PRIVATE);
        getWindow().setNavigationBarColor(0xFF121212);
        getWindow().setStatusBarColor(0xFF121212);
        loadApps();
        showPage("root", false);
    }

    @Override public void onBackPressed() {
        if (!"root".equals(page)) showPage("root", true); else super.onBackPressed();
    }

    private void showPage(String next, boolean animate) {
        page = next;
        applyColors();
        getWindow().setNavigationBarColor(dark ? 0xFF121212 : 0xFFECECF0);
        frame = new FrameLayout(this);
        frame.setBackground(radialBackground());
        scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        scroll.setVerticalScrollBarEnabled(false);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(12), dp(42), dp(30));
        scroll.addView(root, new ScrollView.LayoutParams(-1, -2));
        frame.addView(scroll, new FrameLayout.LayoutParams(-1, -1));
        addScrollControls();
        setContentView(frame);
        addHeader(root, titleFor(next), !"root".equals(next));
        if ("root".equals(next)) buildMain();
        else if ("appearance".equals(next)) buildAppearance();
        else if ("icons".equals(next)) buildSlotSettings();
        else if ("accessibility".equals(next)) buildAccessibility();
        else if ("home".equals(next)) buildHomeControls();
        if (animate) {
            root.setAlpha(0f); root.setTranslationY(dp(8));
            root.animate().alpha(1f).translationY(0).setDuration(220).setInterpolator(new DecelerateInterpolator()).start();
        }
    }

    private String titleFor(String p) {
        if ("appearance".equals(p)) return "Wygląd aplikacji";
        if ("icons".equals(p)) return "Przyciski aplikacji";
        if ("accessibility".equals(p)) return "Dostępność";
        if ("home".equals(p)) return "Home i nawigacja";
        return "Ustawienia ESSGOO";
    }

    private void applyColors() {
        String theme = prefs.getString("theme", "DARK");
        if ("DAY".equals(theme)) dark = false;
        else if ("SYSTEM".equals(theme)) dark = (getResources().getConfiguration().uiMode & android.content.res.Configuration.UI_MODE_NIGHT_MASK) == android.content.res.Configuration.UI_MODE_NIGHT_YES;
        else dark = true;
        if (dark) {
            bg = 0xFF121212; card = 0xE62A2A2C; fg = Color.WHITE; muted = 0xFF8E8E93;
            separator = 0xFF414145; inputSurface = 0xFF38383A;
        } else {
            bg = 0xFFF2F2F7; card = 0xF9FFFFFF; fg = 0xFF17171A; muted = 0xFF68686E;
            separator = 0xFFD6D6DC; inputSurface = 0xFFE8E8ED;
        }
        getWindow().setNavigationBarColor(dark ? 0xFF121212 : 0xFFECECF0);
    }

    private Drawable radialBackground() {
        if (!dark) return new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{0xFFFFFFFF, 0xFFF4F4F7, 0xFFE9E9EF});
        int center = 0xFF29292E;
        String wallpaper = prefs.getString("wallpaper", "wallpaper_graphite");
        if ("wallpaper_blue".equals(wallpaper)) center = 0xFF10243D;
        else if ("wallpaper_purple".equals(wallpaper)) center = 0xFF2A1838;
        GradientDrawable d = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{center, 0xFF19191B, 0xFF121212});
        d.setGradientType(GradientDrawable.RADIAL_GRADIENT);
        d.setGradientCenter(0.76f, 0.27f);
        d.setGradientRadius(dp(650));
        return d;
    }

    private void addHeader(LinearLayout parent, String title, boolean back) {
        LinearLayout header = new LinearLayout(this); header.setGravity(Gravity.CENTER_VERTICAL); header.setOrientation(LinearLayout.HORIZONTAL);
        if (back) {
            TextView arrow = text("‹", 37, blue, false); arrow.setGravity(Gravity.CENTER); arrow.setBackground(round(0x662A2A2C, dp(15), 0x554A4A4E));
            header.addView(arrow, new LinearLayout.LayoutParams(dp(42), dp(42)));
            arrow.setOnClickListener(v -> showPage("root", true));
        }
        TextView heading = text(title, 28, fg, true);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(0, -2, 1); if (back) hp.leftMargin = dp(12);
        header.addView(heading, hp);
        parent.addView(header, lp(-1, dp(54), 8));
        if (!back) parent.addView(text("Skróty, klawisze i przełączanie aplikacji", 13, muted, false), lp(-1, -2, 2));
    }

    private void buildMain() {
        addSectionTitle("SKRÓTY APLIKACJI");
        LinearLayout shortcuts = group();
        addNavRow(shortcuts, "▦", 0xFF0A84FF, "Cztery przyciski aplikacji", "icons", "Konfiguruj");
        addDivider(shortcuts);
        addActionRow(shortcuts, "⇄", 0xFF30D158, "Szybkie przełączanie", "Przełącz do aplikacji docelowej lub wróć", () -> startActivity(new Intent(this, QuickSwitcherActivity.class)));

        addSectionTitle("STEROWANIE");
        LinearLayout control = group();
        addActionRow(control, "⌘", 0xFF0A84FF, "Mapowanie klawiszy", "Przypisz działanie do obsługiwanych klawiszy", () -> startActivity(new Intent(this, MappingActivity.class)));
        addDivider(control);
        addNavRow(control, "⌂", 0xFF30D158, "Home i nawigacja", "home", "Szczegóły");
        addDivider(control);
        addNavRow(control, "♿", 0xFF64D2FF, "Dostępność Androida", "accessibility", isAccessibilityServiceEnabled() ? "Włączona" : "Wymagana konfiguracja");

        addSectionTitle("WYGLĄD TEJ APLIKACJI");
        LinearLayout appearance = group();
        String themeLabel = prefs.getString("theme", "DARK").equals("DAY") ? "Jasny" : prefs.getString("theme", "DARK").equals("SYSTEM") ? "Zgodny z systemem" : "Ciemny";
        addNavRow(appearance, "◐", 0xFFBF5AF2, "Motyw interfejsu", "appearance", themeLabel);

        addSectionTitle("SYSTEM RADIA");
        LinearLayout system = group();
        addActionRow(system, "⚙", 0xFF8E8E93, "Ustawienia producenta", "Otwórz ustawienia ESSGOO / Androida", this::openWheelSettings);
        addFooter("ESSGOO Control · Android 9 · aplikacja pomocnicza");
    }

    private void buildHomeControls() {
        addSectionTitle("ZACHOWANIE PRZYCISKU HOME");
        LinearLayout g = group();
        addActionRow(g, "⌂", 0xFF30D158, "Otwórz ekran główny Androida", "Poza DiPlay wywołuje systemowy HOME", () -> {
            try {
                Intent i = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
            } catch (Exception e) { toast("Nie udało się otworzyć ekranu głównego"); }
        });
        addDivider(g);
        addActionRow(g, "⌘", 0xFF0A84FF, "Testuj obsługę Home", "Przejdź do konfiguracji przechwytywania klawiszy", () -> startActivity(new Intent(this, MappingActivity.class)));
        addSectionTitle("WAŻNE O CARPLAY HOME");
        addInfoCard("Gdy DiPlay jest aktywny, aplikacja próbuje kliknąć dostępny przycisk Home/Dashboard w drzewie dostępności. Jeśli DiPlay nie udostępnia takiego przycisku, wysłanie BtnHome=200 wymaga integracji po stronie DiPlay. Ta aplikacja nie udaje, że może wysłać zdarzenie do prywatnej sesji CarPlay.");
        addSectionTitle("POWRÓT DO POPRZEDNIEGO EKRANU");
        addInfoCard("Szybkie przełączanie zapamiętuje aplikację widoczną przed przełączeniem i próbuje przywrócić jej istniejące zadanie. Android i sam launcher decydują, czy dokładna karta lub strona zostanie zachowana.");
    }

    private void buildAppearance() {
        addSectionTitle("MOTYW USTAWIEŃ"); LinearLayout g = group();
        addChoiceRow(g, "Ciemny", "DARK", "◐"); addDivider(g); addChoiceRow(g, "Jasny", "DAY", "☼"); addDivider(g); addChoiceRow(g, "Zgodny z systemem", "SYSTEM", "◉");
        addInfoCard("Motyw zmienia wyłącznie wygląd tej aplikacji pomocniczej.");
    }

    private void buildAccessibility() {
        addSectionTitle("PRZECHWYTYWANIE KLAWISZY");
        LinearLayout g = group();
        addActionRow(g, "♿", 0xFF64D2FF, "Usługa dostępności Androida", isAccessibilityServiceEnabled() ? "Włączona · nasłuch może działać" : "Wymaga ręcznego włączenia w ustawieniach Androida", () -> {
            try { startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); }
            catch (Exception e) { toast("Nie udało się otworzyć ustawień dostępności"); }
        });
        addInfoCard("Android wymaga ręcznego nadania uprawnienia usłudze dostępności. Bez tego mapowanie klawiszy sprzętowych nie będzie działać. Włącz usługę o nazwie „Mapowanie przycisków · nasłuch klawiszy”.");
    }

    private boolean isAccessibilityServiceEnabled() {
        try {
            String enabled = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            return enabled != null && enabled.toLowerCase(Locale.ROOT).contains((getPackageName() + "/" + AppTrackingService.class.getName()).toLowerCase(Locale.ROOT));
        } catch (Exception e) { return false; }
    }

    private void buildSlotSettings() {
        addSectionTitle("CZTERY PRZYCISKI W MENU APLIKACJI");
        TextView expl = text("Nadaj każdemu skrótowi własną nazwę i wybierz aplikację, którą ma otwierać.", 13, muted, false); root.addView(expl, lp(-1, -2, 3));
        for (int slot = 1; slot <= 4; slot++) addSlotConfig(slot);
        addSectionTitle("DOMYŚLNA APLIKACJA PRZEŁĄCZNIKA");
        LinearLayout g = group();
        Spinner target = appSpinner(prefs.getString("target_app", "")); g.addView(target, lp(-1, dp(48), 4));
        TextView save = pillButton("Zapisz domyślną aplikację", true); g.addView(save, lp(-1, dp(44), 8));
        save.setOnClickListener(v -> { int n=target.getSelectedItemPosition(); if(n>=0&&n<ids.size()){prefs.edit().putString("target_app",ids.get(n)).apply();toast("Zapisano: "+labels.get(n));}});
        addSectionTitle("MAPOWANIE KLAWISZY"); LinearLayout m = group();
        addActionRow(m, "⌘", blue, "Otwórz mapowanie", "Konfiguruj akcje i skróty", () -> startActivity(new Intent(this, MappingActivity.class)));
    }

    private void addSlotConfig(int slot) {
        String prefix="slot_"+slot; LinearLayout g=group();
        LinearLayout titleRow=new LinearLayout(this); titleRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView badge=text(String.valueOf(slot),17,fg,true); badge.setGravity(Gravity.CENTER); badge.setBackground(round(new int[]{0xFF0A84FF,0xFFBF5AF2,0xFFFF9F0A,0xFF30D158}[slot-1],dp(13),0)); titleRow.addView(badge,new LinearLayout.LayoutParams(dp(40),dp(40)));
        LinearLayout copy=new LinearLayout(this);copy.setOrientation(1);copy.setPadding(dp(12),0,0,0);copy.addView(text(prefs.getString(prefix+"_label","Przycisk "+slot),16,fg,true));copy.addView(text("Skrót "+slot,12,muted,false));titleRow.addView(copy,new LinearLayout.LayoutParams(0,-2,1));g.addView(titleRow);
        EditText name=new EditText(this);name.setSingleLine(true);name.setTextSize(15);name.setTextColor(fg);name.setHintTextColor(muted);name.setHint("Nazwa przycisku");name.setPadding(dp(12),0,dp(12),0);name.setBackground(round(inputSurface,dp(12),separator));name.setText(prefs.getString(prefix+"_label","Przycisk "+slot));g.addView(name,lp(-1,dp(46),12));
        Spinner app=appSpinner(prefs.getString(prefix+"_app",""));g.addView(app,lp(-1,dp(48),7));
        TextView save=pillButton("Zapisz przycisk "+slot,true);g.addView(save,lp(-1,dp(42),9));
        save.setOnClickListener(v->{int n=app.getSelectedItemPosition();if(n<0||n>=ids.size())return;String custom=name.getText().toString().trim();if(custom.isEmpty())custom="Przycisk "+slot;prefs.edit().putString(prefix+"_label",custom).putString(prefix+"_app",ids.get(n)).apply();toast("Zapisano: "+custom);});
    }

    private void addSectionTitle(String title) { TextView t=text(title,11,muted,true); t.setLetterSpacing(0.08f); root.addView(t,lp(-1,-2,23)); }
    private LinearLayout group() { LinearLayout g=new LinearLayout(this);g.setOrientation(LinearLayout.VERTICAL);g.setPadding(dp(13),dp(3),dp(13),dp(3));g.setBackground(round(card,dp(20),0x443F3F43));root.addView(g,lp(-1,-2,9));return g; }

    private void addNavRow(LinearLayout group,String glyph,int color,String title,String target,String trailing) {
        LinearLayout row=rowBase(glyph,color,title,null); if(trailing!=null&&!trailing.isEmpty()){TextView sub=text(trailing,12,muted,false);sub.setGravity(Gravity.CENTER_VERTICAL);row.addView(sub,lp(-2,-1,0));}
        TextView chev=text("›",29,0xFF77777D,false);chev.setGravity(Gravity.CENTER);row.addView(chev,new LinearLayout.LayoutParams(dp(24),dp(58)));
        row.setOnClickListener(v->showPage(target,true)); group.addView(row,new LinearLayout.LayoutParams(-1,dp(64)));
    }

    private void addToggleRow(LinearLayout group,String glyph,int color,String title,String desc,String key,boolean defaultOn) {
        LinearLayout row=rowBase(glyph,color,title,desc); Switch sw=new Switch(this);sw.setShowText(false);sw.setChecked(prefs.getBoolean(key,defaultOn));sw.setThumbTintList(switchThumb());sw.setTrackTintList(switchTrack());row.addView(sw,lp(-2,dp(44),0));
        sw.setOnCheckedChangeListener((button,checked)->prefs.edit().putBoolean(key,checked).apply());
        row.setOnClickListener(v->sw.setChecked(!sw.isChecked())); group.addView(row,new LinearLayout.LayoutParams(-1,dp(desc!=null&&desc.length()>45?96:desc!=null?80:62)));
    }

    private LinearLayout rowBase(String glyph,int color,String title,String desc) {
        LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(1),dp(5),dp(2),dp(5));
        TextView icon=text(glyph,20,Color.WHITE,true);icon.setGravity(Gravity.CENTER);icon.setBackground(round(color,dp(11),0x22FFFFFF));row.addView(icon,new LinearLayout.LayoutParams(dp(38),dp(38)));
        LinearLayout copy=new LinearLayout(this);copy.setOrientation(LinearLayout.VERTICAL);copy.setGravity(Gravity.CENTER_VERTICAL);copy.setPadding(dp(12),0,dp(8),0);copy.addView(text(title,15,fg,true));if(desc!=null)copy.addView(text(desc,12,muted,false),lp(-1,-2,3));
        row.addView(copy,new LinearLayout.LayoutParams(0,-1,1));row.setClickable(true);row.setFocusable(true);row.setBackground(makeRipple());row.setOnTouchListener((v,e)->{if(e.getAction()==MotionEvent.ACTION_DOWN)v.animate().scaleX(.992f).scaleY(.992f).setDuration(80).start();if(e.getAction()==MotionEvent.ACTION_UP||e.getAction()==MotionEvent.ACTION_CANCEL)v.animate().scaleX(1f).scaleY(1f).setDuration(130).start();return false;});return row;
    }

    private void addActionRow(LinearLayout group,String glyph,int color,String title,String desc,Runnable action){LinearLayout row=rowBase(glyph,color,title,desc);TextView chev=text("›",29,0xFF77777D,false);chev.setGravity(Gravity.CENTER);row.addView(chev,new LinearLayout.LayoutParams(dp(24),dp(58)));row.setOnClickListener(v->action.run());group.addView(row,new LinearLayout.LayoutParams(-1,dp(desc!=null?72:62)));}
    private void addDivider(LinearLayout group){View line=new View(this);line.setBackgroundColor(separator);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(1));p.leftMargin=dp(50);p.rightMargin=dp(5);group.addView(line,p);}

    private void addChoiceRow(LinearLayout g,String label,String value,String glyph){LinearLayout row=rowBase(glyph,blue,label,null);TextView check=text(prefs.getString("theme","DARK").equals(value)?"✓":"",20,green,true);check.setGravity(Gravity.CENTER);row.addView(check,new LinearLayout.LayoutParams(dp(28),dp(58)));row.setOnClickListener(v->{prefs.edit().putString("theme",value).apply();showPage("appearance",false);});g.addView(row,new LinearLayout.LayoutParams(-1,dp(62)));}
    private void addWallpaperChoice(LinearLayout g,String label,int color,String key){LinearLayout row=rowBase("✦",color,label,null);TextView check=text(prefs.getString("wallpaper","wallpaper_graphite").equals(key)?"✓":"›",22,fg,true);check.setGravity(Gravity.CENTER);row.addView(check,new LinearLayout.LayoutParams(dp(28),dp(58)));row.setOnClickListener(v->{prefs.edit().putString("wallpaper",key).apply();showPage("wallpaper",false);});g.addView(row,new LinearLayout.LayoutParams(-1,dp(62)));}

    private void addInfoCard(String msg){LinearLayout g=group();TextView t=text(msg,13,muted,false);g.addView(t,lp(-1,-2,3));}
    private void addFooter(String s){TextView f=text(s,11,muted,false);f.setGravity(Gravity.CENTER);root.addView(f,lp(-1,-2,24));}
    private void addScrollControls(){LinearLayout controls=new LinearLayout(this);controls.setOrientation(LinearLayout.VERTICAL);controls.setGravity(Gravity.CENTER);controls.setBackground(round(0xCC242426,dp(17),0x33444448));TextView up=text("⌃",18,0xFF77777D,true);up.setGravity(Gravity.CENTER);TextView down=text("⌄",18,0xFF77777D,true);down.setGravity(Gravity.CENTER);controls.addView(up,new LinearLayout.LayoutParams(dp(30),dp(35)));controls.addView(down,new LinearLayout.LayoutParams(dp(30),dp(35)));FrameLayout.LayoutParams cp=new FrameLayout.LayoutParams(dp(34),dp(74),Gravity.RIGHT|Gravity.CENTER_VERTICAL);cp.rightMargin=dp(4);frame.addView(controls,cp);up.setOnClickListener(v->scroll.smoothScrollBy(0,-dp(240)));down.setOnClickListener(v->scroll.smoothScrollBy(0,dp(240)));}

    private Spinner appSpinner(String selected){Spinner sp=new Spinner(this);sp.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,labels));int i=ids.indexOf(selected);sp.setSelection(i<0?0:i);sp.setBackgroundTintList(ColorStateList.valueOf(blue));return sp;}
    private void loadApps(){ids.clear();labels.clear();ids.add(Switcher.HOME);labels.add("Ekran główny Androida");PackageManager pm=getPackageManager();List<ApplicationInfo> apps=pm.getInstalledApplications(0);Collections.sort(apps,Comparator.comparing(a->String.valueOf(pm.getApplicationLabel(a)).toLowerCase(Locale.ROOT)));for(ApplicationInfo a:apps){if(a.packageName.equals(getPackageName()))continue;Intent i=pm.getLaunchIntentForPackage(a.packageName);if(i!=null){ids.add(a.packageName);labels.add(String.valueOf(pm.getApplicationLabel(a)));}}}
    private ColorStateList switchThumb(){return new ColorStateList(new int[][]{new int[]{android.R.attr.state_checked},new int[]{}},new int[]{Color.WHITE,0xFFE5E5EA});}
    private ColorStateList switchTrack(){return new ColorStateList(new int[][]{new int[]{android.R.attr.state_checked},new int[]{}},new int[]{green,0xFF555559});}
    private Drawable makeRipple(){if(android.os.Build.VERSION.SDK_INT>=21)return new android.graphics.drawable.RippleDrawable(ColorStateList.valueOf(0x22FFFFFF),null,null);return round(0xFF303033,dp(12),0xFF303033);}
    private TextView pillButton(String s,boolean primary){TextView t=text(s,14,primary?Color.WHITE:fg,true);t.setGravity(Gravity.CENTER);t.setBackground(round(primary?blue:inputSurface,dp(13),separator));t.setClickable(true);t.setFocusable(true);return t;}
    private TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setIncludeFontPadding(true);if(bold)t.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));else t.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));return t;}
    private GradientDrawable round(int color,int radius,int strokeColor){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(radius);if(strokeColor!=0)d.setStroke(dp(1),strokeColor);return d;}
    private LinearLayout.LayoutParams lp(int w,int h,int top){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(w,h);p.topMargin=dp(top);return p;}
    private int dp(int x){return (int)(x*getResources().getDisplayMetrics().density+0.5f);}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
    private void openWheelSettings(){try{Intent vendor=getPackageManager().getLaunchIntentForPackage("com.hcn.autosetting");if(vendor!=null){startActivity(vendor);return;}}catch(Exception ignored){}try{startActivity(new Intent(Settings.ACTION_SETTINGS));}catch(Exception e){toast("Nie udało się otworzyć ustawień");}}
}
