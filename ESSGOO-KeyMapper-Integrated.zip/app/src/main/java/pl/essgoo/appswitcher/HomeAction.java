package pl.essgoo.appswitcher;

import android.accessibilityservice.AccessibilityService;
import android.content.Context;
import android.content.SharedPreferences;
import android.text.TextUtils;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Toast;
import android.util.Log;

/** Context-aware Home action for the steering-wheel key 1. */
public final class HomeAction {
    private static final String TAG = "ESSGOO-HomeAction";
    private HomeAction() { }

    public static void perform(AccessibilityService service) {
        SharedPreferences p = service.getSharedPreferences(Switcher.PREFS, Context.MODE_PRIVATE);
        String target = p.getString("target_app", "");
        String displayPackage = Switcher.findDisplay(service);
        if (TextUtils.isEmpty(target)) target = displayPackage;

        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        String activePackage = "";
        if (root != null && root.getPackageName() != null) {
            String rootPackage = root.getPackageName().toString();
            // The active accessibility window can be a status-bar/keyboard overlay,
            // not the app whose screen is being controlled. Use the last real app
            // observed by AppTrackingService in that case.
            if (!isTransientSystemPackage(rootPackage) && !rootPackage.equals(service.getPackageName())) {
                activePackage = rootPackage;
            }
        }
        if (TextUtils.isEmpty(activePackage)) {
            activePackage = p.getString("last_seen", "");
        }

        boolean isDiPlayForeground = !TextUtils.isEmpty(activePackage)
                && ((!TextUtils.isEmpty(displayPackage) && displayPackage.equals(activePackage))
                || (target.equals(activePackage) && Switcher.isDisplayPackage(service, target)));
        if (isDiPlayForeground) {
            // Search all visible accessibility windows, not only the active one. On
            // head units the status bar/overlay can be the active window while DiPlay
            // still owns another visible window containing the Home control.
            boolean clicked = false;
            try {
                for (android.view.accessibility.AccessibilityWindowInfo window : service.getWindows()) {
                    AccessibilityNodeInfo windowRoot = null;
                    try {
                        windowRoot = window.getRoot();
                        if (windowRoot == null) continue;
                        CharSequence pkgName = windowRoot.getPackageName();
                        if (pkgName != null && target.equals(pkgName.toString()) && clickHomeNode(windowRoot)) {
                            clicked = true;
                            break;
                        }
                    } catch (Exception ignored) { }
                    finally {
                        if (windowRoot != null) windowRoot.recycle();
                        try { window.recycle(); } catch (Exception ignored) { }
                    }
                }
            } catch (Exception ignored) { }
            if (!clicked && root != null) {
                CharSequence pkgName = root.getPackageName();
                if (pkgName != null && target.equals(pkgName.toString())) clicked = clickHomeNode(root);
            }
            if (root != null) root.recycle();
            if (clicked) return;

            Log.w(TAG, "DiPlay is foreground, but no accessible CarPlay Home control is exposed. BtnHome="
                    + CarPlayProtocol.BTN_HOME + " requires an integration point inside DiPlay.");
            Toast.makeText(service,
                    "Nie znaleziono przycisku Home w DiPlay. Jeśli aplikacja go nie udostępnia, potrzebna jest integracja z DiPlay.",
                    Toast.LENGTH_LONG).show();
            return;
        }

        if (root != null) root.recycle();
        // Outside DiPlay: use Android's HOME action. This returns to the current
        // default launcher without attempting to finish or recreate its activity.
        service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME);
    }

    private static boolean clickHomeNode(AccessibilityNodeInfo node) {
        if (node == null) return false;
        CharSequence text = node.getText();
        CharSequence desc = node.getContentDescription();
        String resourceId = node.getViewIdResourceName();
        boolean homeNode = isHomeLabel(text) || isHomeLabel(desc) || isHomeResourceId(resourceId);
        if (homeNode) {
            AccessibilityNodeInfo clickable = node;
            while (clickable != null) {
                if (clickable.isClickable() && clickable.isEnabled()) {
                    if (clickable.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true;
                }
                AccessibilityNodeInfo parent = clickable.getParent();
                if (clickable != node) clickable.recycle();
                clickable = parent;
            }
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                boolean clicked;
                try { clicked = clickHomeNode(child); }
                finally { child.recycle(); }
                if (clicked) return true;
            }
        }
        return false;
    }

    private static boolean isTransientSystemPackage(String pkg) {
        if (pkg == null) return true;
        return pkg.equals("android") || pkg.equals("com.android.systemui")
                || pkg.equals("com.android.permissioncontroller")
                || pkg.equals("com.google.android.permissioncontroller")
                || pkg.contains("inputmethod") || pkg.contains("keyboard");
    }

    private static boolean isHomeResourceId(String value) {
        if (value == null) return false;
        String id = value.toLowerCase(java.util.Locale.ROOT);
        return id.endsWith(":id/home") || id.endsWith(":id/home_button")
                || id.endsWith(":id/dashboard") || id.endsWith(":id/dashboard_button")
                || id.endsWith(":id/carplay_home");
    }

    private static boolean isHomeLabel(CharSequence value) {
        if (value == null) return false;
        String s = value.toString().trim().toLowerCase(java.util.Locale.ROOT);
        return s.equals("home") || s.equals("carplay home") || s.equals("home screen")
                || s.equals("dashboard") || s.equals("ekran główny") || s.equals("strona główna")
                || s.equals("accueil") || s.equals("inicio") || s.equals("startseite")
                || s.contains("go to home") || s.contains("return home") || s.contains("home button")
                || s.contains("home screen") || s.contains("carplay home") || s.contains("dashboard button")
                || s.contains("ekran główny") || s.contains("strona główna");
    }
}
