package pl.essgoo.appswitcher;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;

/** Shared implementation behind four independently visible app-drawer entries. */
public abstract class SlotLaunchActivity extends Activity {
    protected abstract int slotNumber();
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        Switcher.performConfiguredSlot(this, slotNumber());
        finish();
        overridePendingTransition(0, 0);
    }
}
