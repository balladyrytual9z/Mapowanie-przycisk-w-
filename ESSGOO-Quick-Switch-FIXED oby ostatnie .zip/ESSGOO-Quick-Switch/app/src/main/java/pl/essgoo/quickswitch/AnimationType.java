package pl.essgoo.quickswitch;

/** Available transition animation styles. */
public final class AnimationType {
    public static final int NONE = 0;
    public static final int FADE = 1;
    public static final int ZOOM = 2;
    public static final int CROSSFADE = 3;
    public static final int IOS_OPEN = 4;
    public static final int BLUR = 5;
    public static final int IPHONE_BOOT = 6;
    public static final int HONDA = 7;
    public static final int CARPLAY = 8;
    public static final int LIQUID = 9;
    public static final int AURORA = 10;
    public static final int SPARKLE = 11;

    public static final int[] ALL = {
            NONE, FADE, ZOOM, CROSSFADE, IOS_OPEN, BLUR,
            IPHONE_BOOT, HONDA, CARPLAY, LIQUID, AURORA, SPARKLE
    };

    public static String label(int type) {
        switch (type) {
            case NONE: return "Bez animacji";
            case FADE: return "Zanikanie (Apple)";
            case ZOOM: return "Powiększenie i zanik";
            case CROSSFADE: return "Crossfade";
            case IOS_OPEN: return "Otwarcie aplikacji iOS";
            case BLUR: return "Miękka zasłona";
            case IPHONE_BOOT: return "Uruchomienie iPhone";
            case HONDA: return "Honda Reveal";
            case CARPLAY: return "CarPlay Boot";
            case LIQUID: return "Liquid Glass";
            case AURORA: return "Aurora Gradient";
            case SPARKLE: return "Iskry";
            default: return "Nieznana";
        }
    }

    public static int durationMs(int type) {
        switch (type) {
            case NONE: return 0;
            case FADE: return 450;
            case ZOOM: return 550;
            case CROSSFADE: return 500;
            case IOS_OPEN: return 600;
            case BLUR: return 700;
            case IPHONE_BOOT: return 1400;
            case HONDA: return 1600;
            case CARPLAY: return 1600;
            case LIQUID: return 900;
            case AURORA: return 1100;
            case SPARKLE: return 1000;
            default: return 500;
        }
    }

    private AnimationType() {}
}
