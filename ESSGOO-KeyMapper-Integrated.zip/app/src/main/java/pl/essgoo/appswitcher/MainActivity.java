package pl.essgoo.appswitcher;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ApplicationInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.Locale;

/** Main app-drawer entry and dashboard. This is a companion app, not a HOME launcher. */
public class MainActivity extends Activity {
    private SharedPreferences prefs;
    private int bg, surface, fg, muted, accent, stroke;
    private boolean firstResume = true;
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences(Switcher.PREFS, MODE_PRIVATE);
        applyColors();
        build();
    }
    @Override protected void onResume() { super.onResume(); if (firstResume) { firstResume = false; return; } if (prefs != null) { applyColors(); build(); } }
    private void applyColors() {
        String t = prefs.getString("theme", "SYSTEM");
        boolean dark = "DARK".equals(t) || ("SYSTEM".equals(t) && (getResources().getConfiguration().uiMode & 0x30) == 0x20);
        bg = dark ? Color.rgb(8,12,19) : Color.rgb(239,243,249);
        surface = dark ? Color.rgb(24,31,43) : Color.WHITE;
        fg = dark ? Color.rgb(246,249,255) : Color.rgb(20,29,45);
        muted = dark ? Color.rgb(158,173,194) : Color.rgb(96,111,132);
        accent = dark ? Color.rgb(82,166,255) : Color.rgb(0,112,245);
        stroke = dark ? Color.rgb(48,62,81) : Color.rgb(220,228,239);
    }
    private void build() {
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true); scroll.setBackgroundColor(bg);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(20),dp(22),dp(20),dp(28)); scroll.addView(root);
        LinearLayout header = new LinearLayout(this); header.setGravity(Gravity.CENTER_VERTICAL);
        TextView mark = text("⌘",27,Color.WHITE,true); mark.setGravity(Gravity.CENTER); mark.setBackground(round(accent,dp(16),accent)); header.addView(mark,new LinearLayout.LayoutParams(dp(54),dp(54)));
        LinearLayout titles = new LinearLayout(this); titles.setOrientation(1); titles.setPadding(dp(13),0,0,0);
        titles.addView(text("ESSGOO · CONTROL CENTER",11,accent,true)); titles.addView(text("Menu aplikacji",26,fg,true));
        header.addView(titles,new LinearLayout.LayoutParams(0,-2,1)); root.addView(header);
        root.addView(text("Cztery własne przyciski. Każdy może otwierać inną aplikację, a po ponownym użyciu wracać do poprzedniego ekranu.",14,muted,false),params(-1,-2,14));
        LinearLayout quick = card(); quick.setPadding(dp(16),dp(16),dp(16),dp(16));
        quick.addView(text("SZYBKIE PRZEŁĄCZANIE",11,accent,true));
        quick.addView(text("Dotknij przycisku, aby otworzyć wybraną aplikację. Nazwy i cele ustawisz w konfiguracji.",13,muted,false),params(-1,-2,5));
        root.addView(quick,params(-1,-2,17));
        for (int i=1;i<=4;i++) {
            final int slot=i;
            String label=Switcher.getSlotLabel(this,i);
            String target=prefs.getString("slot_"+i+"_app","");
            String appName=targetName(target);
            LinearLayout tile=card(); tile.setOrientation(LinearLayout.HORIZONTAL); tile.setGravity(Gravity.CENTER_VERTICAL); tile.setPadding(dp(15),dp(14),dp(15),dp(14));
            TextView num=text(String.format(Locale.getDefault(),"%02d",i),17,accent,true); num.setGravity(Gravity.CENTER); num.setBackground(round(bg,dp(14),stroke)); tile.addView(num,new LinearLayout.LayoutParams(dp(48),dp(48)));
            LinearLayout copy=new LinearLayout(this); copy.setOrientation(1); copy.setPadding(dp(13),0,dp(8),0);
            copy.addView(text(label,17,fg,true)); copy.addView(text(target.isEmpty()?"Wybierz aplikację w ustawieniach":appName,12,muted,false),params(-1,-2,4));
            tile.addView(copy,new LinearLayout.LayoutParams(0,-2,1));
            TextView go=text("›",29,accent,true); go.setGravity(Gravity.CENTER); tile.addView(go,new LinearLayout.LayoutParams(dp(30),dp(42)));
            tile.setClickable(true); tile.setFocusable(true); tile.setOnClickListener(v->Switcher.performConfiguredSlot(this,slot));
            root.addView(tile,params(-1,-2,10));
        }
        TextView settings=button("⚙   Ustawienia przycisków",true); root.addView(settings,params(-1,dp(54),19)); settings.setOnClickListener(v->startActivity(new Intent(this,SettingsActivity.class)));
        TextView mapping=button("Mapowanie klawiszy Androida",false); root.addView(mapping,params(-1,dp(48),9)); mapping.setOnClickListener(v->startActivity(new Intent(this,MappingActivity.class)));
        TextView radio=button("Ustawienia fabryczne radia",false); root.addView(radio,params(-1,dp(48),9)); radio.setOnClickListener(v->{try{Intent i=getPackageManager().getLaunchIntentForPackage("com.hcn.autosetting");if(i!=null)startActivity(i);else startActivity(new Intent(android.provider.Settings.ACTION_SETTINGS));}catch(Exception e){startActivity(new Intent(android.provider.Settings.ACTION_SETTINGS));}});
        root.addView(text("Osobna aplikacja pomocnicza · Android 9 · bez roota",12,muted,false),params(-1,-2,20));
        setContentView(scroll);
        for(int i=0;i<root.getChildCount();i++){View v=root.getChildAt(i);v.setAlpha(0f);v.setTranslationY(dp(7));v.animate().alpha(1f).translationY(0).setStartDelay(Math.min(i*25,250)).setDuration(240).start();}
    }
    private String targetName(String pkg) {
        if (pkg == null || pkg.isEmpty()) return "";
        if (Switcher.HOME.equals(pkg)) return "Ekran główny Androida";
        try { ApplicationInfo a=getPackageManager().getApplicationInfo(pkg,0); return String.valueOf(getPackageManager().getApplicationLabel(a)); }
        catch (Exception e) { return pkg; }
    }
    private LinearLayout card(){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setBackground(round(surface,dp(20),stroke));c.setElevation(dp(1));return c;}
    private TextView button(String s,boolean primary){TextView t=text(s,15,primary?Color.WHITE:fg,true);t.setGravity(Gravity.CENTER);t.setBackground(round(primary?accent:surface,dp(15),primary?accent:stroke));t.setClickable(true);t.setFocusable(true);return t;}
    private TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private GradientDrawable round(int color,int radius,int border){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(radius);d.setStroke(dp(1),border);return d;}
    private LinearLayout.LayoutParams params(int w,int h,int top){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(w,h);p.topMargin=dp(top);return p;}
    private int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
}
