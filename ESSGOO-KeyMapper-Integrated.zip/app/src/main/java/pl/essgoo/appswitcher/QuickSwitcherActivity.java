package pl.essgoo.appswitcher;

import android.app.Activity;
import android.os.Bundle;

/** Dedicated app-drawer icon for the contextual quick switcher. */
public class QuickSwitcherActivity extends Activity {
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        Switcher.perform(this);
        finish();
        overridePendingTransition(0, 0);
    }
}
