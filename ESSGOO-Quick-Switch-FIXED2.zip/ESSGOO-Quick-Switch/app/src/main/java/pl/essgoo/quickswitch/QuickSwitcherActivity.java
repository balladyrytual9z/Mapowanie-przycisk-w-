package pl.essgoo.quickswitch;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.widget.Toast;
import java.util.List;

/** One-action switcher: launcher -> DiPlay; DiPlay -> HOME/launcher. */
public final class QuickSwitcherActivity extends Activity {
    private static final String PREFS = "quick_switch_state";
    private static final String DISPLAY_PACKAGE = "cached_diplay_package";

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        if (!isTrackerEnabled()) {
            Toast.makeText(this, "Włącz usługę dostępności „Szybkie przełączanie”, aby rozpoznawać DiPlay.", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            finish();
            return;
        }
        try { performSwitch(); }
        catch (Exception e) {
            Toast.makeText(this, "Nie udało się przełączyć aplikacji.", Toast.LENGTH_SHORT).show();
            finish();
        }
    }

    private void performSwitch() {
        PackageManager pm = getPackageManager();
        String displayPackage = findDiPlayPackageFast();
        if (TextUtils.isEmpty(displayPackage)) {
            Toast.makeText(this, "Nie znaleziono zainstalowanej aplikacji DiPlay.", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        String last = getSharedPreferences(ForegroundTrackerService.PREFS, MODE_PRIVATE)
                .getString(ForegroundTrackerService.LAST_PACKAGE, "");

        // If DiPlay is currently foreground, return directly to the configured HOME app.
        if (displayPackage.equals(last) || isKnownDiPlayPackage(last)) {
            Intent home = new Intent(Intent.ACTION_MAIN);
            home.addCategory(Intent.CATEGORY_HOME);
            home.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP
                    | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
            try {
                startActivity(home);
                overridePendingTransition(0, 0);
            } catch (Exception e) {
                Toast.makeText(this, "Nie udało się wrócić do ekranu głównego.", Toast.LENGTH_SHORT).show();
            }
            finish();
            return;
        }

        // KLUCZOWA ZMIANA: Widżet systemowy DiPlay polega na domyślnym launcher intent package,
        // ponieważ to on poprawnie inicjalizuje wewnętrzny stan USB/dongle w przeciwieństwie do surowego HostActivity.
        Intent launch = pm.getLaunchIntentForPackage(displayPackage);

        if (launch == null) {
            launch = resolveDirectDiPlayActivity(displayPackage);
        }

        if (launch == null) {
            Toast.makeText(this, "DiPlay jest zainstalowany, ale nie udostępnia ekranu do uruchomienia.", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        // Dodanie flag imitujących zachowanie natywnego widżetu startowego
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED
                | Intent.FLAG_ACTIVITY_SINGLE_TOP);

        try {
            startActivity(launch);
            overridePendingTransition(0, 0);
        } catch (Exception e) {
            Toast.makeText(this, "Android zablokował uruchomienie ekranu DiPlay.", Toast.LENGTH_LONG).show();
        }
        finish();
    }

    private Intent resolveDirectDiPlayActivity(String detectedPackage) {
        PackageManager pm = getPackageManager();
        // Fallback do standardowego launch intentu danego pakietu
        return pm.getLaunchIntentForPackage(detectedPackage);
    }

    private boolean isKnownDiPlayPackage(String pkg) {
        return "com.shilapi.xcertplay".equals(pkg)
                || "com.carplay.dipower".equals(pkg)
                || "com.shihab.diplay".equals(pkg)
                || (!TextUtils.isEmpty(pkg) && pkg.toLowerCase(java.util.Locale.ROOT).contains("diplay"));
    }

    private String findDiPlayPackageFast() {
        PackageManager pm = getPackageManager();
        android.content.SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        // Check known DiPlay package IDs first. In particular, xcertplay does not
        // contain the word "diplay", so a name-only scan would miss it.
        String[] knownPackages = {"com.shilapi.xcertplay", "com.carplay.dipower", "com.shihab.diplay"};
        for (String pkg : knownPackages) {
            if (pm.getLaunchIntentForPackage(pkg) != null) {
                prefs.edit().putString(DISPLAY_PACKAGE, pkg).apply();
                return pkg;
            }
        }

        String cached = prefs.getString(DISPLAY_PACKAGE, "");
        if (!TextUtils.isEmpty(cached) && !cached.equals(getPackageName())
                && pm.getLaunchIntentForPackage(cached) != null) return cached;

        prefs.edit().remove(DISPLAY_PACKAGE).apply();
        List<ApplicationInfo> apps = pm.getInstalledApplications(0);
        for (ApplicationInfo app : apps) {
            if (app.packageName.equals(getPackageName())) continue;
            String pkg = app.packageName.toLowerCase(java.util.Locale.ROOT);
            String label = String.valueOf(pm.getApplicationLabel(app)).toLowerCase(java.util.Locale.ROOT);
            if (pkg.contains("diplay") || label.contains("diplay")) {
                if (pm.getLaunchIntentForPackage(app.packageName) != null) {
                    prefs.edit().putString(DISPLAY_PACKAGE, app.packageName).apply();
                    return app.packageName;
                }
            }
        }
        return "";
    }

    private boolean isTrackerEnabled() {
        String expected = new ComponentName(this, ForegroundTrackerService.class).flattenToString();
        String enabled = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (TextUtils.isEmpty(enabled)) return false;
        TextUtils.SimpleStringSplitter splitter = new TextUtils.SimpleStringSplitter(':');
        splitter.setString(enabled);
        while (splitter.hasNext()) {
            String item = splitter.next();
            if (expected.equalsIgnoreCase(item) || item.equalsIgnoreCase(expected.replace('/', '\\'))) return true;
        }
        return false;
    }
}
