package pl.essgoo.quickswitch;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Toast;

/**
 * One-tap switcher without settings UI.
 * Uses the animation selected in SettingsActivity.
 */
public final class QuickSwitcherActivity extends Activity {

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        if (!SwitchHelper.isTrackerEnabled(this)) {
            Toast.makeText(this, "Włącz usługę dostępności „Szybkie przełączanie”.", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            finish();
            return;
        }
        String display = SwitchHelper.findDiPlayPackage(this);
        if (display.isEmpty()) {
            Toast.makeText(this, "Nie znaleziono aplikacji DiPlay.", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        int anim = SwitchHelper.getSelectedAnimation(this);
        boolean goHome = SwitchHelper.shouldGoHome(this);

        if (anim == AnimationType.NONE) {
            try {
                if (goHome) {
                    startActivity(SwitchHelper.buildHomeIntent());
                } else {
                    Intent launch = SwitchHelper.buildDiPlayIntent(this, display);
                    if (launch == null) {
                        Toast.makeText(this, "DiPlay nie udostępnia ekranu.", Toast.LENGTH_LONG).show();
                    } else {
                        startActivity(launch);
                    }
                }
                overridePendingTransition(0, 0);
            } catch (Exception e) {
                Toast.makeText(this, "Nie udało się przełączyć.", Toast.LENGTH_SHORT).show();
            }
            finish();
            return;
        }

        Intent overlay = new Intent(this, AnimationOverlayActivity.class);
        overlay.putExtra(AnimationOverlayActivity.EXTRA_ANIM, anim);
        overlay.putExtra(AnimationOverlayActivity.EXTRA_PACKAGE, display);
        overlay.putExtra(AnimationOverlayActivity.EXTRA_GO_HOME, goHome);
        startActivity(overlay);
        overridePendingTransition(0, 0);
        finish();
    }
}
