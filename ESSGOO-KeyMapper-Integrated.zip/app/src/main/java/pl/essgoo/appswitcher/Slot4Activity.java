package pl.essgoo.appswitcher;

public class Slot4Activity extends SlotLaunchActivity {
    @Override protected int slotNumber() { return 4; }
}
