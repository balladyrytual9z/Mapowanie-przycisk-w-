package pl.essgoo.appswitcher;

public class Slot1Activity extends SlotLaunchActivity {
    @Override protected int slotNumber() { return 1; }
}
