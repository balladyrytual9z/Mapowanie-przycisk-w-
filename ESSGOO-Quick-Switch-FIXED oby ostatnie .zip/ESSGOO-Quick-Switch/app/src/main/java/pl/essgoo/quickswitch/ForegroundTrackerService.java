package pl.essgoo.quickswitch;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;

/** Tracks the foreground package only; intentionally contains no transition UI or animation. */
public final class ForegroundTrackerService extends AccessibilityService {
    static final String PREFS = "quick_switch_state";
    static final String LAST_PACKAGE = "last_foreground_package";
    private String lastWrittenPackage = "";

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || event.getPackageName() == null) return;
        int type = event.getEventType();
        if (type != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
                && type != AccessibilityEvent.TYPE_WINDOWS_CHANGED) return;
        String pkg = event.getPackageName().toString();
        if (pkg.isEmpty() || pkg.equals(getPackageName()) || isTransient(pkg)) return;
        if (!pkg.equals(lastWrittenPackage)) {
            lastWrittenPackage = pkg;
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(LAST_PACKAGE, pkg).apply();
        }
    }

    private boolean isTransient(String pkg) {
        return pkg.equals("android") || pkg.equals("com.android.systemui")
                || pkg.equals("com.android.permissioncontroller")
                || pkg.equals("com.google.android.permissioncontroller")
                || pkg.contains("inputmethod") || pkg.contains("keyboard");
    }

    @Override public void onInterrupt() { }
}
