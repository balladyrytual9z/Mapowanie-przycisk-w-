# ESSGOO Quick Switch — Fast / CarPlay-inspired transitions

Jednofunkcyjna aplikacja Android 9 (API 28+) do przełączania DiPlay ↔ launcher. Bez ustawień, mapowania klawiszy, Docka i dodatkowych funkcji.

## Działanie
- Launcher → DiPlay: uruchamia DiPlay. Po pierwszym wykryciu pakiet DiPlay jest zapamiętywany, więc kolejne przełączenia nie skanują całej listy aplikacji.
- DiPlay → launcher: rozwiązuje aktywną aplikację HOME i próbuje przywrócić istniejące zadanie launchera przez `NEW_TASK | REORDER_TO_FRONT | SINGLE_TOP`, zamiast zawsze wysyłać ogólne zdarzenie HOME. To daje launcherowi lepszą szansę zachowania poprzedniej karty.
- Launcher → DiPlay: aplikacja rozpoczyna lekką, sprzętowo przyspieszaną nakładkę Liquid Glass, po czym uruchamia DiPlay bez animacji systemowej. Nakładka jest nieklikalna i nie przechwytuje dotyku; ma 420 ms ruchu świetlnego, a znika krótkim crossfade (120 ms), gdy dostępność wykryje przejście z aktywności startowej DiPlay do właściwego okna/aktywności CarPlay. Cel przejścia to płynne 60 FPS, ale rzeczywista liczba klatek zależy od firmware i obciążenia MT8163.
- Nakładka rysuje subtelny półprzezroczysty welon i świetlne gradienty; nie wykonuje zrzutu ekranu ani kosztownego rozmywania całego obrazu. Nie zatrzymuje uruchamiania DiPlay. Gdy firmware nie zgłosi osobnego okna docelowego, działa bezpiecznik 5 s, aby nakładka nie została na ekranie bez końca.
- DiPlay → launcher: pozostaje krótka animacja odwrotna. Dokładna karta nadal zależy od zachowania stanu przez launcher.
- Usługa dostępności obserwuje nazwy pakietów/klas okien do synchronizacji przejścia; nie odczytuje tekstu ani zawartości okien i nie przechwytuje klawiszy.

## Pierwsze uruchomienie
Android wymaga ręcznego włączenia usługi dostępności. Po włączeniu wróć do launchera i uruchom „Szybkie przełączanie” ponownie.

## Ograniczenia
1. Aby wywołać przełączenie z DiPlay, aktywność aplikacji musi zostać uruchomiona przez dostępny skrót/przycisk w Twoim radiu.
2. Przywrócenie dokładnej karty zależy od tego, czy launcher utrzymuje swój istniejący task i nie resetuje własnego interfejsu po powrocie. Zewnętrzna aplikacja nie ma publicznego API do odczytu/ustawienia prywatnej karty launchera. `REORDER_TO_FRONT` jest próbą przywrócenia istniejącego stanu, a nie gwarancją.
3. Nakładka Liquid Glass jest lekkim efektem gradientów, nie prawdziwym dynamicznym rozmyciem treści obu aplikacji. Jej zakończenie synchronizuje się z przejściem okna na podstawie zdarzeń dostępności i heurystyki klasy/pakietu; jeśli DiPlay/firmware używa nietypowych okien, wykrycie wymaga testu na radiu. Cel 60 FPS nie jest gwarantowany przez Androida ani aplikację.
4. Pakiet DiPlay jest wykrywany po nazwie pakietu lub etykiecie zawierającej `DiPlay` i zapamiętywany po pierwszym znalezieniu.

## Budowanie
Projekt źródłowy Gradle / Android Studio. `applicationId`: `pl.essgoo.quickswitch`, `minSdk`: 28, `targetSdk`: 28. Kompilacja APK i test na radiu nie zostały wykonane w tej sesji.
