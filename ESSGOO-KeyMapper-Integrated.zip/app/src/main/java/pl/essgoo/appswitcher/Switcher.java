package pl.essgoo.appswitcher;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.text.TextUtils;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public final class Switcher {
    public static final String PREFS = "switcher_prefs";
    public static final String HOME = "__HOME__";
    private Switcher() {}

    /**
     * Acts as a toggle for the selected app (normally DiPlay):
     * - outside the target app: remember the current screen and open the target;
     * - inside the target app: bring the app/task that was underneath it back to front.
     *
     * Starting an existing app task with NEW_TASK asks Android to bring its task forward; avoid
     * RESET_TASK_IF_NEEDED because it can reset/reparent the task and lose the prior screen.
     */
    public static void perform(Context c) {
        SharedPreferences p = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String target = p.getString("target_app", "");
        if (TextUtils.isEmpty(target)) target = findDisplay(c);
        if (TextUtils.isEmpty(target) || HOME.equals(target)) {
            openHome(c);
            return;
        }

        String current = p.getString("last_seen", "");
        if (target.equals(current)) {
            String returnTo = p.getString("return_app", "");
            if (TextUtils.isEmpty(returnTo) || target.equals(returnTo)) {
                returnTo = p.getString("previous_seen", "");
            }
            openPrevious(c, returnTo, target);
            return;
        }

        // Capture the foreground app/screen before opening DiPlay. The accessibility
        // service also maintains this value, including when the user changes apps.
        if (!TextUtils.isEmpty(current) && !c.getPackageName().equals(current)
                && !target.equals(current) && !"android".equals(current)) {
            p.edit().putString("return_app", isHomePackage(c, current) ? HOME : current).apply();
        }
        openPackage(c, target);
    }

    private static void openPrevious(Context c, String packageName, String target) {
        if (TextUtils.isEmpty(packageName) || HOME.equals(packageName)) {
            openHome(c);
            return;
        }
        if (target.equals(packageName) || c.getPackageName().equals(packageName)) {
            openHome(c);
            return;
        }
        openPackage(c, packageName);
    }

    private static void openPackage(Context c, String packageName) {
        try {
            Intent launch = c.getPackageManager().getLaunchIntentForPackage(packageName);
            if (launch != null) {
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                c.startActivity(launch);
                return;
            }
        } catch (Exception ignored) { }
        openHome(c);
    }


    /** Launches/toggles one of the four user-configurable dashboard buttons. */
    public static void performConfiguredSlot(Context c, int slot) {
        SharedPreferences p = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String prefix = "slot_" + slot;
        String target = p.getString(prefix + "_app", "");
        if (TextUtils.isEmpty(target)) {
            android.widget.Toast.makeText(c, "Skonfiguruj najpierw przycisk " + slot + " w ustawieniach", android.widget.Toast.LENGTH_SHORT).show();
            c.startActivity(new Intent(c, SettingsActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            return;
        }
        if (HOME.equals(target)) {
            openHome(c);
            return;
        }
        String last = p.getString("last_seen", "");
        String returnTo = p.getString(prefix + "_return", "");
        if (target.equals(last)) {
            if (TextUtils.isEmpty(returnTo) || target.equals(returnTo)) {
                returnTo = p.getString("return_app", "");
                if (TextUtils.isEmpty(returnTo) || target.equals(returnTo)) returnTo = p.getString("previous_seen", "");
            }
            if (TextUtils.isEmpty(returnTo) || target.equals(returnTo) || c.getPackageName().equals(returnTo)) openHome(c);
            else if (HOME.equals(returnTo) || isHomePackage(c, returnTo)) openHome(c);
            else openPackage(c, returnTo);
            return;
        }
        if (!TextUtils.isEmpty(last) && !last.equals(target) && !last.equals(c.getPackageName()) && !"android".equals(last)) {
            p.edit().putString(prefix + "_return", isHomePackage(c, last) ? HOME : last).apply();
        }
        openPackage(c, target);
    }

    public static String getSlotLabel(Context c, int slot) {
        SharedPreferences p = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String value = p.getString("slot_" + slot + "_label", "");
        return TextUtils.isEmpty(value) ? "Przycisk " + slot : value;
    }

    public static boolean isHomePackage(Context c, String packageName) {
        if (TextUtils.isEmpty(packageName)) return false;
        try {
            Intent home = new Intent(Intent.ACTION_MAIN);
            home.addCategory(Intent.CATEGORY_HOME);
            android.content.pm.ResolveInfo info = c.getPackageManager().resolveActivity(home, PackageManager.MATCH_DEFAULT_ONLY);
            return info != null && info.activityInfo != null && packageName.equals(info.activityInfo.packageName);
        } catch (Exception ignored) {
            return false;
        }
    }


    public static boolean isDisplayPackage(Context c, String packageName) {
        if (TextUtils.isEmpty(packageName)) return false;
        String lowerPackage = packageName.toLowerCase(java.util.Locale.ROOT);
        if (lowerPackage.contains("diplay") || lowerPackage.contains("display")) return true;
        try {
            ApplicationInfo info = c.getPackageManager().getApplicationInfo(packageName, 0);
            String label = String.valueOf(c.getPackageManager().getApplicationLabel(info)).toLowerCase(java.util.Locale.ROOT);
            return label.contains("diplay") || label.contains("display");
        } catch (Exception ignored) { return false; }
    }

    public static String findDisplay(Context c) {
        PackageManager pm = c.getPackageManager();
        List<ApplicationInfo> apps = pm.getInstalledApplications(0);
        Collections.sort(apps, Comparator.comparing((ApplicationInfo a) -> String.valueOf(pm.getApplicationLabel(a)).toLowerCase()));
        for (ApplicationInfo app : apps) {
            String label = String.valueOf(pm.getApplicationLabel(app)).toLowerCase();
            if (label.contains("display") || label.contains("diplay")) {
                if (!app.packageName.equals(c.getPackageName())) return app.packageName;
            }
        }
        return "";
    }

    private static void openHome(Context c) {
        try {
            Intent i = new Intent(Intent.ACTION_MAIN);
            i.addCategory(Intent.CATEGORY_HOME);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            c.startActivity(i);
        } catch (Exception ignored) { }
    }
}
