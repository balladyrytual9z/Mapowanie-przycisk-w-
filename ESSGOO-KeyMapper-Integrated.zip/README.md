# ESSGOO Key Mapper + Przełącznik

Projekt Android (minSdk 28 / Android 9) do mapowania dostępnych klawiszy Androida oraz uruchamiania wybranej aplikacji z osobnego skrótu.

## Aplikacje
- **Mapowanie przycisków** — ustawienia, wybór aplikacji docelowej, motyw dzień/noc, skrót do ustawień radia i moduł mapowania.
- **Przełącznik** — skrót uruchamiający wybraną aplikację w zwykłej aktywności startowej.

## Kompilacja
Wgraj zawartość ZIP-a do repozytorium GitHub i uruchom workflow `Build ESSGOO-KeyMapper-Integrated`. Możesz też trzymać archiwum `ESSGOO-KeyMapper-Integrated.zip` w repozytorium; workflow poprzedniej wersji obsługiwał oba układy.

## Ograniczenia
Kody protokołu CarPlay nie są automatycznie androidowymi KeyEventami. Przechwytywanie klawiszy zależy od firmware i od tego, czy Android przekazuje je do AccessibilityService. Skrót do ustawień producenta otwiera aplikację ustawień ESSGOO, ale nie gwarantuje bezpośredniego przejścia do podstrony mapowania kierownicy.
