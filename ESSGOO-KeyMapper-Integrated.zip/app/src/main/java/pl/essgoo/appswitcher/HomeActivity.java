package pl.essgoo.appswitcher;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;

/** Separate launcher shortcut for radios whose factory key mapper launches apps. */
public class HomeActivity extends Activity {
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        // Leave the foreground immediately so the accessibility service can inspect
        // the actual underlying app (especially DiPlay) rather than this tiny activity.
        finish();
        overridePendingTransition(0, 0);
        new Handler().postDelayed(() -> {
            if (!AppTrackingService.performContextHome()) {
                android.content.Intent home = new android.content.Intent(android.content.Intent.ACTION_MAIN);
                home.addCategory(android.content.Intent.CATEGORY_HOME);
                home.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK);
                try { startActivity(home); } catch (Exception ignored) { }
            }
        }, 220);
    }
}
