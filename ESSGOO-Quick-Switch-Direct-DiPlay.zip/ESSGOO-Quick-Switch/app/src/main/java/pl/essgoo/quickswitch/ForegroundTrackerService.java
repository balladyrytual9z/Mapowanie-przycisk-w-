package pl.essgoo.quickswitch;

import android.accessibilityservice.AccessibilityService;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.view.animation.DecelerateInterpolator;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;

/**
 * Tracks foreground window transitions and hosts a lightweight, non-touchable glass veil.
 * It never reads window text and never filters keys.
 */
public final class ForegroundTrackerService extends AccessibilityService {
    static final String PREFS = "quick_switch_state";
    static final String LAST_PACKAGE = "last_foreground_package";
    static final String ACTION_BEGIN_CARPLAY_TRANSITION = "pl.essgoo.quickswitch.BEGIN_CARPLAY_TRANSITION";
    static final String EXTRA_TARGET_PACKAGE = "target_package";
    static final String EXTRA_LAUNCH_CLASS = "launch_class";

    private String lastWrittenPackage = "";
    private WindowManager windowManager;
    private GlassTransitionView glassView;
    private String pendingTargetPackage = "";
    private String initialLaunchClass = "";
    private boolean sawTargetWindow;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable safetyTimeout = new Runnable() {
        @Override public void run() { dismissGlass(false); }
    };

    private final BroadcastReceiver transitionReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (intent == null || !ACTION_BEGIN_CARPLAY_TRANSITION.equals(intent.getAction())) return;
            pendingTargetPackage = intent.getStringExtra(EXTRA_TARGET_PACKAGE);
            if (pendingTargetPackage == null) pendingTargetPackage = "";
            initialLaunchClass = intent.getStringExtra(EXTRA_LAUNCH_CLASS);
            if (initialLaunchClass == null) initialLaunchClass = "";
            sawTargetWindow = false;
            showGlass();
        }
    };

    @Override protected void onServiceConnected() {
        super.onServiceConnected();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        IntentFilter filter = new IntentFilter(ACTION_BEGIN_CARPLAY_TRANSITION);
        registerReceiver(transitionReceiver, filter);
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || event.getPackageName() == null) return;
        int type = event.getEventType();
        if (type != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
                && type != AccessibilityEvent.TYPE_WINDOWS_CHANGED) return;

        String packageName = event.getPackageName().toString();
        CharSequence classSequence = event.getClassName();
        String className = classSequence == null ? "" : classSequence.toString();
        if (packageName.isEmpty() || packageName.equals(getPackageName()) || isTransient(packageName)) return;

        if (!pendingTargetPackage.isEmpty()) {
            boolean targetPackage = packageName.equals(pendingTargetPackage);
            boolean likelyCarPlayWindow = className.toLowerCase(java.util.Locale.ROOT).contains("carplay")
                    || className.toLowerCase(java.util.Locale.ROOT).contains("projection");
            if (targetPackage) {
                sawTargetWindow = true;
                // DiPlay often opens its launcher/settings Activity first and then a second
                // Activity containing the actual projection UI. Finish on that window change.
                if (likelyCarPlayWindow || (type == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
                        && !initialLaunchClass.isEmpty() && !className.isEmpty()
                        && !initialLaunchClass.equals(className))) {
                    pendingTargetPackage = "";
                    dismissGlass(true);
                }
            } else if (sawTargetWindow) {
                // Some builds expose the projection UI as a separate package/process without
                // an informative class name. After DiPlay's first window was seen, the next
                // non-system foreground window is treated as the projection destination.
                pendingTargetPackage = "";
                dismissGlass(true);
            }
        }

        if (packageName.equals(lastWrittenPackage)) return;
        lastWrittenPackage = packageName;
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(LAST_PACKAGE, packageName).apply();
    }

    private void showGlass() {
        if (windowManager == null || pendingTargetPackage.isEmpty()) return;
        dismissGlass(false);
        glassView = new GlassTransitionView(this);
        glassView.setAlpha(0f);
        glassView.setTranslationY(dp(12));
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.setTitle("QuickSwitch Glass Transition");
        try {
            windowManager.addView(glassView, lp);
            final GlassTransitionView view = glassView;
            view.animate().alpha(0.88f).translationY(0f).setDuration(110L).start();
            // Safety release: no overlay may remain if this firmware does not report a
            // distinct CarPlay Activity/window. The real app launch continues underneath.
            handler.removeCallbacks(safetyTimeout);
            handler.postDelayed(safetyTimeout, 5000L);
        } catch (RuntimeException ignored) {
            glassView = null;
        }
    }

    private void dismissGlass(boolean syncedToCarPlayWindow) {
        handler.removeCallbacks(safetyTimeout);
        final GlassTransitionView old = glassView;
        glassView = null;
        if (old == null || windowManager == null) return;
        long duration = syncedToCarPlayWindow ? 120L : 100L;
        old.animate().alpha(0f).translationY(-dp(5)).setDuration(duration)
                .setListener(new AnimatorListenerAdapter() {
                    @Override public void onAnimationEnd(Animator animation) {
                        try { windowManager.removeView(old); } catch (RuntimeException ignored) { }
                    }
                }).start();
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private boolean isTransient(String pkg) {
        return pkg.equals("android")
                || pkg.equals("com.android.systemui")
                || pkg.equals("com.android.permissioncontroller")
                || pkg.equals("com.google.android.permissioncontroller")
                || pkg.contains("inputmethod")
                || pkg.contains("keyboard");
    }

    @Override public void onInterrupt() { dismissGlass(false); }

    @Override public void onDestroy() {
        handler.removeCallbacks(safetyTimeout);
        try { unregisterReceiver(transitionReceiver); } catch (Exception ignored) { }
        dismissGlass(false);
        super.onDestroy();
    }

    /** Hardware-accelerated translucent sheen; no full-screen blur or screenshot capture. */
    private static final class GlassTransitionView extends View {
        private final Paint veil = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint streak = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final float density;
        private float shimmerProgress;
        private ValueAnimator shimmerAnimator;

        GlassTransitionView(Context context) {
            super(context);
            density = getResources().getDisplayMetrics().density;
            setLayerType(View.LAYER_TYPE_HARDWARE, null);
            veil.setColor(Color.argb(38, 14, 22, 34));
            streak.setShader(new android.graphics.LinearGradient(0, 0, dp(420), 0,
                    new int[]{Color.TRANSPARENT, Color.argb(22, 225, 244, 255),
                            Color.argb(46, 225, 244, 255), Color.argb(12, 160, 205, 235), Color.TRANSPARENT},
                    new float[]{0f, 0.32f, 0.5f, 0.68f, 1f}, Shader.TileMode.CLAMP));
        }

        private float dp(float v) { return v * density; }

        @Override protected void onAttachedToWindow() {
            super.onAttachedToWindow();
            shimmerAnimator = ValueAnimator.ofFloat(0f, 1f);
            shimmerAnimator.setDuration(420L);
            shimmerAnimator.setInterpolator(new DecelerateInterpolator());
            shimmerAnimator.addUpdateListener(animation -> {
                shimmerProgress = (Float) animation.getAnimatedValue();
                invalidate();
            });
            shimmerAnimator.start();
        }

        @Override protected void onDetachedFromWindow() {
            if (shimmerAnimator != null) {
                shimmerAnimator.cancel();
                shimmerAnimator = null;
            }
            super.onDetachedFromWindow();
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float w = getWidth(), h = getHeight();
            canvas.drawRect(0, 0, w, h, veil);
            glow.setShader(new RadialGradient(w * 0.76f, h * 0.22f, Math.max(w, h) * 0.58f,
                    new int[]{Color.argb(38, 175, 220, 255), Color.argb(12, 110, 165, 220), Color.TRANSPARENT},
                    new float[]{0f, 0.48f, 1f}, Shader.TileMode.CLAMP));
            canvas.drawRect(0, 0, w, h, glow);
            glow.setShader(new RadialGradient(w * 0.18f, h * 0.88f, Math.max(w, h) * 0.48f,
                    new int[]{Color.argb(22, 130, 185, 220), Color.TRANSPARENT}, null, Shader.TileMode.CLAMP));
            canvas.drawRect(0, 0, w, h, glow);
            canvas.save();
            canvas.rotate(-8f, w / 2f, h / 2f);
            float bandX = -dp(420) + (w + dp(840)) * shimmerProgress;
            canvas.drawRect(bandX, -h, bandX + dp(420), h * 2f, streak);
            canvas.restore();
        }
    }
}
