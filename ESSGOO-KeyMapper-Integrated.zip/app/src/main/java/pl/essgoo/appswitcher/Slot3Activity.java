package pl.essgoo.appswitcher;

public class Slot3Activity extends SlotLaunchActivity {
    @Override protected int slotNumber() { return 3; }
}
