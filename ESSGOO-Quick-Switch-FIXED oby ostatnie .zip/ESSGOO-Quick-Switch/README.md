# ESSGOO Quick Switch

Android 9 / API 28+. Szybkie przełączanie DiPlay ↔ HOME z wyborem animacji przejścia.

## Funkcje

- Ekran ustawień w stylu Apple (iOS)
- 12 animacji przejścia: zanikanie, zoom, iPhone boot, Honda Reveal, CarPlay Boot, Liquid Glass, Aurora, Iskry i inne
- Usługa dostępności do rozpoznawania aplikacji na pierwszym planie
- Bezpośrednie uruchamianie CarPlayHostActivity (z fallbackiem do launchera)

## Build

```bash
gradle --no-daemon assembleRelease
```

Wymaga JDK 17, Android SDK 35, Build Tools 35.0.0, Gradle 8.9.

## Użycie

1. Zainstaluj APK
2. Włącz usługę dostępności „Szybkie przełączanie”
3. Otwórz aplikację → wybierz animację → naciśnij **Przełącz DiPlay**
