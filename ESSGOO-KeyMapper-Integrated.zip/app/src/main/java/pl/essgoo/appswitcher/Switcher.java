package pl.essgoo.appswitcher;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.text.TextUtils;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public final class Switcher {
    public static final String PREFS = "switcher_prefs";
    public static final String HOME = "__HOME__";
    private Switcher() {}

    public static void perform(Context c) {
        SharedPreferences p = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String target = p.getString("target_app", "");
        if (TextUtils.isEmpty(target)) target = findDisplay(c);
        if (TextUtils.isEmpty(target) || HOME.equals(target)) { openHome(c); return; }
        try {
            Intent launch = c.getPackageManager().getLaunchIntentForPackage(target);
            if (launch != null) {
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
                c.startActivity(launch);
                return;
            }
        } catch (Exception ignored) { }
        openHome(c);
    }

    public static String findDisplay(Context c) {
        PackageManager pm = c.getPackageManager();
        List<ApplicationInfo> apps = pm.getInstalledApplications(0);
        Collections.sort(apps, Comparator.comparing((ApplicationInfo a) -> String.valueOf(pm.getApplicationLabel(a)).toLowerCase()));
        for (ApplicationInfo app : apps) {
            String label = String.valueOf(pm.getApplicationLabel(app)).toLowerCase();
            if (label.contains("display") || label.contains("diplay")) {
                if (!app.packageName.equals(c.getPackageName())) return app.packageName;
            }
        }
        return "";
    }
    private static void openHome(Context c) {
        try {
            Intent i = new Intent(Intent.ACTION_MAIN);
            i.addCategory(Intent.CATEGORY_HOME);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            c.startActivity(i);
        } catch (Exception ignored) { }
    }
}
