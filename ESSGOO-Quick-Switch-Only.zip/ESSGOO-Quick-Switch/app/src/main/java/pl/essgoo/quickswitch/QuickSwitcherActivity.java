package pl.essgoo.quickswitch;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.widget.Toast;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/** Fixed one-action switcher: launcher -> DiPlay; DiPlay -> Android HOME/launcher. */
public final class QuickSwitcherActivity extends Activity {
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        try {
            if (!isTrackerEnabled()) {
                Toast.makeText(this, "Włącz usługę dostępności „Szybkie przełączanie”, aby rozpoznawać DiPlay.", Toast.LENGTH_LONG).show();
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                finish();
                overridePendingTransition(0, 0);
                return;
            }
            performSwitch();
        } catch (Exception e) {
            Toast.makeText(this, "Nie udało się przełączyć aplikacji.", Toast.LENGTH_SHORT).show();
        }
        finish();
        overridePendingTransition(0, 0);
    }

    private void performSwitch() {
        String displayPackage = findDiPlayPackage();
        if (TextUtils.isEmpty(displayPackage)) {
            Toast.makeText(this, "Nie znaleziono aplikacji DiPlay.", Toast.LENGTH_SHORT).show();
            return;
        }

        String last = getSharedPreferences(ForegroundTrackerService.PREFS, MODE_PRIVATE)
                .getString(ForegroundTrackerService.LAST_PACKAGE, "");

        if (displayPackage.equals(last)) {
            // Use Android HOME rather than the launch intent of the launcher. This gives
            // the existing launcher task a chance to resume in-place on its prior card.
            Intent home = new Intent(Intent.ACTION_MAIN);
            home.addCategory(Intent.CATEGORY_HOME);
            home.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(home);
        } else {
            Intent launch = getPackageManager().getLaunchIntentForPackage(displayPackage);
            if (launch == null) {
                Toast.makeText(this, "Nie można otworzyć DiPlay.", Toast.LENGTH_SHORT).show();
                return;
            }
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(launch);
        }
    }

    private String findDiPlayPackage() {
        PackageManager pm = getPackageManager();
        List<ApplicationInfo> apps = pm.getInstalledApplications(0);
        Collections.sort(apps, Comparator.comparing(a -> String.valueOf(pm.getApplicationLabel(a)).toLowerCase(Locale.ROOT)));
        for (ApplicationInfo app : apps) {
            if (app.packageName.equals(getPackageName())) continue;
            String pkg = app.packageName.toLowerCase(Locale.ROOT);
            String label = String.valueOf(pm.getApplicationLabel(app)).toLowerCase(Locale.ROOT);
            if (pkg.contains("diplay") || label.contains("diplay")) return app.packageName;
        }
        // Some vendor builds display the app under a generic name; use a conservative
        // fallback only when the package identifier itself contains the known name.
        return "";
    }

    private boolean isTrackerEnabled() {
        String expected = new ComponentName(this, ForegroundTrackerService.class).flattenToString();
        String enabled = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (TextUtils.isEmpty(enabled)) return false;
        TextUtils.SimpleStringSplitter splitter = new TextUtils.SimpleStringSplitter(':');
        splitter.setString(enabled);
        while (splitter.hasNext()) {
            String item = splitter.next();
            if (expected.equalsIgnoreCase(item) || item.equalsIgnoreCase(expected.replace('/', '\\'))) return true;
        }
        return false;
    }
}
