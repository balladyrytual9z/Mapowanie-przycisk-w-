package pl.essgoo.quickswitch;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/** iOS-style settings screen with animation picker and switch button. */
public final class SettingsActivity extends Activity {

    private LinearLayout animList;
    private TextView txtStatus;
    private View cardAccessibility;
    private int selected;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        animList = findViewById(R.id.anim_list);
        txtStatus = findViewById(R.id.txt_status);
        cardAccessibility = findViewById(R.id.card_accessibility);
        Button btnSwitch = findViewById(R.id.btn_switch);
        Button btnAcc = findViewById(R.id.btn_accessibility);

        selected = SwitchHelper.getSelectedAnimation(this);
        buildAnimationRows();

        btnSwitch.setOnClickListener(v -> performSwitch());
        btnAcc.setOnClickListener(v ->
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
    }

    @Override protected void onResume() {
        super.onResume();
        refreshStatus();
    }

    private void refreshStatus() {
        boolean tracker = SwitchHelper.isTrackerEnabled(this);
        cardAccessibility.setVisibility(tracker ? View.GONE : View.VISIBLE);

        String display = SwitchHelper.findDiPlayPackage(this);
        if (display.isEmpty()) {
            txtStatus.setText("DiPlay nie został znaleziony na urządzeniu.");
            txtStatus.setTextColor(0xFFFF3B30);
        } else if (!tracker) {
            txtStatus.setText("Włącz usługę dostępności, aby przełączanie działało poprawnie.");
            txtStatus.setTextColor(0xFFFF9500);
        } else {
            boolean onDiPlay = SwitchHelper.shouldGoHome(this);
            txtStatus.setText(onDiPlay
                    ? "DiPlay aktywny · kolejne przełączenie wróci do HOME"
                    : "Gotowy · pakiet: " + display);
            txtStatus.setTextColor(0xFF8E8E93);
        }
    }

    private void buildAnimationRows() {
        animList.removeAllViews();
        int[] types = AnimationType.ALL;
        for (int i = 0; i < types.length; i++) {
            final int type = types[i];
            View row = getLayoutInflater().inflate(R.layout.item_animation_row, animList, false);
            TextView title = row.findViewById(R.id.row_title);
            ImageView check = row.findViewById(R.id.row_check);
            title.setText(AnimationType.label(type));
            check.setVisibility(type == selected ? View.VISIBLE : View.GONE);

            // Separator line between rows
            if (i > 0) {
                View sep = new View(this);
                sep.setBackgroundColor(0xFFC6C6C8);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, 1);
                lp.setMarginStart(16);
                animList.addView(sep, lp);
            }

            row.setOnClickListener(v -> {
                selected = type;
                SwitchHelper.setSelectedAnimation(this, type);
                buildAnimationRows();
            });
            animList.addView(row);
        }
    }

    private void performSwitch() {
        if (!SwitchHelper.isTrackerEnabled(this)) {
            Toast.makeText(this, "Włącz usługę dostępności „Szybkie przełączanie”.", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            return;
        }
        String display = SwitchHelper.findDiPlayPackage(this);
        if (display.isEmpty()) {
            Toast.makeText(this, "Nie znaleziono aplikacji DiPlay.", Toast.LENGTH_SHORT).show();
            return;
        }

        int anim = SwitchHelper.getSelectedAnimation(this);
        if (anim == AnimationType.NONE) {
            // Direct switch without overlay
            doDirectSwitch(display);
            return;
        }

        Intent overlay = new Intent(this, AnimationOverlayActivity.class);
        overlay.putExtra(AnimationOverlayActivity.EXTRA_ANIM, anim);
        overlay.putExtra(AnimationOverlayActivity.EXTRA_PACKAGE, display);
        overlay.putExtra(AnimationOverlayActivity.EXTRA_GO_HOME, SwitchHelper.shouldGoHome(this));
        startActivity(overlay);
        overridePendingTransition(0, 0);
    }

    private void doDirectSwitch(String displayPackage) {
        try {
            if (SwitchHelper.shouldGoHome(this)) {
                startActivity(SwitchHelper.buildHomeIntent());
            } else {
                Intent launch = SwitchHelper.buildDiPlayIntent(this, displayPackage);
                if (launch == null) {
                    Toast.makeText(this, "DiPlay nie udostępnia ekranu do uruchomienia.", Toast.LENGTH_LONG).show();
                    return;
                }
                startActivity(launch);
            }
            overridePendingTransition(0, 0);
        } catch (Exception e) {
            Toast.makeText(this, "Nie udało się przełączyć.", Toast.LENGTH_SHORT).show();
        }
    }
}
