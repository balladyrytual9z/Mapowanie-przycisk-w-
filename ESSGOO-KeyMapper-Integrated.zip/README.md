# ESSGOO Key Mapper + Przełącznik

Projekt Android (minSdk 28 / Android 9) do mapowania dostępnych klawiszy Androida oraz uruchamiania wybranej aplikacji z osobnego skrótu.

## Aplikacje
- **Mapowanie przycisków** — ustawienia, wybór aplikacji docelowej, motyw dzień/noc, skrót do ustawień radia i moduł mapowania.
- **Przełącznik** — działa jak przełącznik kontekstowy: poza DiPlay zapamiętuje bieżącą aplikację i otwiera DiPlay; uruchomiony ponownie w DiPlay wraca do poprzedniej aplikacji/zadania, o ile Android i sama aplikacja na to pozwalają.
- **Ekran główny** — drugi skrót, który wykonuje kontekstową akcję Home. Jest też automatycznie wywoływany przez androidowy `KEYCODE_1` (cyfra 1) oraz `KEYCODE_NUMPAD_1`, gdy usługa dostępności jest aktywna i opcja jest włączona. Poza DiPlay uruchamia Home Androida/launchera. W DiPlay próbuje kliknąć dostępny semantyczny przycisk Home/Dashboard. Nie używa Wstecz jako zamiennika, bo może opuścić CarPlay zamiast wrócić na jego stronę główną.

## Kompilacja
Wgraj zawartość ZIP-a do repozytorium GitHub i uruchom workflow `Build ESSGOO-KeyMapper-Integrated`. Możesz też trzymać archiwum `ESSGOO-KeyMapper-Integrated.zip` w repozytorium; workflow obsługuje oba układy.

## Ograniczenia
Kody protokołu CarPlay nie są automatycznie androidowymi KeyEventami. Przechwytywanie klawiszy zależy od firmware i od tego, czy Android przekazuje je do AccessibilityService. Skrót do ustawień producenta otwiera aplikację ustawień ESSGOO, ale nie gwarantuje bezpośredniego przejścia do podstrony mapowania kierownicy.


## Ważne dla przycisku 1
Android nie daje zwykłej aplikacji bez roota gwarantowanej metody wysłania dowolnego klawisza do innej aplikacji. Dlatego wejście do CarPlay Home zależy od tego, czy dISplay udostępnia dostępny przycisk Home/Dashboard albo czy jego obsługa Wstecz wraca do ekranu głównego CarPlay. Cyfra 1 jest przechwytywana globalnie, więc wyłącz tę opcję w Mapowaniu przycisków, jeśli potrzebujesz wpisywać cyfrę 1 na klawiaturze.

## BtnHome = 200: istotne ograniczenie techniczne

`CarPlayProtocol.BTN_HOME` ma wartość `200`, zgodnie z publicznymi implementacjami protokołu CarPlay. To identyfikator zdarzenia protokołu, a nie androidowy `KeyEvent`. Osobna aplikacja Android nie może sama wstrzyknąć tego zdarzenia do aktywnej sesji CarPlay w DiPlay bez obsługi po stronie DiPlay (np. publicznego API, broadcast receivera lub zmiany kodu samego odbiornika). Dlatego przycisk „1” działa w launcherze przez systemowe Home, a w DiPlay używa dostępnego semantycznego przycisku Home, jeśli jest wystawiony w drzewie dostępności. Gdy go nie ma, aplikacja informuje o ograniczeniu i nie symuluje Wstecz.

## Zakres tego archiwum a właściwy launcher

To repozytorium jest aplikacją pomocniczą do mapowania klawiszy i uruchamiania aplikacji; nie zawiera kodu właściwego launchera (pulpitu, pagera, szuflady aplikacji ani Docka). Dlatego nie dodano mu po cichu kategorii `CATEGORY_HOME` ani nie zastąpiono istniejącego launchera pustym ekranem. Funkcje Persistent Dock, strony pulpitu, App Drawer/Search/Settings oraz hierarchia `BackHandler` muszą być wprowadzone do źródłowego projektu launchera.

Właściwy punkt protokołu dla powrotu na stronę główną CarPlay to `CarPlayProtocol.BTN_HOME = 200`. W tym projekcie przycisk „1” korzysta z systemowego Home poza DiPlay i próbuje uruchomić widoczny semantyczny przycisk Home/Dashboard wewnątrz DiPlay (po etykiecie, opisie lub identyfikatorze zasobu). Jeśli DiPlay nie wystawia takiego węzła, zewnętrzna aplikacja nie ma bezpośredniego dostępu do prywatnego kanału protokołu CarPlay. Aby wysyłać `BtnHome=200` niezawodnie, potrzebna jest zmiana w DiPlay lub jego udokumentowane API.


## Co jest faktycznie obsługiwane przez tę osobną aplikację

- Skrót **Przełącznik** przełącza między wybraną aplikacją docelową (domyślnie wykrywaną jako DiPlay) a ostatnią zapamiętaną aplikacją. Przy powrocie uruchamiany jest istniejący task aplikacji, jeśli Android go zachował; system nie udostępnia zwykłej aplikacji bez roota gwarantowanego dostępu do dokładnego poprzedniego okna/tasku.
- **Mapowanie klawiszy Androida** zapisuje przypisania według rzeczywistego `KeyEvent` i wykonuje obsługiwane akcje z usługi dostępności: Home, Back, Recents, przełącznik, media, głośność i motyw. Lista zapisanych mapowań i opcja usunięcia wszystkich są w ekranie mapowania.
- **Mapowanie kodów CarPlay** pozwala zapisać lokalne przypisanie dla wybranego wpisu protokołu. To konfiguracja referencyjna: zewnętrzna aplikacja nie odbiera automatycznie zdarzeń z prywatnego kanału DiPlay i nie może sama wyemitować `BtnHome=200` do tej sesji. Żeby te mapowania protokołu wykonywały akcje w DiPlay, potrzebny jest interfejs integracyjny po stronie DiPlay.
- Projekt **nie jest launcherem**: nie rejestruje `CATEGORY_HOME`, nie zastępuje pulpitu i nie implementuje Docka/pulpitu/szuflady aplikacji. Działa obok istniejącego launchera jako aplikacja pomocnicza z osobnymi skrótami.

## Sprawdzenie

Workflow GitHub Actions buduje APK przez `gradle assembleDebug`. W tym środowisku nie ma zainstalowanego Gradle ani Android SDK, więc lokalnie sprawdzono strukturę archiwum i poprawność XML, ale kompilacja APK i test na radiu wymagają uruchomienia workflow i instalacji wyniku na urządzeniu.

## Dashboard i cztery własne przyciski

- W szufladzie/menu aplikacji dostępny jest kafelek **ESSGOO Control Center**, który otwiera pełne menu pomocniczej aplikacji.
- Jest też osobny kafelek **Ustawienia przycisków**, aby można było wejść bezpośrednio do konfiguracji.
- Menu zawiera cztery przyciski. W ustawieniach każdego można niezależnie zmienić widoczną nazwę oraz wybrać aplikację docelową z listy aplikacji uruchamialnych albo ekran główny Androida.
- Po zapisaniu ustawień menu pokazuje własną nazwę i wybraną aplikację. Kliknięcie przycisku uruchamia wybrany cel; ponowne kliknięcie, gdy cel jest rozpoznany jako ostatnia aplikacja na pierwszym planie, próbuje wrócić do zapisanego ekranu źródłowego.
- Zmiana nazwy dotyczy przycisku w tym menu, nie zmienia globalnej nazwy ani ikony aplikacji w Androidzie.
