package pl.essgoo.appswitcher;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;
import android.view.KeyEvent;
import android.content.SharedPreferences;
import android.content.Intent;
import android.media.AudioManager;

public class AppTrackingService extends AccessibilityService {
    private static volatile AppTrackingService instance;

    @Override public void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
    }

    public static boolean performContextHome() {
        AppTrackingService service = instance;
        if (service == null) return false;
        HomeAction.perform(service);
        return true;
    }
    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || event.getPackageName() == null) return;
        int type = event.getEventType();
        if (type != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && type != AccessibilityEvent.TYPE_WINDOWS_CHANGED) return;

        String pkg = event.getPackageName().toString();
        // Ignore transient system overlays (status bar, keyboard, permission UI).
        // They can become the accessibility event source while DiPlay or the launcher
        // remains the actual app underneath; recording them would corrupt the return target.
        if (pkg.equals(getPackageName()) || isTransientSystemPackage(pkg)) return;

        SharedPreferences p = getSharedPreferences(Switcher.PREFS, MODE_PRIVATE);
        String target = p.getString("target_app", "");
        if (target.isEmpty()) target = Switcher.findDisplay(this);
        String current = p.getString("last_seen", "");
        if (pkg.equals(current)) return;

        SharedPreferences.Editor edit = p.edit().putString("previous_seen", current).putString("last_seen", pkg);
        if (!target.isEmpty() && pkg.equals(target)) {
            // Each transition into the target refreshes the return destination, so an old
            // session cannot leave a stale app stored as the destination.
            if (!current.isEmpty() && !current.equals(target) && !current.equals(getPackageName())
                    && !"android".equals(current)) {
                edit.putString("return_app", Switcher.isHomePackage(this, current) ? Switcher.HOME : current);
            }
        } else {
            // Keep the last foreground package as the best available return destination.
            edit.putString("return_app", Switcher.isHomePackage(this, pkg) ? Switcher.HOME : pkg);
        }
        edit.apply();
    }

    private boolean isTransientSystemPackage(String pkg) {
        if (pkg == null) return true;
        return pkg.equals("android")
                || pkg.equals("com.android.systemui")
                || pkg.equals("com.android.permissioncontroller")
                || pkg.equals("com.google.android.permissioncontroller")
                || pkg.contains("inputmethod")
                || pkg.contains("keyboard");
    }

    @Override public boolean onKeyEvent(KeyEvent event) {
        if(event==null || event.getAction()!=KeyEvent.ACTION_DOWN || event.getRepeatCount()>0) return false;
        SharedPreferences p=getSharedPreferences(Switcher.PREFS,MODE_PRIVATE); int code=event.getKeyCode();
        if(p.getBoolean("capture_key",false)) { p.edit().putBoolean("capture_key",false).putInt("captured_key_code",code).putString("captured_key_name",KeyEvent.keyCodeToString(code)).apply(); return true; }
        // Context-aware Home defaults to the physical/keyboard digit 1. The user may
        // reassign it from the key-listener UI. When no custom Home key was saved,
        // NUMPAD_1 is accepted as an equivalent fallback. Home takes precedence over
        // generic mappings so the two actions cannot accidentally collide.
        int homeTrigger = p.getInt("home_trigger_key", KeyEvent.KEYCODE_1);
        boolean customHomeTrigger = p.contains("home_trigger_key");
        if (code == homeTrigger || (!customHomeTrigger && code == KeyEvent.KEYCODE_NUMPAD_1)) {
            HomeAction.perform(this);
            return true;
        }
        // Quick switcher remains a separate launcher/system action and configurable key.
        int switcherTrigger = p.getInt("switcher_trigger_key", -1);
        if (switcherTrigger >= 0 && code == switcherTrigger) { Switcher.perform(this); return true; }
        String action=p.getString("hardware_"+code,"NONE"); if("NONE".equals(action)) return false;
        performAction(action); return true;
    }
    private void performAction(String action){
        if("HOME".equals(action)) performGlobalAction(GLOBAL_ACTION_HOME);
        else if("BACK".equals(action)) performGlobalAction(GLOBAL_ACTION_BACK);
        else if("RECENTS".equals(action)) performGlobalAction(GLOBAL_ACTION_RECENTS);
        else if("SWITCHER".equals(action) || "OPEN_DISPLAY".equals(action)) Switcher.perform(this);
        else if("TOGGLE_THEME".equals(action)) { SharedPreferences p=getSharedPreferences(Switcher.PREFS,MODE_PRIVATE); p.edit().putString("theme", "DARK".equals(p.getString("theme","SYSTEM")) ? "DAY" : "DARK").apply(); }
        else if("PLAY_PAUSE".equals(action)) media(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE);
        else if("NEXT_TRACK".equals(action)) media(KeyEvent.KEYCODE_MEDIA_NEXT);
        else if("PREVIOUS_TRACK".equals(action)) media(KeyEvent.KEYCODE_MEDIA_PREVIOUS);
        else if("VOLUME_UP".equals(action)) { AudioManager a=(AudioManager)getSystemService(AUDIO_SERVICE); if(a!=null)a.adjustVolume(AudioManager.ADJUST_RAISE,AudioManager.FLAG_SHOW_UI); }
        else if("VOLUME_DOWN".equals(action)) { AudioManager a=(AudioManager)getSystemService(AUDIO_SERVICE); if(a!=null)a.adjustVolume(AudioManager.ADJUST_LOWER,AudioManager.FLAG_SHOW_UI); }
    }
    private void media(int key){Intent i=new Intent(Intent.ACTION_MEDIA_BUTTON);i.putExtra(Intent.EXTRA_KEY_EVENT,new KeyEvent(KeyEvent.ACTION_DOWN,key));sendOrderedBroadcast(i,null);i.putExtra(Intent.EXTRA_KEY_EVENT,new KeyEvent(KeyEvent.ACTION_UP,key));sendOrderedBroadcast(i,null);}
    @Override public void onInterrupt() { if (instance == this) instance = null; }
}
