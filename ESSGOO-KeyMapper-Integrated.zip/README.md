# ESSGOO App Switcher (Android 9 / API 28 / ARMv7)

Projekt zawiera dwie pozycje w launcherze, zbudowane w jednym APK:

- **Przełącz aplikację** – szybki przycisk bez własnego interfejsu; uruchomienie przełącza aplikację i natychmiast zamyka aktywność.
- **Ustawienia przełącznika** – osobny ekran ustawień w ciemnym, samochodowym stylu inspirowanym ogólnymi zasadami interfejsu CarPlay.

## Tryby

1. **Ostatnie dwie aplikacje** – wraca do poprzedniej wykrytej aplikacji.
2. **Dwie wybrane akcje** – przełącza pomiędzy dwoma celami, np. ekran główny i dISplay. Wybierz dISplay z listy aplikacji; nazwa pakietu nie jest zakodowana na sztywno.

## Budowanie przez GitHub Actions

1. Utwórz repozytorium GitHub i wgraj zawartość ZIP-a.
2. Wejdź w **Actions** → **Build ESSGOO App Switcher APK** → **Run workflow**.
3. Po zakończeniu otwórz przebieg i pobierz artefakt **ESSGOO-App-Switcher-APK**.
4. Rozpakuj artefakt i zainstaluj `app-debug.apk` na radiu.

Workflow jest w `.github/workflows/build.yml`.

## Konfiguracja na radiu

1. Otwórz **Ustawienia przełącznika**.
2. Wybierz tryb i ustaw akcje A/B, jeśli korzystasz z trybu pary.
3. Naciśnij **Włącz dostęp do użycia aplikacji**.
4. Na ekranie Dostępność Androida znajdź **Przełącznik aplikacji** i włącz usługę.
5. Wróć do ustawień i przetestuj przycisk.

## Ograniczenia Androida

- To zwykła aplikacja bez roota. Android nie udostępnia jej pełnego, natywnego API Alt+Tab; usługa Dostępności śledzi zdarzenia zmiany okna, a aplikacja uruchamia aktywność poprzedniego celu.
- Niektóre aplikacje mogą być chronione, nie mieć zwykłego ekranu startowego lub odtwarzać się od początku zamiast wrócić do dokładnie tego samego okna.
- Dostępność trzeba włączyć ręcznie. Android może wyłączyć usługę po awarii lub aktualizacji.
- Dwie pozycje w launcherze są aktywnościami jednego APK, a nie dwoma niezależnymi pakietami. Dla użytkownika są widoczne jako osobne ikony.
- Projekt ma `minSdk 28`, `targetSdk 28` i nie wymaga bibliotek natywnych, więc jest odpowiedni dla Androida 9 i ARMv7.

## Testy

Kod i workflow przygotowano, ale kompilacja w GitHub Actions oraz działanie na konkretnym firmware ESSGOO wymagają uruchomienia i testu na urządzeniu. Jeśli Gradle zgłosi błąd, wklej pełny log z Actions.


## Część 2: mapowanie klawiszy (ESSGOO)

Dodano osobną aktywność „Mapowanie przycisków” jako ikonę w launcherze. Pozwala wybrać kody z listy CarPlay i zapisać przypisaną akcję, a także uruchomić nasłuch następnego androidowego `KeyEvent` i przypisać przechwycony klawisz do akcji. Dostępne akcje: Home, Wstecz, Ostatnie aplikacje, przełącznik aplikacji, play/pause, następny/poprzedni utwór oraz głośność.

**Ważne ograniczenie techniczne:** liczby `CarPlayType` (np. `BtnHome=200`) są kodami protokołu, a nie kodami `android.view.KeyEvent`. Android nie dostarcza tych kodów do zwykłej aplikacji automatycznie. Zapisanie mapowania protokołu jest konfiguracją, ale będzie działać dopiero po dodaniu integracji, która faktycznie przekazuje zdarzenia z dISplay/protokołu do aplikacji (np. broadcast/Intent lub API udostępnione przez dISplay). Ta aplikacja nie podszywa się pod implementację protokołu CarPlay.

Nasłuch fizycznych klawiszy wymaga włączenia usługi „Przełącznik aplikacji” w Ustawienia > Dostępność. Klawisze przechwytywane przez firmware radia, sterownik MCU albo inną aplikację mogą nie być widoczne. Bez roota aplikacja nie może dowolnie wstrzykiwać klawiszy do innych aplikacji; realizuje tylko jawnie obsługiwane akcje systemowe i multimedialne.


## Układ aplikacji (wersja zintegrowana)

W launcherze są dwie osobne ikony:
- **Przełącz aplikację** — lekka aktywność uruchamiająca przełączanie aplikacji.
- **Mapowanie przycisków** — aplikacja ustawień z ikoną kierownicy. Z jej ekranu otwiera się panel mapowania kodów CarPlay i nasłuchu fizycznych klawiszy. Ekran mapowania nie jest osobną pozycją w launcherze.

Ikona kierownicy jest wektorowa, więc nie wymaga dużych bitmap. Kompilacja i działanie na fizycznym ESSGOO nadal wymagają testów.
