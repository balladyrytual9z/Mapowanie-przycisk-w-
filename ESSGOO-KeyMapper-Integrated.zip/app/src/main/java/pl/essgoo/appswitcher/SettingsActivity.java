package pl.essgoo.appswitcher;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.content.SharedPreferences;
import android.provider.Settings;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.widget.*;
import java.util.*;

public class SettingsActivity extends Activity {
    private SharedPreferences prefs; private Spinner appSpinner; private Switch themeSwitch; private TextView themeStatus;
    private final ArrayList<String> ids=new ArrayList<>(), labels=new ArrayList<>();
    private int bg,surface,fg,muted,accent,stroke;
    @Override public void onCreate(Bundle b){super.onCreate(b);prefs=getSharedPreferences(Switcher.PREFS,MODE_PRIVATE);applyColors();build();}
    private void applyColors(){String t=prefs.getString("theme","SYSTEM");boolean dark="DARK".equals(t)||("SYSTEM".equals(t)&&(getResources().getConfiguration().uiMode&0x30)==0x20);bg=dark?Color.rgb(8,12,19):Color.rgb(239,243,249);surface=dark?Color.rgb(24,31,43):Color.WHITE;fg=dark?Color.rgb(246,249,255):Color.rgb(20,29,45);muted=dark?Color.rgb(158,173,194):Color.rgb(96,111,132);accent=dark?Color.rgb(82,166,255):Color.rgb(0,112,245);stroke=dark?Color.rgb(48,62,81):Color.rgb(220,228,239);}
    private void build(){
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setClipToPadding(false);scroll.setBackgroundColor(bg);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(22),dp(22),dp(22),dp(32));scroll.addView(root);
        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);top.setOrientation(LinearLayout.HORIZONTAL);
        TextView logo=label("⌘",26,Color.WHITE,true);logo.setGravity(Gravity.CENTER);logo.setBackground(round(accent,dp(17),accent));top.addView(logo,new LinearLayout.LayoutParams(dp(52),dp(52)));
        LinearLayout heading=new LinearLayout(this);heading.setOrientation(1);heading.setPadding(dp(13),0,0,0);heading.addView(label("ESSGOO  ·  CONTROL CENTER",11,accent,true));heading.addView(label("Mapowanie przycisków",25,fg,true),lp(-1,-2,3));top.addView(heading,new LinearLayout.LayoutParams(0,-2,1));root.addView(top);
        root.addView(label("Twoje sterowanie. Prosto, czytelnie i gotowe do jazdy.",14,muted,false),lp(-1,-2,12));

        LinearLayout hero=card(root,0);hero.setPadding(dp(18),dp(18),dp(18),dp(18));
        LinearLayout heroRow=new LinearLayout(this);heroRow.setGravity(Gravity.CENTER_VERTICAL);hero.addView(heroRow);
        TextView wheel=label("◉",31,accent,true);wheel.setGravity(Gravity.CENTER);wheel.setBackground(round(tint(accent,0.13f),dp(18),tint(accent,0.13f)));heroRow.addView(wheel,new LinearLayout.LayoutParams(dp(62),dp(62)));
        LinearLayout heroText=new LinearLayout(this);heroText.setOrientation(1);heroText.setPadding(dp(14),0,0,0);heroText.addView(label("Twoje przyciski",19,fg,true));heroText.addView(label("Szybki dostęp do mapowania i akcji",13,muted,false),lp(-1,-2,4));heroRow.addView(heroText,new LinearLayout.LayoutParams(0,-2,1));
        TextView mapping=actionButton("Otwórz mapowanie",true);hero.addView(mapping,lp(-1,dp(50),16));mapping.setOnClickListener(v->startActivity(new Intent(this,MappingActivity.class)));

        section(root,"APLIKACJA DOCELOWA","Wybierz, co ma otwierać skrót Przełącznik.");
        LinearLayout appCard=card(root,10);appCard.addView(label("OTWIERAJ APLIKACJĘ",11,muted,true));loadApps();appSpinner=new Spinner(this);appSpinner.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,labels));String chosen=prefs.getString("target_app","");if(chosen.isEmpty())chosen=Switcher.findDisplay(this);int idx=ids.indexOf(chosen);appSpinner.setSelection(idx<0?0:idx);appSpinner.setBackgroundTintList(android.content.res.ColorStateList.valueOf(accent));appCard.addView(appSpinner,lp(-1,dp(48),5));
        TextView save=actionButton("Zapisz wybór",true);appCard.addView(save,lp(-1,dp(46),9));save.setOnClickListener(v->{int n=appSpinner.getSelectedItemPosition();String id=ids.get(n);prefs.edit().putString("target_app",id).apply();Toast.makeText(this,"Zapisano: "+labels.get(n),Toast.LENGTH_SHORT).show();});
        TextView test=actionButton("Uruchom aplikację teraz  ›",false);appCard.addView(test,lp(-1,dp(44),7));test.setOnClickListener(v->{prefs.edit().putString("target_app",ids.get(appSpinner.getSelectedItemPosition())).apply();Switcher.perform(this);});

        section(root,"CZTERY KONFIGUROWALNE PRZYCISKI","Każdy przycisk ma własną nazwę i własną aplikację docelową. Ponowne użycie przycisku próbuje wrócić do zapisanego ekranu źródłowego.");
        for(int slot=1;slot<=4;slot++) addSlotConfig(root,slot);

        section(root,"WYGLĄD","Dopasuj interfejs do jasnego lub ciemnego kokpitu.");LinearLayout themeCard=card(root,10);
        LinearLayout themeRow=new LinearLayout(this);themeRow.setGravity(Gravity.CENTER_VERTICAL);themeRow.setOrientation(LinearLayout.HORIZONTAL);themeCard.addView(themeRow);
        LinearLayout themeCopy=new LinearLayout(this);themeCopy.setOrientation(1);themeCopy.addView(label("Tryb nocny",16,fg,true));themeStatus=label("Dostosuj jasność interfejsu",12,muted,false);themeCopy.addView(themeStatus,lp(-1,-2,3));themeRow.addView(themeCopy,new LinearLayout.LayoutParams(0,-2,1));
        themeSwitch=new Switch(this);themeSwitch.setChecked("DARK".equals(prefs.getString("theme","SYSTEM")));themeRow.addView(themeSwitch);themeSwitch.setOnCheckedChangeListener((button,checked)->{prefs.edit().putString("theme",checked?"DARK":"DAY").apply();themeStatus.setText(checked?"Ciemny interfejs aktywny":"Jasny interfejs aktywny");button.postDelayed(this::recreate,140);});
        TextView system=actionButton("Użyj motywu systemowego",false);themeCard.addView(system,lp(-1,dp(42),12));system.setOnClickListener(v->{prefs.edit().putString("theme","SYSTEM").apply();recreate();});

        section(root,"USTAWIENIA RADIA","Otwórz panel producenta, aby znaleźć konfigurację przycisków kierownicy.");LinearLayout radioCard=card(root,10);radioCard.addView(label("FABRYCZNE USTAWIENIA ESSGOO",11,muted,true));TextView wheelSettings=actionButton("Ustawienia radia  ›",false);radioCard.addView(wheelSettings,lp(-1,dp(48),9));wheelSettings.setOnClickListener(v->openWheelSettings());
        section(root,"UPRAWNIENIA","Potrzebne tylko do obsługi klawiszy przekazywanych przez Androida.");LinearLayout accessCard=card(root,10);accessCard.addView(label("Usługa dostępności",16,fg,true));accessCard.addView(label("Bez roota. Przyciski przejęte bezpośrednio przez firmware mogą nie być widoczne dla aplikacji.",13,muted,false),lp(-1,-2,5));TextView access=actionButton("Otwórz ustawienia dostępności",false);accessCard.addView(access,lp(-1,dp(46),10));access.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        root.addView(label("Android 9  ·  lokalna konfiguracja  ·  bez roota",12,muted,false),lp(-1,-2,20));setContentView(scroll);animateChildren(root);
    }

    private void addSlotConfig(LinearLayout root,int slot){
        final int number=slot; String prefix="slot_"+number;
        LinearLayout slotCard=card(root,10);
        LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setOrientation(LinearLayout.HORIZONTAL);slotCard.addView(row);
        TextView numberView=label(String.format(Locale.getDefault(),"%02d",number),17,accent,true);numberView.setGravity(Gravity.CENTER);numberView.setBackground(round(tint(accent,0.13f),dp(14),stroke));row.addView(numberView,new LinearLayout.LayoutParams(dp(48),dp(48)));
        LinearLayout info=new LinearLayout(this);info.setOrientation(1);info.setPadding(dp(12),0,0,0);info.addView(label("PRZYCISK "+number,11,muted,true));info.addView(label("Własna nazwa + aplikacja",14,fg,true),lp(-1,-2,3));row.addView(info,new LinearLayout.LayoutParams(0,-2,1));
        EditText name=new EditText(this);name.setSingleLine(true);name.setTextSize(15);name.setTextColor(fg);name.setHintTextColor(muted);name.setHint("Nazwa przycisku "+number);name.setPadding(dp(12),dp(7),dp(12),dp(7));name.setBackground(round(bg,dp(12),stroke));name.setText(prefs.getString(prefix+"_label","Przycisk "+number));slotCard.addView(name,lp(-1,dp(48),12));
        Spinner target=new Spinner(this);target.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,labels));String selected=prefs.getString(prefix+"_app","");int idx=ids.indexOf(selected);target.setSelection(idx<0?0:idx);target.setBackgroundTintList(android.content.res.ColorStateList.valueOf(accent));slotCard.addView(target,lp(-1,dp(48),6));
        TextView saveSlot=actionButton("Zapisz przycisk "+number,true);slotCard.addView(saveSlot,lp(-1,dp(44),9));
        saveSlot.setOnClickListener(v->{int selectedIndex=target.getSelectedItemPosition();if(selectedIndex<0||selectedIndex>=ids.size())return;String custom=name.getText().toString().trim();if(custom.isEmpty())custom="Przycisk "+number;prefs.edit().putString(prefix+"_label",custom).putString(prefix+"_app",ids.get(selectedIndex)).apply();Toast.makeText(this,"Zapisano: "+custom,Toast.LENGTH_SHORT).show();});
    }

    private LinearLayout card(LinearLayout root,int top){LinearLayout c=new LinearLayout(this);c.setOrientation(1);c.setPadding(dp(16),dp(15),dp(16),dp(16));c.setBackground(round(surface,dp(22),stroke));c.setElevation(dp(2));root.addView(c,lp(-1,-2,top));return c;}
    private void section(LinearLayout r,String title,String sub){TextView h=label(title,12,accent,true);r.addView(h,lp(-1,-2,23));r.addView(label(sub,13,muted,false),lp(-1,-2,4));}
    private void animateChildren(LinearLayout root){for(int i=0;i<root.getChildCount();i++){View v=root.getChildAt(i);v.setAlpha(0f);v.setTranslationY(dp(10));v.animate().alpha(1f).translationY(0).setStartDelay(Math.min(i*35,350)).setDuration(300).setInterpolator(new DecelerateInterpolator()).start();}}
    private void openWheelSettings(){try{Intent vendor=getPackageManager().getLaunchIntentForPackage("com.hcn.autosetting");if(vendor!=null){startActivity(vendor);Toast.makeText(this,"W ustawieniach radia znajdź mapowanie przycisków kierownicy",Toast.LENGTH_LONG).show();return;}}catch(Exception ignored){}try{startActivity(new Intent(Settings.ACTION_SETTINGS));Toast.makeText(this,"Otworzono ustawienia Androida",Toast.LENGTH_LONG).show();}catch(Exception e){Toast.makeText(this,"Nie udało się otworzyć ustawień",Toast.LENGTH_SHORT).show();}}
    private void loadApps(){ids.clear();labels.clear();ids.add(Switcher.HOME);labels.add("Ekran główny Androida");PackageManager pm=getPackageManager();List<ApplicationInfo> apps=pm.getInstalledApplications(0);Collections.sort(apps,Comparator.comparing(a->String.valueOf(pm.getApplicationLabel(a)).toLowerCase()));for(ApplicationInfo a:apps){if(a.packageName.equals(getPackageName()))continue;Intent i=pm.getLaunchIntentForPackage(a.packageName);if(i!=null){ids.add(a.packageName);labels.add(String.valueOf(pm.getApplicationLabel(a)));}}}
    private TextView label(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private TextView actionButton(String s,boolean primary){TextView b=label(s,15,primary?Color.WHITE:fg,true);b.setGravity(Gravity.CENTER);b.setPadding(dp(12),0,dp(12),0);b.setBackground(round(primary?accent:tint(accent,0.10f),dp(15),primary?accent:stroke));b.setClickable(true);b.setFocusable(true);b.setOnTouchListener((v,e)->{if(e.getAction()==android.view.MotionEvent.ACTION_DOWN)v.animate().scaleX(.985f).scaleY(.985f).setDuration(90).start();if(e.getAction()==android.view.MotionEvent.ACTION_UP||e.getAction()==android.view.MotionEvent.ACTION_CANCEL)v.animate().scaleX(1f).scaleY(1f).setDuration(150).start();return false;});return b;}
    private GradientDrawable round(int c,int r,int st){GradientDrawable d=new GradientDrawable();d.setColor(c);d.setCornerRadius(r);d.setStroke(dp(1),st);return d;}
    private int tint(int c,float a){return Color.argb((int)(255*a),Color.red(c),Color.green(c),Color.blue(c));}
    private LinearLayout.LayoutParams lp(int w,int h,int top){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(w,h);p.topMargin=dp(top);return p;}
    private int dp(int x){return (int)(x*getResources().getDisplayMetrics().density+0.5f);}
}
