package pl.essgoo.appswitcher;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.content.SharedPreferences;
import android.content.Intent;
import android.provider.Settings;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.util.*;

public class MappingActivity extends Activity {
  private SharedPreferences prefs; private Spinner codeSpinner, actionSpinner; private TextView captured;
  private final Handler handler=new Handler(); private int bg=Color.rgb(16,18,22), surface=Color.rgb(30,33,39), fg=Color.rgb(245,246,248), muted=Color.rgb(165,172,183), accent=Color.rgb(78,161,255);
  private final String[] names={"Invalid (0)","BtnSiri (5)","CarMicrophone (7)","BtnLeft (100)","BtnRight (101)","BtnSelectDown (104)","BtnSelectUp (105)","BtnBack (106)","BtnDown (114)","BtnHome (200)","BtnPlay (201)","BtnPause (202)","BtnNextTrack (204)","BtnPrevTrack (205)","SupportWifi (1000)","SupportWifiNeedKo (1012)","AudioOutputStart (1)","AudioOutputStop (2)","AudioInputConfig (3)","AudioPhonecallStart (4)","AudioPhonecallStop (5)","AudioNaviStart (6)","AudioNaviStop (7)","AudioSiriStart (8)","AudioSiriStop (9)","AudioMediaStart (10)","AudioMediaStop (11)","TouchDown (14)","TouchMove (15)","TouchUp (16)"};
  private final int[] codes={0,5,7,100,101,104,105,106,114,200,201,202,204,205,1000,1012,1,2,3,4,5,6,7,8,9,10,11,14,15,16};
  private final String[] actions={"NONE","HOME","BACK","RECENTS","SWITCHER","OPEN_DISPLAY","PLAY_PAUSE","NEXT_TRACK","PREVIOUS_TRACK","VOLUME_UP","VOLUME_DOWN","TOGGLE_THEME"};
  private final String[] actionLabels={"Brak akcji","Ekran główny Androida","Wstecz","Ostatnie aplikacje","Przełącznik","Otwórz wybraną aplikację","Odtwarzaj / pauza","Następny utwór","Poprzedni utwór","Głośniej","Ciszej","Zmień motyw dzień/noc"};
  @Override public void onCreate(Bundle b){super.onCreate(b);prefs=getSharedPreferences(Switcher.PREFS,MODE_PRIVATE);applyColors();build();pollCaptured();}
  private void applyColors(){String t=prefs.getString("theme","SYSTEM");boolean dark="DARK".equals(t)||("SYSTEM".equals(t)&&(getResources().getConfiguration().uiMode&0x30)==0x20);bg=dark?Color.rgb(10,13,18):Color.rgb(242,245,250);surface=dark?Color.rgb(25,30,39):Color.WHITE;fg=dark?Color.rgb(248,250,255):Color.rgb(20,27,39);muted=dark?Color.rgb(161,173,190):Color.rgb(95,107,124);accent=dark?Color.rgb(73,157,255):Color.rgb(0,112,245);}
  private void build(){ScrollView sc=new ScrollView(this);sc.setBackgroundColor(bg); LinearLayout root=new LinearLayout(this);root.setOrientation(1);root.setPadding(dp(20),dp(18),dp(20),dp(26));sc.addView(root);
    add(root,"ESSGOO  /  CONTROLS",12,muted,true,0);add(root,"Mapowanie przycisków",28,fg,true,8);add(root,"Przypisz akcję do kodu CarPlay albo przechwyć fizyczny klawisz Androida.",14,muted,false,6);
    section(root,"KODY PROTOKOŁU CARPLAY"); add(root,"Wybierz kod, a następnie akcję. Kody protokołu nie są automatycznie klawiszami Androida: zadziałają tylko wtedy, gdy dISplay lub inny komponent przekaże je do tej aplikacji.",13,muted,false,0);
    codeSpinner=new Spinner(this); codeSpinner.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,names)); root.addView(codeSpinner,lp(-1,dp(52),12));
    actionSpinner=new Spinner(this); actionSpinner.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,actionLabels)); root.addView(actionSpinner,lp(-1,dp(52),8));
    Button save=button("Zapisz przypisanie kodu");root.addView(save,lp(-1,dp(52),12)); save.setOnClickListener(v->{int code=codes[codeSpinner.getSelectedItemPosition()];String act=actions[actionSpinner.getSelectedItemPosition()];prefs.edit().putString("protocol_item_"+codeSpinner.getSelectedItemPosition(),act).apply();Toast.makeText(this,"Zapisano "+names[codeSpinner.getSelectedItemPosition()]+" → "+act,Toast.LENGTH_SHORT).show();});
    section(root,"NASŁUCH KLAWISZY ANDROIDA"); add(root,"Włącz usługę dostępności, a następnie rozpocznij nasłuch. Naciśnij fizyczny przycisk na radiu, jeśli generuje standardowy Android KeyEvent.",13,muted,false,0);
    captured=add(root,"Ostatni klawisz: brak",16,fg,true,12); Button listen=button("Nasłuchuj następnego klawisza");root.addView(listen,lp(-1,dp(52),8)); listen.setOnClickListener(v->{prefs.edit().putBoolean("capture_key",true).remove("captured_key_name").apply();captured.setText("Nasłuch aktywny… naciśnij klawisz");});
    Button mapCaptured=button("Przypisz ostatni klawisz do wybranej akcji");root.addView(mapCaptured,lp(-1,dp(52),8)); mapCaptured.setOnClickListener(v->{int key=prefs.getInt("captured_key_code",Integer.MIN_VALUE);if(key==Integer.MIN_VALUE){Toast.makeText(this,"Najpierw uruchom nasłuch i naciśnij klawisz",Toast.LENGTH_LONG).show();return;}String act=actions[actionSpinner.getSelectedItemPosition()];prefs.edit().putString("hardware_"+key,act).apply();Toast.makeText(this,"Klawisz Androida "+key+" → "+act,Toast.LENGTH_LONG).show();});
    Button access=button("Ustawienia dostępności Androida");root.addView(access,lp(-1,dp(50),8));access.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))); Button wheel=button("Ustawienia radia · przyciski kierownicy");root.addView(wheel,lp(-1,dp(50),8));wheel.setOnClickListener(v->{try{Intent i=getPackageManager().getLaunchIntentForPackage("com.hcn.autosetting");if(i!=null){startActivity(i);Toast.makeText(this,"Znajdź sekcję mapowania przycisków kierownicy",Toast.LENGTH_LONG).show();}else{startActivity(new Intent(Settings.ACTION_SETTINGS));Toast.makeText(this,"Nie znaleziono aplikacji ustawień ESSGOO; otwarto ustawienia Androida",Toast.LENGTH_LONG).show();}}catch(Exception e){Toast.makeText(this,"Nie udało się otworzyć ustawień radia",Toast.LENGTH_LONG).show();}});
    section(root,"MOTYW I TEST"); Button theme=new Button(this);theme.setText("Przełącz dzień / noc");theme.setAllCaps(false);theme.setTextColor(Color.WHITE);theme.setBackground(round(accent,dp(15)));root.addView(theme,lp(-1,dp(50),8));theme.setOnClickListener(v->{String old=prefs.getString("theme","SYSTEM");prefs.edit().putString("theme","DARK".equals(old)?"DAY":"DARK").apply();recreate();}); Button openDisplay=new Button(this);openDisplay.setText("Otwórz wybraną aplikację");openDisplay.setAllCaps(false);openDisplay.setTextColor(Color.WHITE);openDisplay.setBackground(round(accent,dp(15)));root.addView(openDisplay,lp(-1,dp(50),8));openDisplay.setOnClickListener(v->Switcher.perform(this));
    section(root,"WAŻNE OGRANICZENIA");add(root,"• Bez roota aplikacja nie może dowolnie wstrzykiwać KeyEventów do innych aplikacji. Może wykonać ograniczone akcje systemowe, np. Home, Wstecz i Ostatnie aplikacje.\n• Nasłuch działa tylko dla klawiszy przekazywanych przez Android AccessibilityService. Przyciski przejęte przez firmware lub aplikację radia mogą nie być widoczne.\n• BtnHome=200 to kod protokołu CarPlay, nie androidowy KEYCODE_HOME. Zapisane przypisanie protokołu jest konfiguracją, nie przechwytuje samo z siebie komunikatów dISplay.",13,muted,false,0);
    setContentView(sc);
    sc.setAlpha(0f); sc.setTranslationY(dp(12)); sc.animate().alpha(1f).translationY(0).setDuration(320).setInterpolator(new android.view.animation.DecelerateInterpolator()).start();
  }
  private void pollCaptured(){String n=prefs.getString("captured_key_name","");if(!n.isEmpty()&&captured!=null)captured.setText("Ostatni klawisz: "+n+" (kod Androida "+prefs.getInt("captured_key_code",-1)+")");handler.postDelayed(this::pollCaptured,500);}
  private void section(LinearLayout r,String s){add(r,s,12,accent,true,24);} private TextView add(LinearLayout r,String s,int size,int color,boolean bold,int top){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);LinearLayout.LayoutParams p=lp(-1,-2,top);r.addView(t,p);return t;}
  private Button button(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextColor(Color.WHITE);b.setTextSize(15);b.setBackground(round(accent,dp(15)));b.setOnTouchListener((v,e)->{if(e.getAction()==android.view.MotionEvent.ACTION_DOWN)v.animate().scaleX(.985f).scaleY(.985f).setDuration(80).start();if(e.getAction()==android.view.MotionEvent.ACTION_UP||e.getAction()==android.view.MotionEvent.ACTION_CANCEL)v.animate().scaleX(1f).scaleY(1f).setDuration(140).start();return false;});return b;} private GradientDrawable round(int c,int r){GradientDrawable d=new GradientDrawable();d.setColor(c);d.setCornerRadius(r);return d;}
  private LinearLayout.LayoutParams lp(int w,int h,int top){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(w,h);p.topMargin=dp(top);return p;} private int dp(int x){return (int)(x*getResources().getDisplayMetrics().density+0.5f);}
}
