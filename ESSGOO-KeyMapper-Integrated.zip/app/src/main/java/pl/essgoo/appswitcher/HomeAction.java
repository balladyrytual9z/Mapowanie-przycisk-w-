package pl.essgoo.appswitcher;

import android.accessibilityservice.AccessibilityService;
import android.content.Context;
import android.content.SharedPreferences;
import android.text.TextUtils;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Toast;
import android.util.Log;

/** Context-aware Home action for the steering-wheel key 1. */
public final class HomeAction {
    private static final String TAG = "ESSGOO-HomeAction";
    private HomeAction() { }

    public static void perform(AccessibilityService service) {
        SharedPreferences p = service.getSharedPreferences(Switcher.PREFS, Context.MODE_PRIVATE);
        String target = p.getString("target_app", "");
        if (TextUtils.isEmpty(target)) target = Switcher.findDisplay(service);

        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        String activePackage = "";
        if (root != null && root.getPackageName() != null) {
            String rootPackage = root.getPackageName().toString();
            // The active accessibility window can be a status-bar/keyboard overlay,
            // not the app whose screen is being controlled. Use the last real app
            // observed by AppTrackingService in that case.
            if (!isTransientSystemPackage(rootPackage) && !rootPackage.equals(service.getPackageName())) {
                activePackage = rootPackage;
            }
        }
        if (TextUtils.isEmpty(activePackage)) {
            activePackage = p.getString("last_seen", "");
        }

        if (!TextUtils.isEmpty(target) && target.equals(activePackage)) {
            // CarPlay's semantic input is CarPlayType.BtnHome=200. This standalone
            // companion app cannot inject that protocol event into DiPlay's private
            // session. First try the real, exposed Home/Dashboard accessibility node.
            boolean clicked = false;
            if (root != null) {
                try { clicked = clickHomeNode(root); }
                finally { root.recycle(); }
            }
            if (clicked) return;

            Log.w(TAG, "DiPlay is foreground, but no accessible CarPlay Home control is exposed. BtnHome="
                    + CarPlayProtocol.BTN_HOME + " requires an integration point inside DiPlay.");
            Toast.makeText(service,
                    "DiPlay nie udostępnia przycisku Home. BtnHome=200 wymaga integracji z DiPlay.",
                    Toast.LENGTH_LONG).show();
            return;
        }

        if (root != null) root.recycle();
        // Outside DiPlay: use Android's HOME action. This returns to the current
        // default launcher without attempting to finish or recreate its activity.
        service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME);
    }

    private static boolean clickHomeNode(AccessibilityNodeInfo node) {
        if (node == null) return false;
        CharSequence text = node.getText();
        CharSequence desc = node.getContentDescription();
        String resourceId = node.getViewIdResourceName();
        boolean homeNode = isHomeLabel(text) || isHomeLabel(desc) || isHomeResourceId(resourceId);
        if (homeNode) {
            AccessibilityNodeInfo clickable = node;
            while (clickable != null) {
                if (clickable.isClickable() && clickable.isEnabled()) {
                    if (clickable.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true;
                }
                AccessibilityNodeInfo parent = clickable.getParent();
                if (clickable != node) clickable.recycle();
                clickable = parent;
            }
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                boolean clicked;
                try { clicked = clickHomeNode(child); }
                finally { child.recycle(); }
                if (clicked) return true;
            }
        }
        return false;
    }

    private static boolean isTransientSystemPackage(String pkg) {
        if (pkg == null) return true;
        return pkg.equals("android") || pkg.equals("com.android.systemui")
                || pkg.equals("com.android.permissioncontroller")
                || pkg.equals("com.google.android.permissioncontroller")
                || pkg.contains("inputmethod") || pkg.contains("keyboard");
    }

    private static boolean isHomeResourceId(String value) {
        if (value == null) return false;
        String id = value.toLowerCase(java.util.Locale.ROOT);
        return id.endsWith(":id/home") || id.endsWith(":id/home_button")
                || id.endsWith(":id/dashboard") || id.endsWith(":id/dashboard_button")
                || id.endsWith(":id/carplay_home");
    }

    private static boolean isHomeLabel(CharSequence value) {
        if (value == null) return false;
        String s = value.toString().trim().toLowerCase(java.util.Locale.ROOT);
        return s.equals("home") || s.equals("carplay home") || s.equals("home screen")
                || s.equals("dashboard") || s.equals("ekran główny") || s.equals("strona główna")
                || s.equals("accueil") || s.equals("inicio") || s.equals("startseite");
    }
}
