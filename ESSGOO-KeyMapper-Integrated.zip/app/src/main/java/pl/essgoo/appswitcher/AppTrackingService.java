package pl.essgoo.appswitcher;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;
import android.view.KeyEvent;
import android.content.SharedPreferences;
import android.content.Intent;
import android.media.AudioManager;
import java.util.ArrayList;

public class AppTrackingService extends AccessibilityService {
    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || event.getPackageName() == null) return;
        int type = event.getEventType();
        if (type != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && type != AccessibilityEvent.TYPE_WINDOWS_CHANGED) return;
        String pkg = event.getPackageName().toString();
        if (pkg.equals(getPackageName()) || pkg.equals("android")) return;
        SharedPreferences p = getSharedPreferences(Switcher.PREFS, MODE_PRIVATE);
        String current = p.getString("last_seen", "");
        if (!pkg.equals(current)) {
            String previous = p.getString("previous_seen", "");
            p.edit().putString("previous_seen", current).putString("last_seen", pkg).apply();
            ArrayList<String> history = new ArrayList<>(); history.add(pkg);
            if (!current.isEmpty() && !current.equals(pkg)) history.add(current);
            if (!previous.isEmpty() && !previous.equals(pkg) && !previous.equals(current)) history.add(previous);
            p.edit().putString("history", android.text.TextUtils.join(";", history)).apply();
        }
    }
    @Override protected boolean onKeyEvent(KeyEvent event) {
        if(event==null || event.getAction()!=KeyEvent.ACTION_DOWN) return false;
        SharedPreferences p=getSharedPreferences(Switcher.PREFS,MODE_PRIVATE); int code=event.getKeyCode();
        if(p.getBoolean("capture_key",false)) { p.edit().putBoolean("capture_key",false).putInt("captured_key_code",code).putString("captured_key_name",KeyEvent.keyCodeToString(code)).apply(); return true; }
        String action=p.getString("hardware_"+code,"NONE"); if("NONE".equals(action)) return false;
        performAction(action); return true;
    }
    private void performAction(String action){
        if("HOME".equals(action)) performGlobalAction(GLOBAL_ACTION_HOME);
        else if("BACK".equals(action)) performGlobalAction(GLOBAL_ACTION_BACK);
        else if("RECENTS".equals(action)) performGlobalAction(GLOBAL_ACTION_RECENTS);
        else if("SWITCHER".equals(action)) Switcher.perform(this);
        else if("PLAY_PAUSE".equals(action)) media(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE);
        else if("NEXT_TRACK".equals(action)) media(KeyEvent.KEYCODE_MEDIA_NEXT);
        else if("PREVIOUS_TRACK".equals(action)) media(KeyEvent.KEYCODE_MEDIA_PREVIOUS);
        else if("VOLUME_UP".equals(action)) { AudioManager a=(AudioManager)getSystemService(AUDIO_SERVICE); if(a!=null)a.adjustVolume(AudioManager.ADJUST_RAISE,AudioManager.FLAG_SHOW_UI); }
        else if("VOLUME_DOWN".equals(action)) { AudioManager a=(AudioManager)getSystemService(AUDIO_SERVICE); if(a!=null)a.adjustVolume(AudioManager.ADJUST_LOWER,AudioManager.FLAG_SHOW_UI); }
    }
    private void media(int key){Intent i=new Intent(Intent.ACTION_MEDIA_BUTTON);i.putExtra(Intent.EXTRA_KEY_EVENT,new KeyEvent(KeyEvent.ACTION_DOWN,key));sendOrderedBroadcast(i,null);i.putExtra(Intent.EXTRA_KEY_EVENT,new KeyEvent(KeyEvent.ACTION_UP,key));sendOrderedBroadcast(i,null);}
    @Override public void onInterrupt() { }
}
