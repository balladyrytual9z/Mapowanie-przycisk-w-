# ESSGOO Quick Switch

Jednofunkcyjna aplikacja Android 9 (API 28+) do przełączania DiPlay ↔ launcher. Nie ma ekranu ustawień, mapowania klawiszy, Docka ani dodatkowych skrótów.

## Działanie
- Wywołanie, gdy aktywny jest launcher: uruchamia DiPlay.
- Wywołanie, gdy aktywny jest DiPlay: uruchamia systemową akcję Android HOME, zamiast ponownie uruchamiać launcher przez jego ikonę. Dzięki temu launcher ma szansę wznowić dokładnie ten ekran/kartę, na której został w tle.
- Pakiet DiPlay jest wykrywany automatycznie po nazwie pakietu lub etykiecie zawierającej `DiPlay`.

## Pierwsze uruchomienie
Android wymaga zgody użytkownika na usługę dostępności, aby aplikacja mogła rozpoznawać, która aplikacja jest na pierwszym planie. Przy pierwszym uruchomieniu otworzy się systemowe menu Dostępność. Włącz usługę **Szybkie przełączanie**, wróć do launchera i kliknij ikonę aplikacji ponownie.

Usługa obserwuje wyłącznie zdarzenia zmiany aplikacji; nie odczytuje zawartości okien i nie przechwytuje klawiszy.

## Ważne ograniczenia
1. Aby wywołać przełączenie z DiPlay, aktywność `QuickSwitcherActivity` musi być uruchamiana przez jakiś element sterujący dostępny podczas korzystania z DiPlay (np. istniejący przycisk/skrót). Sama ikona w menu launchera nie jest widoczna nad DiPlay.
2. Powrót do dokładnej karty zależy od tego, czy launcher zachowuje swój stan, gdy jest w tle. Aplikacja używa Android HOME, nie może z zewnątrz wymusić prywatnej karty wewnątrz launchera.
3. Wykrywanie DiPlay wymaga, aby nazwa pakietu lub etykieta aplikacji zawierała `DiPlay`. Jeśli firmware używa innej nazwy, trzeba zmienić dopasowanie w `findDiPlayPackage()`.

## Budowanie
Projekt źródłowy Gradle / Android Studio. `applicationId`: `pl.essgoo.quickswitch`, `minSdk`: 28, `targetSdk`: 28. W tej sesji nie wykonano kompilacji APK ani testu na radiu ESSGOO.
