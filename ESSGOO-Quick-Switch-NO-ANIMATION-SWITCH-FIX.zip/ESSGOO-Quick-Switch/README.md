# ESSGOO Quick Switch

Android 9 / API 28+, minSdk 28, targetSdk 28. Lightweight one-action switcher for DiPlay with an accessibility-service foreground tracker and a hardware-accelerated bez animacji overlay.

## Build locally

Requires JDK 17, Android SDK platform 35, Build Tools 35.0.0 and Gradle 8.9.

```bash
gradle --no-daemon assembleRelease
```

Output: `app/build/outputs/apk/release/app-release.apk`.

## GitHub Actions: automatic Releases

The workflow `.github/workflows/release.yml` runs on every push to any branch and can also be started manually. It builds a signed release APK and creates a GitHub Release with a unique tag (`v1.0.<run number>-<run attempt>`). If the repository root is not a Gradle project, the workflow finds a ZIP added in the push (or the newest ZIP in the repository), extracts it and builds the Gradle project inside it. For a ZIP upload, commit/push the ZIP to the repository; merely attaching a file to a GitHub web Release does not trigger a push workflow.

The same development signing key is stored in `signing/quick-switch-release.jks` so APKs produced by successive workflow runs can update one another. **Important:** this is a project-specific development key, not a protected production signing key. Keep the repository private if you do not want others to obtain the signing key. Do not replace or regenerate it after installing the app, or Android will reject in-place updates; uninstalling the old app would then be required.

## DiPlay behaviour and limitations

The app checks the candidate `<package>.MainActivity` component and falls back to the package launcher activity if that component is unavailable. The `MainActivity` name is not guaranteed by DiPlay vendors; direct launch to the real projection UI is only confirmed after inspecting the installed DiPlay APK/manifest or testing on the head unit. The bez animacji overlay is a translucent animated veil, not a screenshot-based crossfade: Android 9 does not let an ordinary third-party app freely capture arbitrary other-app screens without user-approved MediaProjection or app cooperation. The overlay is non-touchable, appears before both directions of the switch, waits 120 ms before opening the target app so it can render, fades after the target foreground-window event, and has a 2.2-second safety timeout.

Enable the app's Accessibility service once in Android Accessibility settings. It observes foreground window/package changes only; it does not read screen text or intercept keys.


## Direct CarPlay projection launch

The switcher checks exported activity candidates in this order: `CarPlayHostActivity`, `projection.ProjectionActivity`, `ProjectionActivity`, then `MainActivity`, across the detected DiPlay package and known package IDs (`com.carplay.dipower`, `com.shihab.diplay`, `com.shilapi.xcertplay`). If none resolves as an exported activity, it falls back to the package launcher activity. The candidate names are not proof that a particular DiPlay build exposes them; confirm against the installed APK manifest. Some vendor activities may additionally require intent extras or an internal service handshake, which cannot be inferred from the class name alone.


## Zachowanie przełączania (wersja bez animacji)

- Usunięto całkowicie nakładkę Liquid Glass, animatory, animacje zasobów i opóźnienia przed uruchomieniem aplikacji.
- Usługa dostępności służy wyłącznie do zapamiętywania pakietu na pierwszym planie.
- Przy przejściu do DiPlay aplikacja próbuje uruchomić `CarPlayHostActivity` dla wykrytego pakietu, a następnie sprawdza pozostałe znane pakiety. Jeśli aktywność nie jest eksportowana lub jej nazwa jest inna, używa standardowego launch intentu DiPlay.
- Pakiety `com.shilapi.xcertplay`, `com.carplay.dipower` i `com.shihab.diplay` są sprawdzane jawnie, więc wykrywanie nie zależy od tego, czy identyfikator zawiera słowo `diplay`.
- Powrót używa standardowego intentu HOME.

**Ograniczenie Androida:** aplikacja zewnętrzna nie może uruchomić aktywności DiPlay oznaczonej jako `exported=false`. Jeśli `CarPlayHostActivity` nie jest eksportowana albo wymaga prywatnych parametrów startowych, kod bez dostępu do wnętrza DiPlay nie może zagwarantować wejścia bezpośrednio do projekcji. W takim przypadku uruchomiony zostanie ekran startowy DiPlay.
