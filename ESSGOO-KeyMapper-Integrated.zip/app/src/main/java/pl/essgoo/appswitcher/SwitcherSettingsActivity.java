package pl.essgoo.appswitcher;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.provider.Settings;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.widget.*;
import java.util.*;

/** Dedicated settings screen for the switcher and configurable hardware triggers. */
public class SwitcherSettingsActivity extends Activity {
    private SharedPreferences prefs;
    private final ArrayList<String> ids = new ArrayList<>(), labels = new ArrayList<>();
    private TextView switchKeyLabel, homeKeyLabel, captureStatus;
    private final Handler handler = new Handler();
    private Runnable poll;
    private String captureFor = "";
    private int bg, surface, fg, muted, accent;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences(Switcher.PREFS, MODE_PRIVATE);
        boolean dark = !"DAY".equals(prefs.getString("theme", "DARK"));
        bg = dark ? 0xFF111318 : 0xFFF1F3F7;
        surface = dark ? 0xFF242832 : Color.WHITE;
        fg = dark ? Color.WHITE : 0xFF171A21;
        muted = dark ? 0xFFABB3C2 : 0xFF626B7A;
        accent = dark ? 0xFF3291FF : 0xFF006EEB;
        loadApps(); build();
    }
    @Override protected void onDestroy() { super.onDestroy(); if (poll != null) handler.removeCallbacks(poll); }

    private void build() {
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true); scroll.setBackgroundColor(bg);
        LinearLayout root = new LinearLayout(this); root.setOrientation(1); root.setPadding(dp(20), dp(18), dp(20), dp(28)); scroll.addView(root);
        add(root, "ESSGOO  /  SWITCHER", 12, muted, true, 0);
        add(root, "Ustawienia przełącznika", 27, fg, true, 7);
        add(root, "Ta aktywność konfiguruje wyłącznie szybkie przełączanie i klawisze, które je uruchamiają.", 14, muted, false, 6);

        section(root, "APLIKACJA DO PRZEŁĄCZANIA");
        Spinner target = new Spinner(this); target.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, labels));
        String selected = prefs.getString("target_app", ""); int pos = ids.indexOf(selected); target.setSelection(pos < 0 ? 0 : pos); root.addView(target, lp(-1, dp(50), 6));
        Button save = button("Zapisz aplikację docelową"); root.addView(save, lp(-1, dp(48), 8));
        save.setOnClickListener(v -> { int n = target.getSelectedItemPosition(); if (n >= 0 && n < ids.size()) { prefs.edit().putString("target_app", ids.get(n)).apply(); toast("Zapisano aplikację docelową"); } });
        Button test = button("Uruchom szybkie przełączanie teraz"); root.addView(test, lp(-1, dp(48), 8));
        test.setOnClickListener(v -> { Switcher.perform(this); finish(); });

        section(root, "PRZYCISK URUCHAMIAJĄCY SZYBKIE PRZEŁĄCZANIE");
        switchKeyLabel = add(root, keyDescription("switcher_trigger_key"), 15, fg, true, 4);
        Button switchCapture = button("Wybierz przycisk dla przełącznika"); root.addView(switchCapture, lp(-1, dp(48), 8));
        switchCapture.setOnClickListener(v -> beginCapture("switcher_trigger_key"));
        Button clearSwitch = button("Usuń przypisanie przycisku przełącznika"); root.addView(clearSwitch, lp(-1, dp(44), 6));
        clearSwitch.setOnClickListener(v -> { prefs.edit().remove("switcher_trigger_key").apply(); updateKeyLabels(); toast("Usunięto przypisanie"); });

        section(root, "PRZYCISK URUCHAMIAJĄCY POWRÓT HOME");
        homeKeyLabel = add(root, keyDescription("home_trigger_key"), 15, fg, true, 4);
        Button homeCapture = button("Wybierz przycisk dla Powrót Home"); root.addView(homeCapture, lp(-1, dp(48), 8));
        homeCapture.setOnClickListener(v -> beginCapture("home_trigger_key"));
        Button clearHome = button("Usuń przypisanie przycisku Home"); root.addView(clearHome, lp(-1, dp(44), 6));
        clearHome.setOnClickListener(v -> { prefs.edit().remove("home_trigger_key").apply(); updateKeyLabels(); toast("Usunięto przypisanie"); });
        captureStatus = add(root, "Aby przypisać klawisz, włącz usługę dostępności i naciśnij fizyczny przycisk na radiu.", 13, muted, false, 10);

        section(root, "WYMAGANE UPRAWNIENIE");
        add(root, "Przechwytywanie klawiszy działa tylko wtedy, gdy firmware przekazuje przycisk jako Android KeyEvent. Nie każdy przycisk kierownicy jest widoczny dla aplikacji.", 13, muted, false, 0);
        Button access = button("Otwórz ustawienia dostępności Androida"); root.addView(access, lp(-1, dp(48), 8));
        access.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        section(root, "POWRÓT Z DIPlay");
        add(root, "Poza DiPlay akcja używa systemowego HOME. W DiPlay próbuje kliknąć widoczny w drzewie dostępności przycisk Home/Dashboard. Nie wysyła BtnHome=200 do prywatnej sesji CarPlay, bo zewnętrzna aplikacja nie ma do niej dostępu bez integracji z DiPlay.", 13, muted, false, 0);
        setContentView(scroll);
    }

    private void beginCapture(String key) {
        captureFor = key;
        prefs.edit().putBoolean("capture_key", true).remove("captured_key_name").apply();
        captureStatus.setText("Nasłuch aktywny: naciśnij fizyczny przycisk na radiu…");
        if (poll != null) handler.removeCallbacks(poll);
        poll = new Runnable() { @Override public void run() {
            String name = prefs.getString("captured_key_name", "");
            if (!name.isEmpty()) {
                int code = prefs.getInt("captured_key_code", -1);
                if (!captureFor.isEmpty() && code >= 0) {
                    prefs.edit().putInt(captureFor, code).apply();
                    captureStatus.setText("Przypisano: " + name + " (" + code + ")");
                    captureFor = ""; updateKeyLabels(); return;
                }
            }
            if (!captureFor.isEmpty()) handler.postDelayed(this, 250);
        }};
        handler.postDelayed(poll, 250);
    }
    private void updateKeyLabels() { if (switchKeyLabel != null) switchKeyLabel.setText(keyDescription("switcher_trigger_key")); if (homeKeyLabel != null) homeKeyLabel.setText(keyDescription("home_trigger_key")); }
    private String keyDescription(String key) { int code = prefs.getInt(key, -1); return code < 0 ? "Nie przypisano klawisza" : "Przypisany klawisz: " + KeyEvent.keyCodeToString(code) + " (" + code + ")"; }
    private void loadApps() {
        ids.clear(); labels.clear(); ids.add(Switcher.HOME); labels.add("Ekran główny Androida");
        PackageManager pm = getPackageManager(); List<ApplicationInfo> apps = pm.getInstalledApplications(0);
        Collections.sort(apps, Comparator.comparing(a -> String.valueOf(pm.getApplicationLabel(a)).toLowerCase(Locale.ROOT)));
        for (ApplicationInfo app : apps) { if (app.packageName.equals(getPackageName())) continue; if (pm.getLaunchIntentForPackage(app.packageName) != null) { ids.add(app.packageName); labels.add(String.valueOf(pm.getApplicationLabel(app))); } }
    }
    private void section(LinearLayout root, String s) { add(root, s, 11, muted, true, 22); }
    private TextView add(LinearLayout root, String s, int size, int color, boolean bold, int top) { TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); if (bold) t.setTypeface(Typeface.create("sans-serif", Typeface.BOLD)); root.addView(t, lp(-1, -2, top)); return t; }
    private Button button(String s) { Button b = new Button(this); b.setText(s); b.setAllCaps(false); b.setTextColor(Color.WHITE); b.setBackground(round(accent, dp(13))); return b; }
    private GradientDrawable round(int color, int radius) { GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(radius); return d; }
    private LinearLayout.LayoutParams lp(int w, int h, int top) { LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h); p.topMargin = dp(top); return p; }
    private int dp(int n) { return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }
    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }
}
