package pl.essgoo.appswitcher;

public class Slot2Activity extends SlotLaunchActivity {
    @Override protected int slotNumber() { return 2; }
}
