package pl.essgoo.quickswitch;

import android.app.Activity;
import android.app.ActivityOptions;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.TextUtils;
import android.widget.Toast;
import java.util.HashSet;
import java.util.List;

/** One-action switcher: launcher -> DiPlay; DiPlay -> HOME/launcher. */
public final class QuickSwitcherActivity extends Activity {
    private static final String PREFS = "quick_switch_state";
    private static final String DISPLAY_PACKAGE = "cached_diplay_package";

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        if (!isTrackerEnabled()) {
            Toast.makeText(this, "Włącz usługę dostępności „Szybkie przełączanie”, aby rozpoznawać DiPlay.", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            finish();
            return;
        }
        try { performSwitch(); }
        catch (Exception e) {
            Toast.makeText(this, "Nie udało się przełączyć aplikacji.", Toast.LENGTH_SHORT).show();
            finish();
        }
    }

    private void performSwitch() {
        String displayPackage = findDiPlayPackageFast();
        if (TextUtils.isEmpty(displayPackage)) {
            Toast.makeText(this, "Nie znaleziono aplikacji DiPlay.", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }
        String last = getSharedPreferences(ForegroundTrackerService.PREFS, MODE_PRIVATE)
                .getString(ForegroundTrackerService.LAST_PACKAGE, "");
        if (displayPackage.equals(last)) {
            ActivityOptions options = ActivityOptions.makeCustomAnimation(this, R.anim.qs_return_enter, R.anim.qs_exit);
            Intent home = new Intent(Intent.ACTION_MAIN);
            home.addCategory(Intent.CATEGORY_HOME);
            ResolveInfo resolved = getPackageManager().resolveActivity(home, PackageManager.MATCH_DEFAULT_ONLY);
            if (resolved != null && resolved.activityInfo != null)
                home.setComponent(new ComponentName(resolved.activityInfo.packageName, resolved.activityInfo.name));
            home.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(home, options.toBundle());
            finish();
            return;
        }

        Intent launch = resolveDirectDiPlayActivity(displayPackage);
        if (launch == null) launch = getPackageManager().getLaunchIntentForPackage(displayPackage);
        if (launch == null) {
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().remove(DISPLAY_PACKAGE).apply();
            Toast.makeText(this, "Nie można otworzyć DiPlay. Sprawdź pakiet aplikacji.", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        final String targetPackage = launch.getComponent() != null ? launch.getComponent().getPackageName() : displayPackage;
        final String launchClass = launch.getComponent() != null ? launch.getComponent().getClassName() : "";
        ForegroundTrackerService.startTransition(this, targetPackage, launchClass);
        final Intent finalLaunch = launch;
        new Handler(Looper.getMainLooper()).post(() -> {
            try {
                ActivityOptions noAnimation = ActivityOptions.makeCustomAnimation(QuickSwitcherActivity.this, 0, 0);
                startActivity(finalLaunch, noAnimation.toBundle());
                overridePendingTransition(0, 0);
            } catch (Exception ignored) {
                Toast.makeText(QuickSwitcherActivity.this, "Nie udało się otworzyć DiPlay.", Toast.LENGTH_SHORT).show();
            } finally { finish(); }
        });
    }

    private Intent resolveDirectDiPlayActivity(String detectedPackage) {
        PackageManager pm = getPackageManager();
        String[] packages = { detectedPackage, "com.carplay.dipower", "com.shihab.diplay" };
        HashSet<String> seen = new HashSet<>();
        for (String pkg : packages) {
            if (TextUtils.isEmpty(pkg) || !seen.add(pkg)) continue;
            Intent candidate = new Intent();
            candidate.setComponent(new ComponentName(pkg, pkg + ".MainActivity"));
            candidate.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            try {
                ResolveInfo info = pm.resolveActivity(candidate, 0);
                if (info != null && info.activityInfo != null && info.activityInfo.exported
                        && pkg.equals(info.activityInfo.packageName)) return candidate;
            } catch (RuntimeException ignored) { }
        }
        return null;
    }

    private String findDiPlayPackageFast() {
        PackageManager pm = getPackageManager();
        android.content.SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        String cached = prefs.getString(DISPLAY_PACKAGE, "");
        if (!TextUtils.isEmpty(cached) && !cached.equals(getPackageName())
                && pm.getLaunchIntentForPackage(cached) != null) return cached;
        // First run only: clear stale cache and rediscover installed launcher apps.
        prefs.edit().remove(DISPLAY_PACKAGE).apply();
        List<ApplicationInfo> apps = pm.getInstalledApplications(0);
        for (ApplicationInfo app : apps) {
            if (app.packageName.equals(getPackageName())) continue;
            String pkg = app.packageName.toLowerCase(java.util.Locale.ROOT);
            String label = String.valueOf(pm.getApplicationLabel(app)).toLowerCase(java.util.Locale.ROOT);
            if (pkg.contains("diplay") || label.contains("diplay")) {
                if (pm.getLaunchIntentForPackage(app.packageName) != null) {
                    prefs.edit().putString(DISPLAY_PACKAGE, app.packageName).apply();
                    return app.packageName;
                }
            }
        }
        return "";
    }

    private boolean isTrackerEnabled() {
        String expected = new ComponentName(this, ForegroundTrackerService.class).flattenToString();
        String enabled = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (TextUtils.isEmpty(enabled)) return false;
        TextUtils.SimpleStringSplitter splitter = new TextUtils.SimpleStringSplitter(':');
        splitter.setString(enabled);
        while (splitter.hasNext()) {
            String item = splitter.next();
            if (expected.equalsIgnoreCase(item) || item.equalsIgnoreCase(expected.replace('/', '\\'))) return true;
        }
        return false;
    }
}
