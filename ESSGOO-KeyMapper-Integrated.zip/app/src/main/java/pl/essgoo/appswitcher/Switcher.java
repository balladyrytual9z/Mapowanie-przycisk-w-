package pl.essgoo.appswitcher;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.text.TextUtils;
import java.util.ArrayList;
import java.util.Arrays;

public final class Switcher {
    public static final String PREFS = "switcher_prefs";
    public static final String HOME = "__HOME__";
    private Switcher() {}

    public static void perform(Context c) {
        SharedPreferences p = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String mode = p.getString("mode", "ALT_TAB");
        String target;
        if ("PAIR".equals(mode)) {
            String a = p.getString("target_a", HOME);
            String b = p.getString("target_b", "");
            String current = p.getString("last_seen", "");
            String lastTarget = p.getString("last_target", "");
            if (b.isEmpty()) b = HOME;
            if (current.equals(a) || lastTarget.equals(a)) target = b; else if (current.equals(b) || lastTarget.equals(b)) target = a; else target = a;
            p.edit().putString("last_target", target).apply();
        } else {
            String hist = p.getString("history", "");
            ArrayList<String> items = new ArrayList<>(Arrays.asList(hist.split(";")));
            String current = p.getString("last_seen", "");
            target = "";
            for (String item : items) if (!item.isEmpty() && !item.equals(current) && !item.equals(c.getPackageName())) { target = item; break; }
            if (target.isEmpty()) target = p.getString("previous_seen", "");
        }
        if (target == null || target.isEmpty() || target.equals(c.getPackageName())) {
            openHome(c); return;
        }
        if (HOME.equals(target)) { openHome(c); return; }
        try {
            PackageManager pm = c.getPackageManager();
            Intent launch = pm.getLaunchIntentForPackage(target);
            if (launch != null) {
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
                c.startActivity(launch);
            } else openHome(c);
        } catch (Exception e) { openHome(c); }
    }
    private static void openHome(Context c) {
        try {
            Intent i = new Intent(Intent.ACTION_MAIN);
            i.addCategory(Intent.CATEGORY_HOME);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            c.startActivity(i);
        } catch (Exception ignored) { }
    }
}
