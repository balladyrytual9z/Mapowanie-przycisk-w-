package pl.essgoo.quickswitch;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Full-screen translucent overlay that plays the selected transition,
 * launches the target app at the midpoint, then finishes.
 */
public final class AnimationOverlayActivity extends Activity {
    public static final String EXTRA_ANIM = "anim";
    public static final String EXTRA_PACKAGE = "pkg";
    public static final String EXTRA_GO_HOME = "go_home";

    private boolean targetLaunched;
    private AnimationCanvasView canvas;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_overlay);

        int anim = getIntent().getIntExtra(EXTRA_ANIM, AnimationType.FADE);
        final String pkg = getIntent().getStringExtra(EXTRA_PACKAGE);
        final boolean goHome = getIntent().getBooleanExtra(EXTRA_GO_HOME, false);

        canvas = findViewById(R.id.anim_canvas);
        TextView title = findViewById(R.id.overlay_title);
        TextView subtitle = findViewById(R.id.overlay_subtitle);

        canvas.setAnimationType(anim);

        // Optional text layers for branded animations
        if (anim == AnimationType.HONDA) {
            title.setText("HONDA");
            subtitle.setText("SENSING");
        } else if (anim == AnimationType.CARPLAY) {
            title.setText("");
            subtitle.setText("");
        } else if (anim == AnimationType.IPHONE_BOOT) {
            title.setText("");
            subtitle.setText("");
        }

        int duration = AnimationType.durationMs(anim);
        // Launch target roughly at 45% of the animation
        final float launchAt = 0.45f;

        ValueAnimator va = ValueAnimator.ofFloat(0f, 1f);
        va.setDuration(duration);
        va.setInterpolator(new AccelerateDecelerateInterpolator());
        va.addUpdateListener(a -> {
            float p = (float) a.getAnimatedValue();
            canvas.setProgress(p);
            if (!targetLaunched && p >= launchAt) {
                targetLaunched = true;
                launchTarget(pkg, goHome);
            }
        });
        va.addListener(new AnimatorListenerAdapter() {
            @Override public void onAnimationEnd(Animator animation) {
                if (!targetLaunched) launchTarget(pkg, goHome);
                finish();
                overridePendingTransition(0, 0);
            }
        });
        va.start();
    }

    private void launchTarget(String pkg, boolean goHome) {
        try {
            if (goHome) {
                startActivity(SwitchHelper.buildHomeIntent());
            } else {
                Intent launch = SwitchHelper.buildDiPlayIntent(this, pkg);
                if (launch != null) {
                    startActivity(launch);
                } else {
                    Toast.makeText(this, "DiPlay nie udostępnia ekranu do uruchomienia.", Toast.LENGTH_LONG).show();
                }
            }
            overridePendingTransition(0, 0);
        } catch (Exception e) {
            Toast.makeText(this, "Android zablokował uruchomienie.", Toast.LENGTH_LONG).show();
        }
    }

    @Override public void onBackPressed() {
        // Block back during animation
    }
}
